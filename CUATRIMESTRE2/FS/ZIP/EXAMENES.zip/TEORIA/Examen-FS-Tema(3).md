## EXAMEN DE FUNDAMENTOS DEL SOFTWARE: TEMA 3

*Autor: Daniel Pérez Ruiz*



1.- Definir lenguaje, compilador, interprete, gramática formal,enlazador, cargador.

2.- Definir símbolo terminal, no terminal, reglas de producción, símbolo inicial

3.- Lexema, token, arbol sintáctico

4.- Fases lexicografíca, sintáctica y semántica

5.- Realice el siguiente árbol sintáctico (diapositivas)

6.- Fases de construcción de un traductor

7.- Bibliotecas, ventajas y desventajas de todas

8.- Registro de activación, uso, qué almacena,y como se hace y deshace la pila (viene en los apuntes)

9.- Definir region y decir tres tipos, definir zona y decir tres tipos

10.- Definir qué es una tabla de símbolos, quién la construye, quién la usa (en qué procesos)

11.- Definición de gramáticas libres de contexto y de LL, LR.

12.- Define: función de generación de código intermedio, optimización del código intermedio, generación de código y optimización del código.

