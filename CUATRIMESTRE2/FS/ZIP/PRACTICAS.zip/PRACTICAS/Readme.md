## README: FUNDAMENTOS DEL SOFTWARE (PRÁTICAS)

##### Autor: *Daniel Pérez Ruiz - @danielperezruiz.10*

*Información más detallada respecto a la parte práctica de la asignatura de Fundamentos del Software*

#### 1. ESTRUCTURA DE CONTENIDOS

*Fecha de Actualización 28/06/2019*

* GUIONES: *Teoría de la parte práctica de Fundamentos del Software*
  * Total de Archivos: 3 elementos
  * Tipo de Archivos: PDF
* MAKEFILES: *Contiene material para la realización y test de Makefiles, así como una plantilla completa.*
  * Total de Archivos: 2 elementos
  * Tipo de Archivos: .Zip ; Archivo Plano
* RESÚMENES: *Contiene una serie de resúmenes sobre Órdenes en el intérprete de comandos de Linux (Bash)*
  * Total de Archivos: 5 elementos
  * Tipo de Archivos: PDF
* SESIONES RESUELTAS: *Contiene las prácticas resueltas de la asignatura
  * Total de Archivos: 9 elementos
  * Tipo de Archivos: PDF
