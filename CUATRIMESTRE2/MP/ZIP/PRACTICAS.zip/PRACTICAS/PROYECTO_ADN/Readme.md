## ADVERTENCIA ANTI-PLAGIO

##### Autor: *Daniel Pérez Ruiz - @danielperezruiz.10*

:warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: 

*La UGR dispone de unas políticas de anti-plagio bastante estrictas con sanciones que pueden ir desde la apertura de expediente hasta la expulsión de la Universidad.*

*Eres libre para usar mi código para entender la metodología que he empleado, así como la implementación de ciertos métodos y/o construcción final del proyecto, sin embargo, me veo obligado a advertirte sobre la posterior verificación de similitud entre prácticas con otros compañeros una vez realizada la entrega de los mismos.*

:warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: :warning: 



**NOTA ADICIONAL: AUNQUE TODAS LAS PRÁCTICAS SON 100% FUNCIONALES, LA ÚNICA PRÁCTICA QUE ESTÁ VALIDADA EN TODOS LOS ASPECTOS ES LA FINAL (PRÁCTICA 5). EL RESTO PUEDE CONTENER REDUNDANCIA DE CÓDIGO, CÓDIGO SUCIO, ENTRE OTROS.**