#include <iostream>
#include <cstdlib>  // rand
#include <ctime> // time
#include <cmath> // floor

/**
 * @brief Genera un valor aleatorio uniforme del intervalo [minimo,maximo] ambos inclusive
 * @param minimo el mínimo valor posible a generar aleatoriamente
 * @param maximo el máximo valor posible a generar aleatoriamente
 * @return Un número entero aleatorio uniforme en el intervalo [minimo,maximo] ambos inclusive
 */
int uniforme(int minimo, int maximo)
{
    double u01= std::rand() / (RAND_MAX+1.0); // Uniforme01
    return floor(minimo + u01 * (maximo-minimo+1));
}


/**
 * @brief Imprime un array de enteros en la salida estándar
 * @param array El array de enteros a imprimir
 * @param util Número de elementos útiles del array
 */
void imprimirArray(const int array[], int util){
    std::cout<<util<<std::endl;
    for(int i=0;i<util;i++){
        std::cout<<array[i]<<" ";
    }
    std::cout<<std::endl;
}

/**
 * @brief Rellena un array de enteros con números aleatorios uniformes en el intervalo [minimo ,maximo]
 * ambos inclusive.
 * @param array El array de enteros a rellenar con números aleatorios
 * @param minimo Mínimo valor a generar
 * @param maximo Máximo valor a generar
 */
void generarArray(int array[], int util, int minimo, int maximo)
{
    for(int i=0;i<util;i++){
        array[i] = uniforme(minimo, maximo);
    }
}

int main(int argc, char* argv[])
{
    const int DIMARRAYALEATORIO=1000;
    int arrayAleatorio[DIMARRAYALEATORIO];
    int util;
    int minimo; // Queremos valores en el rango -30<=n<=50
    int maximo;

    std::clog<<"Número de elementos útiles: ";
    std::cin>>util;
    std::clog<<"Mínimo valor: ";
    std::cin>>minimo;
    std::clog<<"Máximo valor: ";
    std::cin>>maximo;

    // Inicializa el generador con el reloj del sistema
    srand ((int) time(0));
    generarArray(arrayAleatorio,util,minimo,maximo);
    imprimirArray(arrayAleatorio,util);
}
