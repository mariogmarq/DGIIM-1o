#include <iostream>

using namespace std;


/**
@brief Escribe los elementos del array en la salida estándar
@param array El array a imprimir
@param util_array Número de elementos útiles en el array
@pre array debería contener al menos un elemento
*/
void imprimirArray(const double array[],int util_array){
    for(int i=0; i<util_array; ++i)
    {
        cout<<array[i]<<" ";
    }
    cout<<endl;
}

int mezclarUnico(const double array1[], int utilArray1, const double array2[], int utilArray2, double arraySalida[]){
    int index1,index2, indexSalida;;
    
    index1=index2=indexSalida=0;
    while(index1<utilArray1 && index2<utilArray2){
        if(array1[index1]<array2[index2]){
            arraySalida[indexSalida]=array1[index1];
            index1++;
        }
        else if (array1[index1]>array2[index2]){
            arraySalida[indexSalida]=array2[index2];
            index2++;           
        }
        else{ // Si son iguales en array1 y array2
            arraySalida[indexSalida]=array1[index1];
            index1++;
            index2++;
        }
        indexSalida++;
    }
    while(index1<utilArray1){
        arraySalida[indexSalida]=array1[index1];
        index1++;     
        indexSalida++;
    }
    while(index2<utilArray2){
        arraySalida[indexSalida]=array2[index2];
        index2++;     
        indexSalida++;
    }
    return indexSalida;
}

int main()
{
    const int DIM_ARRAY_SALIDA=100;
    double array1[] = {1, 3 , 5, 7};
    double array2[] = {2, 4, 4.3, 9};
    double array3[] = {1, 3 , 5};
    double array4[] = {2, 3.8, 4.3, 6.4, 9.3};
    double array5[] = {5, 6.3, 7.5, 8.3, 9.2};
    double array6[] = {1.0, 3.4, 6.3};
    double arraySalida[DIM_ARRAY_SALIDA];
    int utilArraySalida;
    
    utilArraySalida=mezclarUnico(array1, 4, array2, 4, arraySalida);
    imprimirArray(arraySalida, utilArraySalida);
    
    utilArraySalida=mezclarUnico(array3, 3, array4, 5, arraySalida);
    imprimirArray(arraySalida, utilArraySalida);
    
    utilArraySalida=mezclarUnico(array5, 5, array6, 3, arraySalida);
    imprimirArray(arraySalida, utilArraySalida);
}
