#include <iostream>

using namespace std;

/**
 * @brief Imprime un array de enteros en la salida estándar
 * @param array El array de enteros a imprimir
 * @param util Número de elementos útiles del array
 */
void imprimirArray(const int array[], int util){
    std::cout<<util<<std::endl;
    for(int i=0;i<util;i++){
        std::cout<<array[i]<<" ";
    }
    std::cout<<std::endl;
}


/**
@brief Lee el número de elementos útiles de un array de int y sus elementos
@param array El array donde se guardan los elementos leídos
@param dim La dimesión del array
@param util_array Número de elementos útiles en el array
*/
void leerArray(int array[], int dim, int &util_array)
{
    cout<<"Número de elementos (máximo: "<<dim<<"):";
    cin>>util_array;
    if(util_array>dim)
        util_array=dim;
    else if(util_array<0)
    {
        util_array=0;
    }
    for(int i=0; i<util_array; ++i)
    {
        cin>>array[i];
    }
    cout<<endl;
}

/**
@brief Busca y devuelve el elemento máximo de un array de int
@param array El array donde buscar el máximo elemento
@param util_array Número de elementos útiles en el array
@return La posición del elemento mínimo del array o -1 si final<inicial
*/
int buscarMinimoArray(const int array[],int inicial, int final)
{
    int posMin=-1;
    int min;

    if(final>=inicial)
    {
        min=array[inicial];
        posMin=inicial;
        for(int i=inicial+1; i<=final; ++i)
        {
            if(array[i]<min)
            {
                min=array[i];
                posMin=i;
            }
        }
    }

    return posMin;
}

int main()
{
    const int DIM_ARRAY=100;
    int array[DIM_ARRAY];
    int util_array;

    leerArray(array,DIM_ARRAY,util_array);

    if(util_array>0){
        cout<<"Array leído: ";
        imprimirArray(array, util_array);
        cout<<"Mínimo: "<<array[buscarMinimoArray(array,0,util_array-1)]<<endl;
    }
    else
        cout<<"No hay elementos en el array"<<endl;
}
