#include <iostream>

using namespace std;

/**
 * @brief Imprime un array de enteros en la salida estándar
 * @param array El array de enteros a imprimir
 * @param util Número de elementos útiles del array
 */
void imprimirArray(const int array[], int util)
{
    std::cout<<util<<std::endl;
    for(int i=0; i<util; i++)
    {
        std::cout<<array[i]<<" ";
    }
    std::cout<<std::endl;
}


/**
@brief Lee el número de elementos útiles de un array de int y sus elementos
@param array El array donde se guardan los elementos leídos
@param dim La dimesión del array
@param util_array Número de elementos útiles en el array
*/
void leerArray(int array[], int dim, int &util_array)
{
    cout<<"Número de elementos (máximo: "<<dim<<"):";
    cin>>util_array;
    if(util_array>dim)
        util_array=dim;
    else if(util_array<0)
    {
        util_array=0;
    }
    for(int i=0; i<util_array; ++i)
    {
        cin>>array[i];
    }
}

/**
@brief Busca secuencialmente un elemento en el array y devuelve su posición, o @retval -1 si no se encuentra
@param array El array donde buscar el elemento
@param util_array Número de elementos útiles en el array
@pre El array debería estar ordenado de menor a mayor. Esto no se comprueba en la función, por lo que se obtendrán resultados 
inesperados si esta precondición no se cumple.
@return La posición del elemento buscado o @retval -1 si no se encuentra
*/
int busquedaBinariaArray(const int array[], int elemento, int inicial, int final)
{
    int izq = inicial, der = final;
    while(izq <= der){
        int centro = (izq + der)/2;
        if(array[centro] > elemento){
            der = centro-1;
        }
        else if(array[centro] < elemento){
            izq = centro+1;
        }
        else{
            return centro;
        }
    }
    return -1;
}

int main()
{
    const int DIM_ARRAY=100;
    int array[DIM_ARRAY];
    int util_array;
    int elemento;

    leerArray(array,DIM_ARRAY,util_array);
    cout<<"Elemento buscado: ";
    cin >> elemento;

    if(util_array>0)
    {
        cout<<"Array leído: ";
        imprimirArray(array, util_array);
        cout<<"Elemento encontrado en posición: "<<
            busquedaBinariaArray(array,elemento,0,util_array-1)<<endl;
    }
    else
        cout<<"No hay elementos en el array"<<endl;
}
