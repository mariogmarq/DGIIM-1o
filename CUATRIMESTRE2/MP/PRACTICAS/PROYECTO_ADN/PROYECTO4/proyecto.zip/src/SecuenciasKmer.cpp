/** 
 * @file SecuenciasKmer.cpp
 * @author Daniel Pérez Ruiz
 * @version 4.0
*/

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>

#include "Kmer.h"
#include "SecuenciasKmer.h"

using namespace std;

const int K=5; /// Número de genes en el Kmer
const string VALIDOS="_atgc"; /// Caracteres vaĺidos

long maxKmer();
Kmer normalizaKmer(const Kmer & km);

/**
 * MÉTODOS PRIVADOS DE LA CLASE "SECUENCIASKMER.H"
 */

void SecuenciasKmer::reservarMemoria(long n){
    if(_conjunto == nullptr){
        _conjunto = new Kmer[n];
    }
}

void SecuenciasKmer::liberarMemoria(){
    if(_conjunto != nullptr){
        delete[] _conjunto;
        _conjunto = nullptr;
    }
}

/**
 * MÉTODOS PÚBLICOS DE LA CLASE "SECUENCIASKMER.H"
 */

/**
 * 1. CONSTRUCTORES Y DESTRUCTORES
 */

SecuenciasKmer::SecuenciasKmer(){
    _conjunto = nullptr;
    _nKmer = 0;
}

SecuenciasKmer::SecuenciasKmer(long nkm){
    reservarMemoria(nkm);
}

SecuenciasKmer::~SecuenciasKmer(){
    liberarMemoria();
}

/*
 * 2. MÉTODOS PARA POSICIONES CONCRETAS DEL VECTOR DINÁMICO
 */

void SecuenciasKmer::setPosicion(long p, const Kmer& km){
    if(p > -1){
        _conjunto[p] = km;
    }
    else{
        cerr << "ERROR [0] EN setPosicion: POSICION DE INSERCION NO PERMITIDA" << endl;
    }
}

Kmer SecuenciasKmer::getPosicion(long p) const{
    Kmer _copia_buscar;
    
    if(p < getSize()){
        _copia_buscar = _conjunto[p];
    }
    else{
        cerr << "ERROR [1] EN getPosicion: POSICION NO PERMITIDA" << endl;
    }
    
    return _copia_buscar;
}

void SecuenciasKmer::deletePosicion(long p){
    Kmer* redimension = new Kmer[getSize()-1];
    int j=0;
    
    if(p > 0 && p < getSize()){
        
        while(j < getSize()){
            if(j != p){
                redimension[j] = _conjunto[j];
            }
            j++;
        }
        
        liberarMemoria();
        _conjunto = redimension;
        
        _nKmer--;
    }
    else{
        cerr << "ERROR [2] EN deletePosicion: POSICION NO PERMITIDA" << endl;
    }
}

/**
 * 3. GESTIÓN DE KMERS
 */

long SecuenciasKmer::findKmer(const std::string& km, long inicial) const{
    long posicion = 0;
    bool encontrado = false;
    
    for(long i=inicial; i<getSize() && !encontrado; i++){
        if(_conjunto[i].getCadena() == km){
            encontrado = true;
            posicion = i;
        }
    }
    if(!encontrado){
        posicion = -1;
    }
    
    return posicion;
}

void SecuenciasKmer::ordenar(){
    Kmer kmer_swap;
    
    for(int i=0; i<getSize()-1;i++){
        for(int j=i+1; j<getSize(); j++){
            if(_conjunto[i].getFrecuencia() < _conjunto[j].getFrecuencia()){
                kmer_swap = _conjunto[i];
                _conjunto[i] = _conjunto[j];
                _conjunto[j] = kmer_swap;
            }  
        }

    }
}

void SecuenciasKmer::zipSecuenciasKmer(){
    int count = 0;
    Kmer vector[getSize()];
    
    bool find = false, already_evaluate = false;
    string cadenaA, cadenaB;
    
    for(int i=0; i<_nKmer; i++){
        if(_conjunto[i].getFrecuencia() != 0){
            cadenaA = _conjunto[i].getCadena();
        
            for(int j=0; j<count && !already_evaluate; j++){
                cadenaB = vector[j].getCadena();
            
                if(cadenaA == cadenaB){
                    already_evaluate = true;
                }
            }
        
            if(!already_evaluate){
                for(int j=i+1; j<getSize(); j++){
                    cadenaB = _conjunto[j].getCadena();
            
                    if(cadenaA == cadenaB){
                        _conjunto[i].setFrecuencia(_conjunto[i].getFrecuencia() + _conjunto[j].getFrecuencia());
                    }
                }
            
                vector[count] = _conjunto[i];
                count++;
            
                find = false;
            }
        
            already_evaluate = false;
        }
    }
    
    if(count > 0){
        liberarMemoria();
        reservarMemoria(count);
        for(int i=0; i<count; i++){
            _conjunto[i] = vector[i];
        }
        _nKmer = count;
    }
    else{
        _nKmer = 0;
    }
}

/*
 * 4. GESTIÓN DE FICHEROS DE KMER
 */

bool SecuenciasKmer::saveFichero(const char* fichero) const{
    bool resultado = true;
    ofstream fout;
    
    fout.open(fichero);
    if(fout){
        fout << MAGIC << endl;
        fout << getSize() << endl;
        for(int i=0; i<getSize();i++){
            fout << _conjunto[i].getCadena() << " " << _conjunto[i].getFrecuencia() << endl;
        }
        if(!fout){
            cerr << "ERROR [3] EN saveFichero: NO SE PUDIERON ESCRIBIR LOS DATOS EN EL FICHERO -> [" << fichero << "]" << endl;
            resultado = false;
        }
        else{
            cout << "SE HAN GUARDADO [" << getSize() << "] KMERS CORRECTAMENTE EN EL FICHERO -> [" << fichero << "]" << endl;
        }
        fout.close();
    }
    else{
        cerr << "ERROR [4] EN saveFichero: FICHERO [" << fichero << "] NO ES VALIDO" << endl;
        resultado = false;
    }
    
    return resultado;
}

bool SecuenciasKmer::loadFichero(const char* fichero){
    bool resultado = true;
    string check_magic, string_kmer = " ";
    int total_datos = 0, frecuencia_kmer = 0;
    Kmer kmer_a_leer;
    ifstream fin;
    
    fin.open(fichero);
    if(fin){
        fin >> check_magic;
        if(check_magic == MAGIC){
            if(fin){
                fin >> total_datos;
                if(0 < total_datos){
                    if(fin){
                        reservarMemoria(total_datos);
                        _nKmer = total_datos;
                        
                        for(int i=0; i < total_datos; i++){
                            fin >> string_kmer >> frecuencia_kmer;
                            
                            kmer_a_leer.setCadena(string_kmer);
                            kmer_a_leer.setFrecuencia(frecuencia_kmer);
                            
                            
                            setPosicion(i,normalizaKmer(kmer_a_leer));
                        }
                        if(fin){
                            cout << "SE HAN LEIDO [" << total_datos << "] KMERS CORRECTAMENTE DEL FICHERO -> [" << fichero << "]" << endl; 
                        }
                        else{
                            cerr << "ERROR [10] EN loadFichero: INCOHERENCIA EN NUMERO DE KMERS" << endl;
                            return false;
                        }
                    }
                    else{
                        cerr << "ERROR [6] EN loadFichero: FALLO EN LA LECTURA DE KMERS DEL FICHERO -> [" << fichero << "]" << endl;
                        resultado = false;
                    }
                }
                else{
                    cerr << "ERROR [7] EN loadFichero: FALLO EN LA LECTURA DE KMERS DEL FICHERO -> [" << fichero << "] (TOTAL DE DATOS NO VALIDO)" << endl;
                    resultado = false;
                }
            }
            else{
                cerr << "ERROR [8] EN loadFichero: EL FICHERO [" << fichero << "] NO ES VALIDO" << endl;
                resultado = false;
            }
        }
        else{
            cerr << "ERROR [9] EN loadFichero: EL FICHERO [" << fichero << "] NO ES VALIDO (MAGIC WORD NOT FOUND)" << endl;
            resultado = false;
        }
        if(!fin){
            resultado = false;
        }
        
        fin.close();
    }
    else{
        cerr << "ERROR [8] EN loadFichero: EL FICHERO [" << fichero << "] NO ES VALIDO" << endl;
        resultado = false;
    }
    
    return resultado;
}

/**
 * 5. LECTURA Y ESCRITURA DE KMERS
 */

void SecuenciasKmer::writeSecuenciasKmer(int frecmin) const{
    for(int i=0; i< getSize(); i++){
        if(_conjunto[i].getFrecuencia() >= frecmin){
            _conjunto[i].writeKmer();
            cout << endl;
        }
    }
}

void SecuenciasKmer::readSecuenciasKmer(){
    int num_datos = -1, frecuencia_kmer = 0;
    string cadena_kmer;
    Kmer kmer_a_leer;
    
    cout << "PROGRAMA LISTO PARA LEER DATOS DESDE TECLADO" << endl;
    
    while(num_datos < 0){
        cout << "Indique cuantos datos quiere leer: ";
        cin >> num_datos;
    }
    
    
    
    if(num_datos == 0){
        cout << endl << "FIN DE LECTURA. NO SE INSERTARAN DATOS" << endl;
    }
    else{
        reservarMemoria(num_datos);
        _nKmer = num_datos;
        
        for(int i=0; i<num_datos; i++){
            cout << endl << "INSERTE CADENA KMER: ";
            cin >> cadena_kmer;
            cout << "INSERTE FRECUENCIA KMER: ";
            cin >> frecuencia_kmer;
            
            kmer_a_leer.setCadena(cadena_kmer);
            kmer_a_leer.setFrecuencia(frecuencia_kmer);
            
            setPosicion(i,normalizaKmer(kmer_a_leer));
        }
        
        liberarMemoria();
    }
}

/**
 * OTROS MÉTODOS
 */

/**
 * @brief Normaliza un Kmer. La longitud debe ser exactamente la fijada por @p K y cualquier carácter
 * ausente o nó @p VALIDO debe ser sustituido por el carácter comodín @p VALIDOS[0].
 * Igualmente, cualquier carácter @p VALIDO debe pasarse a minúscula. Finalmente, la frecuencia
 * debe ser >= 0
 * @param km El Kmer a normalizar
 * @return Una copia normalizada de @p km
 */
Kmer normalizaKmer(const Kmer & km)  {
    Kmer _kmer_normalizado;
    string _kmer_copia=km.getCadena(), _kmer_swap;
    int frecuencia_copia=km.getFrecuencia(), j=0;
    bool caracter_valido = false;
    
    //AJUSTE DE LONGITUD DE KMER
    if(_kmer_copia.size() < K){
        for(int x=_kmer_copia.size(); x<K; x++){
            _kmer_copia += VALIDOS[0];
        }
    }
    
    if(_kmer_copia.size() > K){
        for(int y=0; y<K; y++){
            _kmer_swap += _kmer_copia[y];
        }
        _kmer_copia = _kmer_swap;
    }
    
    //ELIMINA CARACTERES NO PERMITIDOS Y CAMBIA MAYÚS -> MINÚS EN CARÁCTER VÁLIDO
    for(int i=0; i<_kmer_copia.size();i++){
        while(j < VALIDOS.size() && !caracter_valido){
            if(_kmer_copia[i] == VALIDOS[j]){
                caracter_valido = true;
            }
            else{
                if(_kmer_copia[i] == toupper(VALIDOS[j])){
                    _kmer_copia[i] = VALIDOS[j];
                    caracter_valido = true;
                }
                j++;
            }
        }
        
        if(!caracter_valido){
            _kmer_copia[i] = VALIDOS[0];
        }
        caracter_valido = false;
        j=0;
    }
    
    //CORRIGE FRECUENCIA
    if(frecuencia_copia < 0){
        frecuencia_copia = 0;
    }
    
    _kmer_normalizado.setCadena(_kmer_copia);
    _kmer_normalizado.setFrecuencia(frecuencia_copia);
    
    return _kmer_normalizado;
}

/**
 * @brief Calcula el número de combinaciones posibles de trigramas
 * @return Un entero largo
 */
long maxKmer(){
    return pow(VALIDOS.size(),K);
}