/**
 * @file main.cpp
 * @author Daniel Pérez Ruiz
 * @version 4.0
 */
#include <iostream>
#include <string>
#include "Kmer.h"
#include "SecuenciasKmer.h"

using namespace std;

void mensajeError() {
    cerr << "ERROR en la llamada" << endl;
    cerr << "   kmer [-i <fichero-entrada>] [-o <fichero-salida>]"<<endl;
    exit(1); 
}

void MakeKmer(SecuenciasKmer &secuencia){
    cout << "SE HAN INTRODUCIDO CORRECTAMENTE [" << secuencia.getSize() << "] KMERS" << endl;
    cout << "ORDENANDO SECUENCIAS INTRODUCIDAS..." << endl;
    secuencia.ordenar();
            
    cout << "COMPRIMIENDO SECUENCIAS..." << endl;
    secuencia.zipSecuenciasKmer();
}

void ShowKmer(SecuenciasKmer &secuencia){
    cout << "MOSTRANDO [" << secuencia.getSize() <<  "] RESULTADOS: " << endl;
    secuencia.writeSecuenciasKmer();
}
 
int main(int narg, char *args[]) {
    SecuenciasKmer seq;
    string arg0 = "", arg1 = "", arg2 = "", arg3 = "", arg4 = "";
    bool load_save = true;
    
    if (narg != 1 && narg != 3 && narg != 5)
        mensajeError();
    else{
        if(narg == 1){
            seq.readSecuenciasKmer();
            MakeKmer(seq);
            seq.writeSecuenciasKmer();
        }
        else{
            arg1 = args[1];
            arg2 = args[2];
            
            if(narg == 5){
                arg3 = args[3];
                arg4 = args[4];
            }
            
            if(arg1 == "-i" && arg3 == ""){
                load_save = seq.loadFichero(args[2]);
                if(load_save){
                    MakeKmer(seq);
                    ShowKmer(seq);
                }
            }
            else{
                if(arg1 == "-i" && arg3 == "-o"){
                    load_save = seq.loadFichero(args[2]);
                    if(load_save){
                        MakeKmer(seq);
                        seq.saveFichero(args[4]);
                    }
                }
                
                else{
                    if(arg1 == "-o" && arg3 == ""){
                        load_save = seq.saveFichero(args[2]);
                        if(load_save){
                            seq.readSecuenciasKmer();
                            MakeKmer(seq);
                        }
                    }
                    else{
                        if(arg1 == "-o" && arg3 == "-i"){
                            load_save = seq.loadFichero(args[4]);
                            
                            if(load_save){
                                MakeKmer(seq);
                                seq.saveFichero(args[2]);
                            }
                        }
                        else{
                            mensajeError();
                        }
                    }
                }
            }
        }
    }
    return 0;
}