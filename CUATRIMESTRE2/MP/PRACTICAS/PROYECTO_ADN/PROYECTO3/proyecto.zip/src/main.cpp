/**
 * @file main.cpp
 * @author Daniel Pérez Ruiz
 */
#include <iostream>
#include <string>
#include <cstring>
#include "Kmer.h"
#include "SecuenciasKmer.h"

using namespace std;

void mensajeError() {
    cerr << "ERROR en la llamada" << endl;
    cerr << "   kmer [-i <fichero-entrada>] [-o <fichero-salida>]"<<endl;
    exit(1); 
}

void MakeKmer(SecuenciasKmer &secuencia){
    cout << "SE HAN INTRODUCIDO CORRECTAMENTE [" << secuencia.getSize() << "] KMERS" << endl;
    cout << "ORDENANDO SECUENCIAS INTRODUCIDAS..." << endl;
    secuencia.ordenar();
            
    cout << "COMPRIMIENDO SECUENCIAS..." << endl;
    secuencia.zipSecuenciasKmer();
}

void SuccesfulMessage(SecuenciasKmer secuencia, char argumento[], bool resultado){
    string arg = argumento;
    if(resultado){
        cout << "[" << secuencia.getSize() << "]" << " DATOS GUARDADOS CORRECTAMENTE EN " << arg << endl;
    }
}
 
int main(int narg, char *args[]) {
    SecuenciasKmer seq;
    string argumento;
    bool load_true = true;
    bool save_true = true;
    
    if (narg != 1 && narg != 3 && narg != 5)
        mensajeError();
    else{
        if(narg == 1){
            seq.readSecuenciasKmer();
            
            MakeKmer(seq);
            
            cout << "MOSTRANDO [" << seq.getSize() <<  "] RESULTADOS: " << endl;
            seq.writeSecuenciasKmer();
        }
        else{
            if(narg == 3){
                if(strcmp(args[1], "-i") == 0){
                    load_true = seq.loadFichero(args[2]);
                    if(load_true){
                        argumento = args[2];
                        cout << "LEYENDO SECUENCIAS EN: " << argumento << endl;
                    
                        MakeKmer(seq);
                    
                        cout << "MOSTRANDO [" << seq.getSize() <<  "] RESULTADOS: " << endl;
                        seq.writeSecuenciasKmer();
                    }
                    else{
                        cerr << "ERROR EN ARGUMENTO 2: FICHERO DE LECTURA NO VALIDO" << endl;
                    }
                    
                }
                else{
                    if(strcmp(args[1], "-o") == 0){
                        save_true = seq.saveFichero(args[2]);
                        if(save_true){
                            seq.readSecuenciasKmer();
                            
                            MakeKmer(seq);
                            
                            SuccesfulMessage(seq,args[2], save_true);
                        }
                        else{
                            cerr << "ERROR EN ARGUMENTO 2: FICHERO NO VALIDO" << endl;
                        }
                    }
                    else{
                        mensajeError();
                    }
                } 
            }
            else{
                if((strcmp(args[1], "-i") == 0) && (strcmp(args[3], "-o") == 0)){
                    load_true = seq.loadFichero(args[2]);
                    
                    if(load_true){
                        argumento = args[2];
                        save_true = seq.saveFichero(args[4]);
                        if(load_true && save_true){
                            MakeKmer(seq);
                            argumento = args[4];
                            cout << "GUARDANDO SECUENCIAS EN: " << argumento << endl << endl;
                            
                            SuccesfulMessage(seq,args[4],save_true);
                        }
                        else{
                            if(!save_true){
                                cerr << "ERROR EN ARGUMENTO 4: FICHERO DE SALIDA NO VALIDO" << endl;
                            }
                            if(!load_true){
                                cerr << "ERROR EN ARGUMENTO 2: FICHERO DE ENTRADA NO VALIDO" << endl;
                            }
                        }
                    }
                    else{
                        cerr << "ERROR EN ARGUMENTO 2: FICHERO NO VALIDO" << endl;
                    }
                }
                else{
                    if((strcmp(args[1], "-o") == 0) && (strcmp(args[3], "-i") == 0)){
                        load_true = seq.loadFichero(args[4]);
                        
                        if(load_true){
                            argumento = args[4];
                        
                            MakeKmer(seq);
                            save_true = seq.saveFichero(args[2]);
                            
                            if(save_true){
                                argumento = args[2];
                                cout << "GUARDANDO SECUENCIAS EN: " << argumento << endl << endl;
                                seq.saveFichero(args[2]);
                                
                                SuccesfulMessage(seq,args[2],save_true);
                            }
                            else{
                                cerr << "ERROR EN ARGUMENTO 2: FICHERO DE SALIDA NO VALIDO" << endl;
                            } 
                        }
                        else{
                            cerr << "ERROR EN ARGUMENTO 4: FICHERO DE ENTRADA NO VALIDO" << endl;
                        }
                    }
                    else{
                        mensajeError();
                    }
                }
            }
        }
    }
    return 0;
}

