/**
 * @file main.cpp
 * @author Daniel Pérez Ruiz
 * @version 5.0
 */
#include <iostream>
#include <string>
#include <cstring>
#include "Kmer.h"
#include "SecuenciasKmer.h"
#include "ContadorKmer.h"

using namespace std;

void mensajeError();

const string ContadorKmer::INI_VALIDOS = "_acgt";
const int ContadorKmer::INI_K=5;

int main(int narg, char *args[]) {
    ContadorKmer contador;
    SecuenciasKmer seq, seq_compare;
    double distancia = 1, distancia_minima = 2*distancia;
    int check_fallos = 0;
    string CAD = "*******************************************************************";
    char* sugerencia = nullptr;
    
    cout << "MP - ANALISIS Y CLASIFICACION DE SECUENCIAS DE ADN" << endl;
    cout << "VERSION: 5.0" << endl;
    cout << "AUTOR: DANIEL PEREZ RUIZ" << endl << endl;
    
    if(narg < 4){
        mensajeError();
    }
    else{
        if(strcmp(args[1],"-l") == 0){
            cout << CAD << endl << "MODO LEARN" << endl << CAD << endl << endl;
            cout << "Abriendo fichero [" << args[2] << "]..." << endl;
            if(seq.loadFichero(args[2])){
                contador.addPerfil(seq);
            }
            else{
                cout << "Creando fichero [" << args[2] << "] ..." << endl << endl;
                contador.addPerfil();
            }
            
            for(int i=4; i<=narg; i++){
                cout << "Abriendo fichero [" << args[i-1] << "] ..." << endl;
                
                if(contador.calcularFrecuenciasKmer(contador.getNumPerfiles()-1,args[i-1])){
                    seq = contador.getSecuenciasKmer(contador.getNumPerfiles()-1,1);
                }
                else{
                    cerr << endl << "ERROR. No se han podido procesar los datos del fichero [" << args[i-1] << "]" << endl << endl;
                    check_fallos++;
                }
            }
            
            if(check_fallos == (narg - 3)){
                cerr << endl << "ERROR. NO SE HA PROCESADO NIGUN ARCHIVO CORRECTAMENTE" << endl;
                cerr << "NO SE HA CREADO EL ARCHIVO >> [" << args[2] << "]" << endl;
            }
            else{
                cout << "Guardando fichero [" << args[2] << "]" << endl;
                seq.saveFichero(args[2]);
            }
        }
        else{
            if(strcmp(args[1],"-c") == 0){
                cout << CAD << endl << "MODO CLASIFY" << endl << CAD << endl;;
                
                contador.addPerfil();
                cout << "Abriendo fichero [" << args[2] << "] ..." << endl;
            
                if(contador.calcularFrecuenciasKmer(contador.getNumPerfiles()-1,args[2])){
                    seq = contador.getSecuenciasKmer(contador.getNumPerfiles()-1,1);
                    cout << "Obtencion de secuencia de [" << seq.getSize() << "] KMERS" << endl << endl;
                
                    cout << "OBTENIENDO DISTANCIAS..." << endl;
                    for(int i=4; i<=narg; i++){
                        if(seq_compare.loadFichero(args[i-1])){
                            distancia = seq.distancia(seq_compare);
                            cout << "[" << i-3 << ". " << args[i-1] << "] = " << distancia << endl << endl;
                           
                            if(distancia < distancia_minima){
                                distancia_minima = distancia;
                                sugerencia = args[i-1];
                            }  
                        }
                        else{
                            check_fallos++;
                        }
                    }
            
                    if(check_fallos == (narg-3)){
                        cerr << endl << "ERROR. NINGUN ARCHIVO SE HA LEIDO CON EXITO. EXITING..." << endl;
                    }
                    else{
                        cout << endl << "SUGERENCIA >> " << sugerencia << " [" << distancia_minima << "]" << endl;
                    }
                }
                else{
                    cerr << "ERROR. No se pudo procesar el fichero [" << args[2] << "]" << endl;
                }
            }
            else{
                mensajeError();
            }
        }
    }
    
    return 0;
}

void mensajeError() {
    cerr << "ERROR en la llamada" << endl;
    cerr << "   kmer [-l f.kmer fa.dna [fn.dna]] [-c f.dna fa.kmer [fn.kmer]]"<<endl;
    exit(1); 
}