/** 
 * @file ContadorKmer.cpp
 * @author Daniel Pérez Ruiz
 * @version 5.0
*/

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include <cctype>


#include "Kmer.h"
#include "SecuenciasKmer.h"
#include "ContadorKmer.h"

using namespace std;

/*
 * 1. GESTIÓN DE LA MEMORIA DINÁMICA
 */

void ContadorKmer::reservarMemoria(int nperfiles){
    if(_contador != nullptr){
        liberarMemoria();
    }
    _contador = new int* [nperfiles];
        
    for(int i=0; i<nperfiles; i++)
        _contador[i] = new int [_NKMER];
}

void ContadorKmer::liberarMemoria(){
    if(_contador != nullptr){
        for(int i=0;i<_nperfiles;++i)
            delete[] _contador[i];
        
        delete[] _contador;
        _contador = nullptr;
        _nperfiles = 0;
    }
}

/*
 * 2. CONSTRUCTORES DE LA CLASE
 */

ContadorKmer::ContadorKmer(){
    _contador = nullptr;
    _nperfiles = 0;
    _VALIDOS = INI_VALIDOS;
    _K = INI_K;
    _NKMER = getNumKmer();
}

ContadorKmer::ContadorKmer(const std::string& validos, int k){
    _contador = nullptr;
    _nperfiles = 0;
    _VALIDOS = validos;
    _K = k;
    _NKMER = getNumKmer();
}

ContadorKmer::ContadorKmer(const ContadorKmer& orig){
    copiar(orig);
}

ContadorKmer::~ContadorKmer(){
    liberarMemoria();
}

void ContadorKmer::copiar(const ContadorKmer & otro){
    _contador = nullptr;
    reservarMemoria(otro.getNumPerfiles());
    
    for(int i=0; i<otro.getNumPerfiles();i++){
        for(int j=0; j<otro.getNumKmer();j++){
            _contador[i][j] = otro._contador[i][j];
        }
    }
    
    _nperfiles = otro.getNumPerfiles();
    _VALIDOS = otro._VALIDOS;
    _K = otro._K;
    _NKMER = otro.getNumKmer();
    
}

/*
 * 3. SOBRECARGA OPERADOR ASIGNACIÓN
 */

ContadorKmer& ContadorKmer::operator =(const ContadorKmer& orig){
    if(&orig != this){
        liberarMemoria();
        copiar(orig);
    }
    
    return *this;
}

/*
 * 4. MÉTODOS PRIVADOS
 */

long ContadorKmer::getIndiceKmer(const Kmer& t) const{
    long indice = 0;
    char caracter;

    for(int i=0; i<_K;i++){
        caracter = t.getCadena()[_K-i-1];
        indice += _VALIDOS.find(caracter)*pow(_VALIDOS.size(),i);
    }
    
    return indice;
}

Kmer ContadorKmer::getIndiceInversoKmer(long i) const{
    Kmer km;
    int k=_K, posicion=0, indice=i, j=0;
    string cadena(_K,'_');
    
    while(k > 0){
        posicion = indice/(pow(_VALIDOS.size(),k-1));
        indice = indice - posicion*pow(_VALIDOS.size(),k-1);
        
        if(j<_K+1){
            cadena[j] = _VALIDOS[posicion];
        }
        
        k--;
        j++;
    }
    
    km.setCadena(cadena);
    
    return km;
}

Kmer ContadorKmer::normalizaKmer(const Kmer& ng) const  {
    Kmer _kmer_normalizado;
    string _kmer_copia=ng.getCadena(), _kmer_swap;
    int frecuencia_copia=ng.getFrecuencia(), j=0;
    bool caracter_valido = false;
    
    //AJUSTE DE LONGITUD DE KMER
    if(_kmer_copia.size() < _K){
        for(int x=_kmer_copia.size(); x<_K; x++){
            _kmer_copia += _VALIDOS[0];
        }
    }
    
    if(_kmer_copia.size() > _K){
        for(int y=0; y<_K; y++){
            _kmer_swap += _kmer_copia[y];
        }
        _kmer_copia = _kmer_swap;
    }
    
    //ELIMINA CARACTERES NO PERMITIDOS Y CAMBIA MAYÚS -> MINÚS EN CARÁCTER VÁLIDO
    for(int i=0; i<_kmer_copia.size();i++){
        while(j < _VALIDOS.size() && !caracter_valido){
            if(_kmer_copia[i] == _VALIDOS[j]){
                caracter_valido = true;
            }
            else{
                if(_kmer_copia[i] == toupper(_VALIDOS[j])){
                    _kmer_copia[i] = _VALIDOS[j];
                    caracter_valido = true;
                }
                j++;
            }
        }
        
        if(!caracter_valido){
            _kmer_copia[i] = _VALIDOS[0];
        }
        caracter_valido = false;
        j=0;
    }
    
    //CORRIGE FRECUENCIA
    if(frecuencia_copia < 0){
        frecuencia_copia = 0;
    }
    
    _kmer_normalizado.setCadena(_kmer_copia);
    _kmer_normalizado.setFrecuencia(frecuencia_copia);
    
    return _kmer_normalizado;
}

/*
 * 5. MÉTODOS DE INSERCIÓN
 */
void ContadorKmer::addPerfil(){
    ContadorKmer otro = *this;
    
    reservarMemoria(getNumPerfiles()+1);
    
    for(int k=0; k<getNumPerfiles()+1; k++){
        for(int j=0; j<getNumKmer(); j++){
            _contador[k][j] = 0;
        }
    }
    
    if(getNumPerfiles() != 0){
        for(int k=0; k<getNumPerfiles();k++){
            for(int j=0; j<getNumKmer(); j++){
                _contador[k][j] = otro._contador[k][j];
            }
        }
    }
    
    _nperfiles++;
}

void ContadorKmer::addPerfil(SecuenciasKmer perfil){
    addPerfil();
        
    for(int i=0; i<perfil.getSize();i++){
        _contador[getNumPerfiles()-1][getIndiceKmer(perfil.getPosicion(i))] = perfil.getPosicion(i).getFrecuencia();
    }
}

bool ContadorKmer::addKmer(int perfil, const Kmer& tg){
    bool respuesta = false;
    int indice = getIndiceKmer(tg);
    
    if( (perfil < getNumPerfiles()) && (indice < getNumKmer()) ){
        _contador[perfil][indice]++;
        respuesta = true;
    }
    
    if(!respuesta){
        cerr << "ERROR. No se ha podido insertar el Kmer en el perfil [" << perfil << "]" << endl;
    }
    
    return respuesta;
}

/*
 * 6. MÉTODOS CONSTANTES
 */
long ContadorKmer::getNumKmer() const{
    return pow(_VALIDOS.size(),_K);
}

int ContadorKmer::getNumPerfiles() const{
    return _nperfiles;
}

SecuenciasKmer ContadorKmer::getSecuenciasKmer(int perfil, int frecmin) const{
    int total_kmers = 0, k=0;
    bool posible = false;
    Kmer km;
    
    if(perfil < getNumPerfiles())
        posible = true;
    
    for(int j=0; j<getNumKmer() && posible;j++){
        if(_contador[perfil][j] >= frecmin)
            total_kmers++;
    }
        
    SecuenciasKmer secuencia(total_kmers);
    
    if(posible){
        for(int i=0; i<getNumKmer(); i++){
            if(_contador[perfil][i] >= frecmin){
                km = getIndiceInversoKmer(i);
                km.setFrecuencia(_contador[perfil][i]);
                secuencia.setPosicion(k,km);
                k++;
            }
        }
    }
    
    secuencia.ordenar();
    
    return secuencia;
}

/*
 * 7. CÁLCULO FRECUENCIAS
 */

bool ContadorKmer::calcularFrecuenciasKmer(int perfil, const char* nfichero){
    bool respuesta = false, first = false, check = true;
    ifstream fin;
    string cadena(_K,'_');
    int i=0, y=2, total_kmers=0;
    char caracter;
    Kmer km;
    
    fin.open(nfichero);
    if(fin){
        respuesta = true;
        while(fin && check){
            if(!first){
		fin >> cadena[i];
		i++;
		if(i == _K)
                    first = true;
            }
            else{
                total_kmers++;
		km.setCadena(cadena);
                check = addKmer(perfil,normalizaKmer(km));
                
		cadena[0] = cadena[1];
		for(int k=1; k<_K; k++){
                    if(y<_K){
			cadena[k] = cadena[y];
			y++;
                    }
                    else{
			fin >> caracter;
			cadena[_K-1] = caracter;
			y=2;
                    }
		}
				
            }
        }
        cout << "Procesados [" << total_kmers << "] Kmers" << endl << endl;
        fin.close();
    }
    else{
        cerr << "ERROR. NO SE HA PODIDO LEER EL FICHERO [" << nfichero << "]";
    }
    
    return respuesta;
}