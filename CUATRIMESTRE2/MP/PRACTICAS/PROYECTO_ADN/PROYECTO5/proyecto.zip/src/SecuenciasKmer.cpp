/** 
 * @file SecuenciasKmer.cpp
 * @author Daniel Pérez Ruiz
 * @version 5.0
*/

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>

#include "Kmer.h"
#include "SecuenciasKmer.h"

using namespace std;

/*
 * 1. ADMINISTRACIÓN DE LA MEMORIA DINÁMICA
 */

void SecuenciasKmer::reservarMemoria(long n){
    if(_conjunto != nullptr){
        liberarMemoria();
    }
    
    _conjunto = new Kmer[n];
    _nKmer = n;
}

void SecuenciasKmer::liberarMemoria(){
    if(_conjunto != nullptr){
        delete[] _conjunto;
        _conjunto = nullptr;
    }
    _nKmer = 0;
}


/*
 * 2. CONSTRUCTORES Y DESTRUCTORES DE LA CLASE
 */

SecuenciasKmer::SecuenciasKmer(){
    _conjunto = nullptr;
    _nKmer = 0;
}

SecuenciasKmer::SecuenciasKmer(long nkm){
    _conjunto = nullptr;
    reservarMemoria(nkm);
}

SecuenciasKmer::~SecuenciasKmer(){
    liberarMemoria();
}

SecuenciasKmer::SecuenciasKmer(const SecuenciasKmer& orig){
    copiar(orig);
}

void SecuenciasKmer::copiar(const SecuenciasKmer& otro){
    _conjunto = nullptr;
    reservarMemoria(otro._nKmer);
    
    for(int i=0; i<_nKmer;i++){
        _conjunto[i].setCadena(otro._conjunto[i].getCadena());
        _conjunto[i].setFrecuencia(otro._conjunto[i].getFrecuencia());
    }
}

/*
 * 3. SOBRECARGA OPERADOR =
 */

SecuenciasKmer& SecuenciasKmer::operator =(const SecuenciasKmer& orig){
    if(&orig != this){
        liberarMemoria();
        copiar(orig);
    }
    return *this;
}

/*
 * 4. MÉTODOS DE ADMINISTRACIÓN
 */

void SecuenciasKmer::setPosicion(long p, const Kmer& km){
    if(-1 < p && p < getSize()){
        _conjunto[p] = km;
    }
    else{
        cerr << "ERROR EN setPosicion: POSICION DE INSERCION NO PERMITIDA" << endl;
    }
}

Kmer SecuenciasKmer::getPosicion(long p) const{
    Kmer _copia_buscar;
    
    if(-1 < p && p < getSize()){
        _copia_buscar = _conjunto[p];
    }
    else{
        cerr << "ERROR EN getPosicion: POSICION NO PERMITIDA" << endl;
    }
    
    return _copia_buscar;
}

long SecuenciasKmer::findKmer(const std::string& km) const{
    long posicion = -1;
    bool encontrado = false;
    
    for(long i=0; i<getSize() && !encontrado; i++){
        if(_conjunto[i].getCadena() == km){
            encontrado = true;
            posicion = i;
        }
    }
    
    return posicion;
}

void SecuenciasKmer::ordenar(){
    Kmer km;
    
    for(int j=0; j<getSize()-1; j++){
        for(int i=j+1; i<getSize(); i++){
            if(_conjunto[j].getFrecuencia() < _conjunto[i].getFrecuencia()){
                km = _conjunto[i];
                _conjunto[i] = _conjunto[j];
                _conjunto[j] = km;
            }
        }  
    }
}

/*
 * 5. SOBRECARGA DE FLUJOS DE ENTRADA Y SALIDA
 */

ostream & operator<<(std::ostream & os, const SecuenciasKmer & i){
    os << i._nKmer << endl;
    
    for(int j=0; j< i.getSize(); j++){
        os << i.getPosicion(j).getCadena() << " " << i.getPosicion(j).getFrecuencia();
        os << endl;
    }
    
    return os;
} 


istream & operator>>(std::istream & is, SecuenciasKmer & i){
    int total_datos, kmer_frec;
    string kmer_chain;
    
    is >> total_datos;
    
    if(total_datos > 0){
        i.reservarMemoria(total_datos);
        
        for(int j=0; j<total_datos; j++){
            is >> kmer_chain >> kmer_frec;
            
            i._conjunto[j].setCadena(kmer_chain);
            i._conjunto[j].setFrecuencia(kmer_frec);
        }
    }
    
    return is;
}


/*
 * 6. GESTIÓN DE FICHEROS
 */

bool SecuenciasKmer::loadFichero(const char* fichero){
    bool respuesta = false;
    string magic_word;
    ifstream fin;
    
    fin.open(fichero);
    if(fin){
        fin >> magic_word;
        if(magic_word == MAGIC){
            fin >> *this;
            
            if(fin){
                cout << "SE HAN LEIDO CORRECTAMENTE [" << this->getSize() << "] KMERS DEL FICHERO [" << fichero << "]" << endl;
                respuesta = true;
            }
            else{
                cerr << "ERROR DE LECTURA DE KMERS DEL FICHERO [" << fichero << "]" << endl;
                liberarMemoria();
            }
        }
        else{
            cerr << "ERROR. FORMATO DE FICHERO [" << fichero << "] NO VALIDO. NO SE HA ENCONTRADO '" << MAGIC << "'" << endl;
        }
        fin.close();
    }
    else{
        cerr << "ERROR. EL FICHERO [" << fichero << "] NO EXISTE O ESTA CORRUPTO" << endl;
    }
    
    return respuesta;
}

bool SecuenciasKmer::saveFichero(const char* fichero) const{
    bool respuesta = false;
    ofstream fout;
    
    fout.open(fichero);
    if(fout){
        fout << MAGIC << endl;
        
        fout << *this;
        
        if(fout){
            cout << "SE HAN ESCRITO CORRECTAMENTE [" << getSize() << "] KMERS EN EL FICHERO [" << fichero << "]" << endl;
            respuesta = true;
        }
        else{
            cerr << "ERROR EN LA ESCRITURA DE KMERS EN EL FICHERO [" << fichero << "]" << endl;
        }
        fout.close();
    }
    else{
        cerr << "ERROR. EL FICHERO [" << fichero << "] NO EXISTE O ESTA CORRUPTO" << endl;
    }
    
    return respuesta;
}

double SecuenciasKmer::distancia(const SecuenciasKmer & d) const {
    long posB;
    long posA = 0;
    double dist = 0.0;

    for (long i = 0; i < this->getSize(); ++i) {
        posB = d.findKmer (getPosicion(i).getCadena());
        if (posB < 0) {
            posB = getSize();
        }

        dist += abs(posA - posB);
        posA++;
    }
    return dist / (getSize() * getSize()); 
}
