/**
 * @file main.cpp
 * @author Daniel Pérez Ruiz
 */
#include <iostream>
#include <string>
#include <cmath>
#include "Kmer.h"
#include "SecuenciasKmer.h"

using namespace std;

const int K=5; /// Número de genes en el Kmer
const string VALIDOS="_atgc"; /// Caracteres vaĺidos

long maxKmer();
Kmer normalizaKmer(const Kmer & km);
 
int main() {
    long nkm;
    Kmer kmer_introducir, kmer_normalizado;
    SecuenciasKmer seq;
    int date_count;
    
    do{
        cin >> nkm;
    }while(nkm < 0);
    
    for(int i=0; i<nkm; i++){
        kmer_introducir.readKmer();
        kmer_normalizado = normalizaKmer(kmer_introducir);
        seq.addKmer(kmer_normalizado);
    }
    /// ...
    cout << "Leyendo " << nkm << " Kmers"<<endl;
    /// ....
    cout << "Comprimiendo secuencia de Kmers ..."<<endl;
    seq.zipSecuenciasKmer();
    cout << "Ordenando secuencia de kmers ..." << endl;
    seq.ordenar();
    seq.writeSecuenciasKmer();
    return 0;
}

/**
 * @brief Calcula el número de combinaciones posibles de trigramas
 * @return Un entero largo
 */
long maxKmer()  {
    return pow(VALIDOS.size(),K);
}

/**
 * @brief Normaliza un Kmer. La longitud debe ser exactamente la fijada por @p K y cualquier carácter
 * ausente o nó @p VALIDO debe ser sustituido por el carácter comodín @p VALIDOS[0].
 * Igualmente, cualquier carácter @p VALIDO debe pasarse a minúscula. Finalmente, la frecuencia
 * debe ser >= 0
 * @param km El Kmer a normalizar
 * @return Una copia normalizada de @p km
 */
Kmer normalizaKmer(const Kmer & km)  {
    Kmer _kmer_normalizado;
    string _kmer_copia=km.getCadena(), _kmer_swap;
    int frecuencia_copia=km.getFrecuencia(), j=0;
    bool caracter_valido = false;
    
    //AJUSTE DE LONGITUD DE KMER
    if(_kmer_copia.size() < K){
        for(int x=_kmer_copia.size(); x<K; x++){
            _kmer_copia += VALIDOS[0];
        }
    }
    
    if(_kmer_copia.size() > K){
        for(int y=0; y<K; y++){
            _kmer_swap += _kmer_copia[y];
        }
        _kmer_copia = _kmer_swap;
    }
    
    //ELIMINA CARACTERES NO PERMITIDOS Y CAMBIA MAYÚS -> MINÚS EN CARÁCTER VÁLIDO
    for(int i=0; i<_kmer_copia.size();i++){
        while(j < VALIDOS.size() && !caracter_valido){
            if(_kmer_copia[i] == VALIDOS[j]){
                caracter_valido = true;
            }
            else{
                if(_kmer_copia[i] == toupper(VALIDOS[j])){
                    _kmer_copia[i] = VALIDOS[j];
                    caracter_valido = true;
                }
                j++;
            }
        }
        
        if(!caracter_valido){
            _kmer_copia[i] = VALIDOS[0];
        }
        caracter_valido = false;
        j=0;
    }
    
    //CORRIGE FRECUENCIA
    if(frecuencia_copia < 0){
        frecuencia_copia = 0;
    }
    
    _kmer_normalizado.setCadena(_kmer_copia);
    _kmer_normalizado.setFrecuencia(frecuencia_copia);
    
    return _kmer_normalizado;
}