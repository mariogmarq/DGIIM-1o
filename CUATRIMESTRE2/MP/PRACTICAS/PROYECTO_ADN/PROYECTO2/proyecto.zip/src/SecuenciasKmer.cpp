/** 
 * @file SecuenciasKmer.cpp
 * @author Daniel Pérez Ruiz
*/

#include <iostream>
#include <string>
#include "SecuenciasKmer.h"
#include "Kmer.h"

using namespace std;

SecuenciasKmer::SecuenciasKmer(){
    for(int i=0; i<_Max; i++){
        _conjunto[i].setCadena(" ");
        _conjunto[i].setFrecuencia(0);
    }
    _nKmer = 0;
}

bool SecuenciasKmer::addKmer(const Kmer& km){
    bool resultado = false;
    
    if(getSize() < _Max){
        _conjunto[getSize()] = km;
        _nKmer++;
        resultado = true;
    }
    
    return resultado;
}

Kmer SecuenciasKmer::getPosicion(long p) const{
    Kmer _copia_buscar;
    
    if(p < _Max){
        _copia_buscar = _conjunto[p];
    }
    else{
        cout << "ERROR: POSICION NO PERMITIDA" << endl;
    }
    
    return _copia_buscar;
}

void SecuenciasKmer::setPosicion(long p, const Kmer& km){
    if(p < _Max){
        _conjunto[p] = km;
    }
    else{
        cout << "ERROR: POSICION NO PERMITIDA" << endl;
    }
}

long SecuenciasKmer::findKmer(const std::string& km, long inicial) const{
    long posicion = 0;
    bool encontrado = false;
    
    for(int i=inicial; i<_Max && !encontrado; i++){
        if(_conjunto[i].getCadena() == km){
            encontrado = true;
            posicion = i;
        }
    }
    if(!encontrado){
        posicion = -1;
    }
    
    return posicion;
}

void SecuenciasKmer::ordenar(){
    Kmer kmer_swap;
    
    for(int i=0; i<getSize()-1;i++){
        for(int j=i+1; j<getSize(); j++){
            if(_conjunto[i].getFrecuencia() < _conjunto[j].getFrecuencia()){
                kmer_swap = _conjunto[i];
                _conjunto[i] = _conjunto[j];
                _conjunto[j] = kmer_swap;
            }  
        }

    }
}

void SecuenciasKmer::zipSecuenciasKmer(){
    int count = 0;
    Kmer vector[_Max];
    
    bool find = false, already_evaluate = false;
    string cadenaA, cadenaB;
    
    for(int i=0; i<_nKmer; i++){
        cadenaA = _conjunto[i].getCadena();
        
        for(int j=0; j<count && !already_evaluate; j++){
            cadenaB = vector[j].getCadena();
            
            if(cadenaA == cadenaB){
                already_evaluate = true;
            }
        }
        
        if(!already_evaluate){
            for(int j=i+1; j<_nKmer; j++){
                cadenaB = _conjunto[j].getCadena();
            
                if(cadenaA == cadenaB){
                    _conjunto[i].setFrecuencia(_conjunto[i].getFrecuencia() + _conjunto[j].getFrecuencia());
                }
            }
            
            vector[count] = _conjunto[i];
            count++;
            
            find = false;
        }
        
        already_evaluate = false;
    }
    
    if(count > 0){
        for(int i=0; i<count; i++){
            _conjunto[i] = vector[i];
        }
        _nKmer = count;
    }
    
    
}

void SecuenciasKmer::writeSecuenciasKmer(int frecmin) const{
    for(int i=0; i<_nKmer;i++){
        if(_conjunto[i].getFrecuencia() >= frecmin){
            _conjunto[i].writeKmer();
            cout << endl;
        }
    }
}