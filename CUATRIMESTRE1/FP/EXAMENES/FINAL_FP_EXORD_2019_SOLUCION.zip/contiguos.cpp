#include<iostream>
using namespace std;

class SecuenciaCaracteres{
private:
    static const int TAMANIO = 100;
    char vector_privado[TAMANIO];
    int total_utilizados;
public:
    SecuenciaCaracteres();
    SecuenciaCaracteres(char v[], int t);
    int TotalUtilizados();
    int Capacidad();
    void Aniade(char nuevo);
    char Elemento(int indice);
    bool Contiguos (char izda, SecuenciaCaracteres dcha);
    bool SeEncuentra (char izda);
    int Esta(int indice_dcha, SecuenciaCaracteres dcha);
};

/*------------------------------------------*/
/* Metodos implementados para hacer el main */
/*------------------------------------------*/
SecuenciaCaracteres::SecuenciaCaracteres(){
    total_utilizados = 0;
}

SecuenciaCaracteres::SecuenciaCaracteres(char v[], int t){
    total_utilizados = t;
    for (int i=0;i<total_utilizados;i++)
        vector_privado[i] = v[i];
}

void SecuenciaCaracteres::Aniade(char nuevo){
    if (total_utilizados < TAMANIO ){
        vector_privado[total_utilizados] = nuevo;
        total_utilizados++;
    }
}
/*------------------------------------*/


bool SecuenciaCaracteres::SeEncuentra (char izda){
    bool salida = false;
    
    for (int i=0; i<total_utilizados && !salida; i++)
        if ( vector_privado[i] == izda )
            salida = true;
    
    return salida;
}

int SecuenciaCaracteres::Esta(int indice_dcha, SecuenciaCaracteres dcha){
    bool encontrado = false;
    int inicio = -1;
    
    for (int i=indice_dcha; i<total_utilizados && !encontrado; i++){
        encontrado = true;
        for (int j=0; j<dcha.total_utilizados && encontrado; j++)
            if ( vector_privado[i+j] != dcha.vector_privado[j])
                encontrado = false;
        
        if (encontrado)
            inicio = i;
    }
    
    return inicio;
}


bool SecuenciaCaracteres::Contiguos (char izda, SecuenciaCaracteres dcha){
    bool contiguo = false;
    
    if (!dcha.SeEncuentra (izda)){
        int indice_comienzo = 0;
        
        while ( vector_privado[indice_comienzo] != izda && indice_comienzo < total_utilizados )
            indice_comienzo++;
        
        
        if (indice_comienzo < total_utilizados){
            int indice_izda = indice_comienzo;
            int indice_dcha = indice_comienzo;
            
            bool terminar = false;
            
            while (!terminar){
                indice_dcha = Esta(indice_dcha, dcha);
                if ( indice_dcha!= -1){
                    indice_dcha = indice_dcha + dcha.total_utilizados;
                
                    indice_izda++;
                    while ( vector_privado[indice_izda] != izda && indice_izda < total_utilizados )
                        indice_izda++;
                
                    if ( indice_izda > indice_dcha )
                        indice_dcha = indice_izda;
                    
                    if ( total_utilizados <= indice_izda ){
                        terminar = true;
                        contiguo = true;
                    }
                }
                else
                    terminar = true;
            }
        }
    }
    
    return contiguo;
}
    




int main(){
    char v[]={'a', '_', 'T', 'T', 'U', '_', 'a', 'T', 'T', 'U'};
    SecuenciaCaracteres sec(v,10);
    
    char v2[]={'a', '_','a','_', 'T', 'T', 'U', 'T', 'T', 'U'};
    SecuenciaCaracteres sec2(v2,10);
    
    char v3[]={'a','_', 'T', 'T', 'U','_','_', 'T', 'T', 'U','a'};
    SecuenciaCaracteres sec3(v3,11);
    
    char v4[]={'a', '_','a','_', 'T', 'T', 'U', 'T', 'T', '_'};
    SecuenciaCaracteres sec4(v4,10);
    
    char d[]={'T','T','U'};
    SecuenciaCaracteres dcha(d,3);
    
    
    cout << sec.Contiguos('a',dcha) << sec2.Contiguos('a',dcha) << endl;
    cout << sec3.Contiguos('a',dcha) << sec4.Contiguos('a',dcha) << endl;
}

