#include<iostream>
using namespace std;

int main(){
    int v[]={4,1,3,9,2};
    int longitud = 5;
    int T = 14;
    
    int suma = 0, indice = -1;
    int longitud_secuencia = 0; // Para calcular longitud de la secuencia, si existe.
                                 //   No se pide en el examen
    int j = 0;
    bool salida = false;
    
    
    /* Algoritmo
     * En cada posicion del vector:
     *  suma los valores de esa posicion en adelante hasta que el acumulado no es menor que T
     *  si la suma es T, se sale del bucle y se devuelve la posicion de comienzo
     *  si no, sigue
     */
    for (int i = 0; i<longitud && !salida; i++){
        suma = 0;
        j = i;
        
        while ( suma < T && j<longitud){
            suma = suma + v[j];
            j++;
        }
        
        if (suma == T){
            salida = true;
            indice = i;
            longitud_secuencia = j-i;
        }
    }
    
    cout << indice << " " << longitud_secuencia << endl;
}

