#include<iostream>
using namespace std;

class SecuenciaADN{
private:
    static const int MAXLONGITUD = 100;
    char secuencia[MAXLONGITUD];
    int longitud;
public:
    SecuenciaADN();
    int Longitud();
    int MaxLongitud();
    void Aniade(char nucleotido);
    char Nucleotido(int indice);
};

class TablaSecuenciasADN{
private:
    static const int CAPACIDAD = 2000;
    SecuenciaADN tabla[CAPACIDAD];
    int longitud_secuencia;
    int total_secuencias;
public:
    TablaSecuenciasADN(int longitud secuencia);
    int TotalSecuencias();
    int Capacidad();
    void Aniade(SecuenciaADN secADN);
    SecuenciaADN SecADN(int indice);
};


/* Ejercicio 1 */
SecuenciaADN SecuenciaConsenso(){
    SecuenciaADN consenso;
    
    char nucleotidos[4]={'G','T','C','A'};
    int frecuencias[4]={0,0,0,0};
    
    for (int j=0; j<longitud_secuencia; j++){
        for (int i=0; i<total_secuencias; i++){
            switch ( tabla[i].Nucleotido(j) ) {
                case 'G':
                    frecuencia[0]++;
                    break;
                case 'T':
                    frecuencia[1]++;
                    break;
                case 'C':
                    frecuencias[2]++;
                    break;
                case 'A':
                    frecuencias[3]++;
                    break;
            }
        }
        
        int mayor = 0;
        for (int k=1; k<4; k++)
            if (frecuencias[k] > frecuencias[mayor] )
                mayor = k;
        
        consenso.Aniade(nucleotidos[mayor]);
        
        frecuencia[0] = frecuencia[1] = frecuencia[2] = frecuencia[3] = 0;
    }
    
    return consenso;
}


/* Ejercicio 2 */
bool MismoConsenso (TablaSecuenciasADN otra){
    bool consenso = false;
    
    if ( longitud_secuencia == otra.longitud_secuencia ){
        consenso = true;
        
        SecuenciaADN sec1 = SecuenciaConsenso();
        SecuenciaADN sec2 = otra.SecuenciaConsenso();
        
        for (int i=0; i<longitud_secuencia; i++)
            if ( sec1.Nucleotido(i) != sec2.Nucleotido(i) )
                consenso = false;
    }
    
    return consenso;
}


/* Ejercicio 3 */

int SecuenciaADN::distanciaHamming (SecuenciaADN s){
    int distancia = 0;
    for (int i=0; i<longitud; i++)
        if ( Nucleotido(i)!= s.Nucleotido(i) )
            distancia++;
    
    return distancia;
}

SecuenciaADN SecuenciaInconexa (){
    int maximo = 0;
    int distancia = 0;
    int indice = 0;
    SecuenciaADN consenso = SecuenciaConsenso();
    
    for (int i=0; i<total_secuencias; i++){
        distancia = consenso.distanciaHamming(tabla[i]);
        if ( distancia > maximo ){
            maximo = distancia;
            indice = i;
        }
    }
    return tabla[indice];
}
