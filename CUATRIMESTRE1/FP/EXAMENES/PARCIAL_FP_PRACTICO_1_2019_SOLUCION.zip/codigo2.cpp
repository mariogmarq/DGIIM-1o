#include <iostream>

using namespace std;

int main(){
    
    const char TERMINADOR = '@';
    const char INICIO_FIN_TRANSMISION = '#';
    
    char caracter;
    int primer_digito, segundo_digito, tercer_digito, cuarto_digito, quinto_digito;
    primer_digito = segundo_digito = tercer_digito = cuarto_digito = quinto_digito = 0;
    int transmision = 0;
    
    
    cin >> caracter;
    
    // HASTA INTRODUCIR @
    // SE INCREMENTA TRANSMISION SI CARACTER ES #
    // SI TRANSMISION ES MAYOR QUE CERO (DESPUES DE LA PRIMERA ALMOHADILLA)
    // SE CONTABILIZAN LAS VOCALES INCREMENTANDO LAS VARIABLES CONTADORAS
    // SI ADEMÁS, ES MAYOR QUE UNO, SE HA TERMINADO UN CODIGO: SE MUESTRA Y REINICIAN LAS
    // VARIABLES CONTADORAS
    while ( caracter != TERMINADOR ){
        
        if ( caracter == INICIO_FIN_TRANSMISION )
            transmision++;
        
        if ( transmision > 0 ){
            switch ( caracter ) {
                case 'a':
                    primer_digito++;
                    break;
                case 'e':
                    segundo_digito++;
                    break;
                case 'i':
                    tercer_digito++;
                    break;
                case 'o':
                    cuarto_digito++;
                    break;
                case 'u':
                    quinto_digito++;
                    break;
                case '#':
                    if (transmision > 1){
                        cout << "ID: " << primer_digito << segundo_digito << tercer_digito << cuarto_digito << quinto_digito << "\n";
                        primer_digito = segundo_digito = tercer_digito = cuarto_digito = quinto_digito = 0;
                    }
            }
        }
        cin >> caracter;
    }
    
    // CASO EXTREMO. SI SOLO SE HA ENVIADO UNA O NINGUNA ALMOHADILLA, SE DEVUELVE CERO
    if ( transmision < 2 ){
        primer_digito = segundo_digito = tercer_digito = cuarto_digito = quinto_digito = 0;
        cout << "ID: " << primer_digito << segundo_digito << tercer_digito << cuarto_digito << quinto_digito << "\n";
    }

}

