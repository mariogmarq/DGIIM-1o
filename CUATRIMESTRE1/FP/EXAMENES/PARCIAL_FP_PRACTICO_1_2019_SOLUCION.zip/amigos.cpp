#include <iostream>

using namespace std;

int main(){
    
    int primer_entero, segundo_entero, suma_primero = 0, suma_segundo = 0;
    bool amigos;
    
    cin >> primer_entero;
    cin >> segundo_entero;

    for (int i = 1; i < primer_entero; i++)
        if ( primer_entero % i == 0 )
            suma_primero = suma_primero + i;
    
    /* Otra forma más eficiente, pero el código es menos claro.
    
    amigos = suma_primer == segundo_entero;
    
    if ( amigos ){
        for (int j = 1; j < segundo_entero; j++)
            if ( segundo_entero % j == 0 )
                suma_segundo = suma_segundo + j;
        
        amigos = suma_segundo == primer_entero;
    }
    
    if ( amigos )
        cout << "\nSon amigos\n";
    else
        cout << "\nNo son amigos\n";
    */
    
    for (int j = 1; j < segundo_entero; j++)
        if ( segundo_entero % j == 0 )
            suma_segundo = suma_segundo + j;
    
    amigos = suma_primero == segundo_entero && suma_segundo == primer_entero;
    
    if ( amigos )
        cout << "\nSon amigos\n";
    else
        cout << "\nNo son amigos\n";
    
}

