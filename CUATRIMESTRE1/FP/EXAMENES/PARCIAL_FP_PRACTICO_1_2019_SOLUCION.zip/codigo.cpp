#include <iostream>

using namespace std;

int main(){
    
    const char TERMINADOR = '@';
    const char INICIO_FIN_TRANSMISION = '#';
    
    char caracter;
    int primer_digito, segundo_digito, tercer_digito, cuarto_digito, quinto_digito;
    primer_digito = segundo_digito = tercer_digito = cuarto_digito = quinto_digito = 0;
    int transmision = 0;
    
    
    cin >> caracter;
    
    // HASTA INTRODUCIR @
    // SE COMPRUEBA SI EL CARACTER ES #. EN ESE CASO SE INCREMENTA TRANSMISION
    // SI TRANSMISION ES 1, DESPUES DE LA PRIMERA ALMOHADILLA Y ANTES DE LA SEGUNDA,
    // SE CONTABILIZAN LAS VOCALES INCREMENTANDO LAS VARIABLES CONTADORAS
    while ( caracter != TERMINADOR ){
        
        if ( caracter == INICIO_FIN_TRANSMISION )
            transmision++;
        
        if ( transmision == 1 ){
            switch ( caracter ) {
                case 'a':
                    primer_digito++;
                    break;
                case 'e':
                    segundo_digito++;
                    break;
                case 'i':
                    tercer_digito++;
                    break;
                case 'o':
                    cuarto_digito++;
                    break;
                case 'u':
                    quinto_digito++;
            }
        }
        cin >> caracter;
    }
    
    // SI SOLO SE HA ENVIADO UNA #, SE ELIMINAN LAS RECEPCIONES
    if ( transmision == 1 )
      primer_digito = segundo_digito = tercer_digito = cuarto_digito = quinto_digito = 0;
    
    
    cout << "ID: " << primer_digito << segundo_digito << tercer_digito << cuarto_digito << quinto_digito << "\n";

}

