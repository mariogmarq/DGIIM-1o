#include <iostream>

using namespace std;

int main(){
    
    int primer_entero, segundo_entero, cifra, contador, numero;
    
    cin >> primer_entero;
    cin >> segundo_entero;
    
    while ( primer_entero > segundo_entero )
        cin >> segundo_entero;
    
    cin >> cifra;
    
    while ( cifra < 0 || cifra > 9)
        cin >> cifra;
    
    contador = 0;
    
    for ( int i = primer_entero; i <= segundo_entero; i++ ){
        
        if ( i < 0 )
            numero = -i;
        else
            numero = i;
        
        if ( numero == 0 && cifra == 0)
            contador++;
    
        while ( numero != 0 ){
            if ( numero % 10 == cifra )
                contador ++;
        
            numero = numero / 10;
        }
    }
    
    cout << "\nEl numero de apariciones es: " << contador << "\n";
    
}
    

