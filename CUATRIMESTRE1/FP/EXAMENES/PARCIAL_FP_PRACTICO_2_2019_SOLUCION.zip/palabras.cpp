#include <iostream>
#include <string>

using namespace std;


/**
 *@brief determina si dos palabras son iguales siguiendo el criterio:
 *                  - La primera y ultima letra son iguales
 *                  - El resto de letras son las mismas aunque en cualquier otro orden
 *@param palabra1 la primera palabra a analizar
 *@param palabra2 la segunda palabra a analizar
 *@pre las cadenas de caracteres no deben tener espacios en blanco, deben ser palabras
 *@return true si son iguales, false si no
 */
bool palabras_casi_iguales ( string palabra1, string palabra2 );
/**
 *@brief ordena una palabra desde la segunda letra a la penultima segun valor ASCII
 *@param palabra Es la palabra a ordenar
 *@pre No debe tener espacios en blanco
 *@retval la palabra ordenada
 */
string  Ordenar ( string palabra );

int main(){
    bool iguales;
    string palabra1;
    string palabra2;
    cin >> palabra1 >> palabra2;
    
    iguales = palabras_casi_iguales (palabra1,palabra2);
    
    if ( iguales )
        cout << "\nSon iguales\n";
    else
        cout << "\nNo son iguales\n";
}

string Ordenar ( string palabra ){
    /*  Algoritmo: Ordenacion por seleccion (valor ASCII) de la subcadena
     * entre las componentes segunda y penultima
     */
    int minimo = 1;
    int maximo = palabra.length()-2;
    int posicion;
    char intercambio;
    
    for (int i=minimo; i<maximo; i++){
        posicion = i;
        for (int j=i+1; j<maximo; j++)
            if ( palabra[j] < palabra[posicion] )
                posicion = j;
        
        intercambio = palabra[posicion];
        palabra[posicion] = palabra[i];
        palabra[i] = intercambio;
    }
    
    return palabra;
}

bool palabras_casi_iguales ( string palabra1, string palabra2 ){
    /* Algoritmo
     * Ordena las palabras en orden alfabetico desde la segunda a la penultima letra
     * Compara si las palabras resultantes son iguales
     */
    bool casi_iguales = palabra1.length() == palabra2.length();
    
    if ( casi_iguales )
        casi_iguales = Ordenar(palabra1) == Ordenar(palabra2);

    return casi_iguales;
}
