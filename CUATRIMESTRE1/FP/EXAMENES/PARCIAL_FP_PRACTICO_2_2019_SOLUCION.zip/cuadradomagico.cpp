#include <iostream>

using namespace std;

const int TAMANO_MAXIMO = 11;

/**
 *@brief determina si una matriz de enteros forma un cuadrado mágico
 *@param matriz es la matriz a analizar
 *@param filas_utiles son las filas de matriz
 *@param columnas_utiles son las columnas de la matriz
 *@pre filas_utiles y columnas_utiles deben ser menor que la constante TAMANO_MAXIMO
 *@pre filas_utiles y columnas_utiles deben ser enteros positivos
 *@return true si es un cuadrado magico, false si no. Devuelve false para tamaños no permitidos
 */
bool es_cuadrado_magico ( int matriz[][TAMANO_MAXIMO], int filas_utiles, int columnas_utiles);

int main(){
    int matriz[TAMANO_MAXIMO][TAMANO_MAXIMO];
    int filas_utiles, columnas_utiles;
    
    cout << "\nIntroduce filas y columnas: ";
    cin >> filas_utiles >> columnas_utiles;
    
    cout << "\nIntroduce la matriz: ";
    for ( int fila=0; fila<filas_utiles; fila++)
        for ( int columna=0; columna<columnas_utiles; columna++)
            cin >> matriz[fila][columna];

    bool cuadradomagico = es_cuadrado_magico ( matriz, filas_utiles, columnas_utiles);
    
    if (cuadradomagico)
        cout << "\nEs un cuadrado magico\n";
    else
        cout << "\nNo es un cuadrado magico\n";
}

bool es_cuadrado_magico ( int matriz[][TAMANO_MAXIMO], int filas_utiles, int columnas_utiles){
    bool es_magico = (filas_utiles == columnas_utiles) && (filas_utiles % 2 != 0);
    es_magico = es_magico && (filas_utiles <= TAMANO_MAXIMO) && (filas_utiles > 0);
    int suma_comun = 0;
    int suma = 0;
    
    if ( es_magico ){
        for ( int columna=0; columna<columnas_utiles; columna++)
            suma_comun = suma_comun + matriz[0][columna];
        for ( int fila=1; fila<filas_utiles && es_magico; fila++){
            suma = 0;
            for ( int columna=0; columna<columnas_utiles && es_magico; columna++)
                suma = suma + matriz[fila][columna];
            if ( suma != suma_comun )
                es_magico = false;
        }
        
        for ( int columna=0; columna<columnas_utiles && es_magico; columna++){
            suma = 0;
            for ( int fila=0; fila<filas_utiles && es_magico; fila++)
                suma = suma + matriz[fila][columna];
            if ( suma != suma_comun )
                es_magico = false;
        }
        
        suma = 0;
        for ( int diagonal=0; diagonal<columnas_utiles && es_magico; diagonal++)
            suma = suma + matriz[diagonal][diagonal];
        if ( suma != suma_comun )
            es_magico = false;
        
        suma = 0;
        for ( int diagonal=0; diagonal<columnas_utiles && es_magico; diagonal++)
            suma = suma + matriz[diagonal][filas_utiles-diagonal-1];
        if ( suma != suma_comun )
            es_magico = false;
    }
    return es_magico;
}
