#include <iostream>

using namespace std;

/**
 *@brief Un objeto de la clase Racional representa un numero racional r
 * mediante dos numeros enteros a y b, que representan el denominador y el
 * numerador, respectivamente, de la fraccion r=a/b, donde a y b son coprimos.
 */
class Racional{
private:
    int numerador; /**< Numerador de la fraccion */
    int denominador; /**< Denominador de la fraccion */
    //Estas serian otras posibilidades, con numerador y denominador siempre positivos
    // int signo;
    // bool signo;
    /**
     *@brief cambia una fraccion a su forma irreducible
     */
    void FraccionIrreducible();
public:
    /**
     *@brief Constructor por defecto
     *@post inicializa el objeto al racional 0=0/1;
     */
    Racional();
    /**
     *@brief Constructor con parametros
     *@param num Numerador del racional
     *@param den Denominador del racional
     *@pre den debe ser distinto de cero
     *@post Si se introduce denominador nulo, se inicializa a 0
     *@post Si la fraccion es irreducible, la convierte a irreducible
     */
    Racional( int num, int den );
    /**
     *@brief Determina si un racional es menor que otro
     *@param otro el racional con el que comparar
     *@retval true, si es menor que otro, false en caso contrario
     */
    bool Menor( Racional otro );
    /**
     *@brief Muestra por pantalla el numero racional hasta un cierto numero de decimales
     *@param precision El numero de decimales a mostrar
     *@pre precision debe ser mayor que cero. Si no lo fuera, se asume con valor 1.
     */
    void MostrarRacional ( int precision );
};

int main(){
    Racional trescuartos(3,4);
    Racional cuatroquintos(-8,10);
    
    cout << "3/4 es menor que 4/5: ";
    if ( trescuartos.Menor(cuatroquintos) )
        cout << "Si\n";
    else
        cout << "No\n";
    
    
    trescuartos.MostrarRacional(5);
    cuatroquintos.MostrarRacional(0);

    Racional periodico (1,3);
    periodico.MostrarRacional(5);
    
    Racional grande(100,3);
    grande.MostrarRacional(20);
}


Racional::Racional(){
    numerador = 0;
    denominador = 1;
}

Racional::Racional( int num, int den ){
    /*
     * Restringimos a denominadores positivos siempre,
     * así podemos suponerlo en las siguientes funciones
     * No se permite un denominador nulo
     */
    if ( den != 0 ){
        if ( den < 0 ){
            numerador = -num;
            denominador = -den;
        }
        else{
            numerador = num;
            denominador = den;
        }
    }
    else{
        numerador = 0;
        denominador = 1;
    }
    
    // Transformamos a su fraccion irreducible
    FraccionIrreducible();
}

void Racional::FraccionIrreducible(){
    
    int num = numerador, den = denominador;
    if ( numerador < 0 )
        num = - numerador;
    
    /* Algoritmo:
        - Calcular MCD de ambos enteros
        - Dividir por el MCD
     */
    int resto = num % den;
    while ( resto != 0 ){
        num = den;
        den = resto;
        resto = num % den;
    }
    
    numerador = numerador / den;
    denominador = denominador / den;
}


bool Racional::Menor( Racional otro ){
    /**
     *  si no hubieramos forzado a denominadores positivos
     *
    bool es_menor;
    bool signo_producto = (denominador * otro.denominador) > 0;
    
    if ( signo_producto )
        es_menor = ( numerador * otro.denominador ) < ( otro.numerador * denominador );
    else
        es_menor = ( numerador * otro.denominador ) > ( otro.numerador * denominador );
    
    return es_menor;
    */
    bool es_menor = (numerador * otro.denominador) < (otro.numerador * denominador);
    return es_menor;
}

void Racional::MostrarRacional ( int precision ){
    int num, den, digito;
    
    // Comprobacion de la precondicion
    if ( precision <= 0 )
        precision = 1;
    
    // Si no forzamos denominadores positivos, hay que distinguir mas casos
    if ( numerador < 0 ){
        cout << "-";
        num = -numerador;
    }
    else{
        cout << "+";
        num = numerador;
    }
    den = denominador;
    
    /* Algoritmo: Para cada digito hasta la precision:
                    - Se hace division entera entre num y den, y se muestra
                    - Se resta el resultado a la fraccion y se multiplica por 10
     */
    digito = num / den;
    cout << digito << ".";
    num = ( num - den * digito ) * 10;
    
    for (int i=0; i<precision; i++){
        digito = num / den;
        cout << digito;
        num = ( num - den * digito ) * 10;
    }
    cout << "\n";
}
