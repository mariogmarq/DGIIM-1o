/* Se requiere implementar la clase Multiconjunto con U={1, 2, ..., 1000}. Observe que no es necesario representar explícitamente todas las repeticiones de cada valor. Asi pues, en vez de representar el multiconjunto {5,5,5,3,3,2} como una secuencia de enteros repetidos, resulta mas conveniente trabajar con la multiplicidad de cada valor del universo U. Por lo tanto, para representar el anterior multiconjunto basta con considerar cada valor del dominio (5, 3, 2) y sus multiplicidades asociadas (3,2,1). Se pide lo siguiente.  Suponga definida la clase SecuenciaEnteros (véase final ejercicio).

a) Defina los datos miembro de la clase y los constructores que estime oportunos.
b) Implemente un metodo para obtener la multiplicidad de un numero perteneciente a U en un multiconjunto y un metodo para añadir un elemento x al multiconjunto con cierta multiplicidad k. Si el elemento ya existe en el multiconjunto, se incrementara su multiplicidad en k.
c) Diseñe metodos que implementen las tres operaciones definidas con anterioridad (soporte, inclusión e intersección). El soporte devolvera un objeto de la clase SecuenciaEnteros, la inclusión un bool y la interseccion un objeto de la clase Multiconjunto.
 d) Implemente un metodo que devuelva un objeto de la clase SecuenciaEnteros con todos los elementos de un multiconjunto. No se requiere que esten ordenados. Para el ejemplo anterior, se devolveria {5,5,5,3,3,2}.
 */

class SecuenciaEnteros{
private:
    static const int TAMANIO = 100;
    int vector_privado[TAMANIO];
    int total_utilizados;
public:
    SecuenciaEnteros();
    int TotalUtilizados();
    int Capacidad();
    void Aniade(int nuevo);
    int Elemento (int indice);
};

/* Apartado a (0.5 puntos) */

class Multiconjunto{
private:
    static const int MAX = 1001; /**< Tamanno del vector de multiplicidades, se desperdicia la primera componente, pero es mas comodo el codigo */
    int multiplicidad[MAX]; /**< Vector con las multiplicidades de los elementos */
public:
    Multiconjunto ();
    int Multiplicidad (int);
    void Aniadir (int,int);
    SecuenciaEnteros Soporte ();
    bool Contenido ( Multiconjunto );
    Multiconjunto Interseccion ( Multiconjunto );
    SecuenciaEnteros TodosRepetidos ();
};

//solo es necesario implementar este constructor, por la funcion interseccion
// inicializa al conjunto vacio
Multiconjunto::Multiconjunto(){
    for (int i=0; i<MAX; i++)
        multiplicidad[i] = 0;
}

/* Apartado b. (0.75 puntos) */

void Multiconjunto::Aniadir (int elemento, int mult ){
    if ( elemento > 0 && elemento < 1001 && mult > 0) // Esto tampoco era necesario comprobarlo
        multiplicidad[elemento] = multiplicidad[elemento] + mult;
}

int Multiconjunto::Multiplicidad (int elemento){
    if ( elemento > 0 && elemento < 1001) // Esto tampoco era necesario comprobarlo
        return multiplicidad[elemento];
    return 0;
}


/** Observese que las funciones siguientes NO dependen de la representacion (los datos miembro elegidos) de la clase, ni de la implementacion del calculo de la multiplicidad ni de la funcion para añadir elementos. Por tanto, estas implementaciones son validas independientemente de lo que se haya implementado (correctamente) antes.
 **/

/* Apartado c. (0.5 puntos) Devolver el soporte, los elementos con multiplicidad positiva, en un objeto de la clase SecuenciaEnteros */

SecuenciaEnteros Multiconjunto::Soporte (){
    SecuenciaEnteros soporte;
    
    for (int elemento=1; elemento <= 1000; elemento++)
        if ( Multiplicidad(elemento) > 0 )
            soporte.Aniadir(elemento);
    
    return soporte;
}

/* Apartado c. (0.5 puntos)  Determinar si un objeto Multiconjunto esta contenido en otro */

bool Multiconjunto::Contenido ( Multiconjunto otro ){
    bool contenido = true;
    
    for (int elemento=1; elemento <= 1000; elemento++)
        if ( Multiplicidad(elemento) > otro.Multiplicidad(elemento) )
            contenido = false;
    
    return contenido;
}

/* Apartado c. (0.5 puntos)  Devolver la interseccion de dos Multiconjuntos */

Multiconjunto Multiconjunto::Interseccion ( Multiconjunto otro ){
    Multiconjunto interseccion;
    int minimo = 0;
    
    for (int elemento=1; elemento <= 1000; elemento++){
        minimo = Multiplicidad(elemento);
        if ( minimo > otro.Multiplicidad(elemento) )
            minimo = otro.Multiplicidad(elemento);
        interseccion.Aniadir(elemento,minimo);
    }
    
    return interseccion;
}

/* Apartado d. (0.75 puntos) Devolver el multiconjunto como tal, es decir, con los elementos repetidos, en un objeto de la clase SecuenciaEnteros
 */

SecuenciaEnteros Multiconjunto::TodosRepetidos (){
    SecuenciaEnteros todos;
    
    for (int elemento=1; elemento <= 1000; elemento++)
        for (int j=0; j<Multiplicidad(elemento); j++)
            todos.Aniadir(elemento);
    
    return todos;
}

