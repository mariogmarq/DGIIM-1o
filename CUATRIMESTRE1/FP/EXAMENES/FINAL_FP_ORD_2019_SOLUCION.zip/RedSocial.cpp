/* Implementar una clase RedSocial para gestionar una red social. La red debe almacenar los nombres de los usuarios y las relaciones de amistad. Se propone la siguiente representacion:

class RedSocial{
private:
    static const int MAXIMO_USUARIOS = 100;
    string Usuarios[MAXIMO_USUARIOS];
    bool RelacionesAmistad[MAXIMO_USUARIOS][MAXIMO_USUARIOS];
    int usuarios_utiles;
public:
    void HacerAmigos(string usr1, string usr2);     // Metodos que NO hay que implementar
    void DeshacerAmigos(string usr1, string usr2);  // y se pueden usar
    bool SonAmigos(string usr1, string usr2);
    bool Existe(string usr);
    ...
};

donde RelacionesAmistad es una matriz binaria tal que la componente (i,j) es true, si el usuario i es amigo del usuario j, y false, en otro caso. Asumiremos que las relaciones de amistad son simetricas, lo que implica que la matriz binaria tambien lo es.

Se pide implementar, al menos, los siguientes métodos (los usuarios vienen especificados por sus nombres):

a) Un metodo que, dado un usuario A de la red, sugiera un amigo potencial para A. Un amigo potencial es aquel usuario de la red (no amigo de A) que tiene mas amigos en comun con A.
b) Un metodo que decida si dos usuarios son amigos circunstanciales, es decir, si son amigos pero no tienen amigos en comun.

Implemente cualquier otro metodo adicional, publico o privado, que considere util.
 */

class RedSocial{
private:
    static const int MAXIMO_USUARIOS = 100;
    string Usuarios[MAXIMO_USUARIOS];
    bool RelacionesAmistad[MAXIMO_USUARIOS][MAXIMO_USUARIOS];
    int usuarios_utiles;
public:
    void HacerAmigos(string usr1, string usr2);
    void DeshacerAmigos(string usr1, string usr2);
    bool SonAmigos(string usr1, string usr2);
    bool Existe(string usr);
    int NumeroAmigosComunes (string user1, string user2);
    string AmigoPotencial (string user);
    bool AmigosCircunstanciales (string user1, string user2);
};

/* Metodo auxiliar para calcular el numero de amigos comunes entre dos usuarios */

int RedSocial::NumeroAmigosComunes (string user1, string user2){
    int contador = 0;
    
    for (int i=0; i<usuarios_utiles; i++)
        if ( user1 != Usuarios[i] && user2!= Usuarios[i] )
            if ( SonAmigos(Usuarios[i],user1) && SonAmigos(Usuarios[i],user2) )
                contador++;
    
    return contador;
}

/* Apartado a */

string RedSocial::AmigoPotencial (string user){
    
    string amigo_pot = "nadie";
    int numero_amigos_comunes = 0;
    int maximo_amigos_comunes = 0;
    
    for (int i=0; i < usuarios_utiles; i++)
        if ( !SonAmigos(Usuatios[i],user) ){
            numero_amigos_comunes = NumeroAmigosComunes(Usuarios[i],user);
            if ( numero_amigos_comunes > maximo_amigos_comunes )
                amigo_pot = Usuarios[i];
        }
    
    return amigo_pot;
}

/* Apartado b */

// Suponemos que SonAmigos devuelve false si no existe alguno de los usuarios
bool RedSocial::AmigosCircunstanciales ( string user1, string user2 ){
    int amigos_circ = false;
    
    if ( SonAmigos(user1, user2) && NumeroAmigosComunes(user1,user2) == 0 )
        amigos_circ = true;
    
    return amigos_circ;
}
        

