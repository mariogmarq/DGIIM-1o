/* NuevoOrden
 Se pretende establecer un nuevo orden para comparar valores enteros positivos. Un valor entero $a$ sera mayor que otro $b$ si el numero de digitos nueve es mayor en $a$ que en $b$. Si el numero de nueves es igual en los dos, el mayor sera el que tiene mas ochos. Si hay empate tambien con este digito, se considera el siete. Asi hasta llegar al cero, si fuese necesario. Si la frecuencia de todos los digitos es igual en ambos valores, se les considera iguales bajo este orden. Se pide lo siguiente:
 
 a) Diseñar una funcion que reciba dos enteros positivos, $a$ y $b$, y devuelva true si $a$ es mayor estricto a $b$, atendiendo al orden especificado y false en caso contrario.
 b) Realizar una funcion main que ordene de forma ascendente v, un array de util enteros siguiendo este nuevo criterio. La ordenacion se realizará en el mismo vector v. Solo hay que implementar la parte de calculo. Suponga declarados
 
 const int TAM = 100;
 int v[TAM];
 int util; // util <= TAM
 
 Por ejemplo, si v contiene los valores 5000, 2244, 9000, 99, 550, tras la ordenacion quedara 2244, 5000, 550, 9000, 99.
*/


#include<iostream>
using namespace std;


int NumeroDigitos (int numero, int digito){
    int resultado = 0;
    
    while ( numero > 0 ){
        if ( numero % 10 == digito )
            resultado++;
        numero = numero / 10;
    }
    
    return resultado;
}


bool MayorQue ( int numero1, int numero2 ){
    int digito = 9;
    int digito_num1 = 0;
    int digito_num2 = 0;
    
    do{
        digito_num1 = NumeroDigitos ( numero1, digito );
        digito_num2 = NumeroDigitos ( numero2, digito );
        digito--;
    }while ( digito > -1 && digito_num1 == digito_num2 );

    return digito_num1 > digito_num2;
}

/* Menos eficiente pero mas corto
 
 bool MayorQue ( int numero1, int numero2 ){
    int digito = 9;
 
    while ( NumeroDigitos ( numero1, digito ) == NumeroDigitos ( numero2, digito ) )
        digito--;
 
    return NumeroDigitos ( numero1, digito ) > NumeroDigitos ( numero2, digito )
 }
*/


int main(){
    const int TAM = 100;
    int v[TAM]={5000, 2244, 9000, 99, 550};
    int util = 5;
    
    /* Ordenacion por insercion */
    int intercambio = 0;
    int posicion_minimo = 0;
    
    for ( int i=0; i<util; i++){
        posicion_minimo = i;
        
        for (int j=i+1; j<util; j++)
            if ( MayorQue( v[posicion_minimo], v[j] ) )
                posicion_minimo = j;
        
        intercambio = v[posicion_minimo];
        v[posicion_minimo] = v[i];
        v[i] = intercambio;
    }
    
    for (int i=0; i<util; i++)
        cout << v[i] << " ";
    cout << endl;
}

