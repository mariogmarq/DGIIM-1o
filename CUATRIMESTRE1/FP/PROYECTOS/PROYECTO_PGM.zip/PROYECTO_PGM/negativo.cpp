/************************************************************************************
 * PROYECTO PGM: MODULO NEGATIVO.EXE - INFORMACION
 * **********************************************************************************
 * 
 * AUTOR: DANIEL ZUFRÍ QUESADA
 * NOMBRE ARCHIVO: NEGATIVO.EXE
 * VERSIÓN: ALPHA 1.0
 * FECHA DE CREACIÓN (23/12/2018)
 * FECHA DE MODIFICACION (26/12/2018)
 * 
 * **********************************************************************************/


#include <iostream>
#include <string>
#include "funciones.h"

using namespace std;

int main(){
	string cadena_magica;
	int filas = 0, columnas = 0;
	short matriz_pixels[MAX][MAX] = {0};
	
	PedirDatos(cadena_magica, filas, columnas, matriz_pixels);
	
	Negativo(cadena_magica, filas, columnas, matriz_pixels);
	
	Mostrar(cadena_magica , filas, columnas, matriz_pixels);
}
