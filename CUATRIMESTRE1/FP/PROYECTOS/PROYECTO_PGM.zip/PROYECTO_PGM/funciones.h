/*******************************************************************************************
 * PROYECTO PGM - BIBLIOTECA DE FUNCIONES
 * *****************************************************************************************
 * 
 * MOTIVACION: EL OBJETIVO DE ESTE ARCHIVO ES EL DE AGRUPAR LAS FUNCIONES
 * 			   REQUERIDAS PARA EL PROYECTO CON EL FIN DE ORGANIZAR EL CODIGO
 * 			   DE UNA FORMA MAS EFICIENTE Y CLARA
 * 
 * DEPENDENCIAS: ESTE ARCHIVO ES FUNDAMENTAL PARA LOS SIGUIENTES 4 MODULOS
 * 		- BLANQUEAR.EXE -> BLANQUEA LA IMAGEN CAMBIANDO TODOS LOS PIXELES
 * 		- ROTAR.EXE -> ROTA LA IMAGEN EN 90º
 * 		- CONTRASTE.EXE -> MAXIMIZA EL CONTRASTE ENTRE LOS PIXELES DE UNA IMAGEN
 * 	    - NEGATIVO.EXE -> REALIZA EL NEGATIVO DE UNA IMAGEN
 * 
 * AUTORES:
 * 		- DANIEL ZUFRÍ QUESADA
 * 		- DANIEL PÉREZ RUIZ
 * 		- MARIA ISABEL RUIZ MARTINEZ
 * 		- PABLO NIETO LOPEZ
 * 
 * ******************************************************************************************/
 
#include <iostream>
#include <string>

using namespace std;

//CONSTANTE DE TIPO SHORT PARA DEFINIR EL TAMAÑO MAXIMO ACEPTADO PARA UNA IMAGEN.
const short MAX = 650;

/* PEDIR DATOS:    FUNCION PARA CARGAR EN MEMORIA LA IMAGEN .PGM
 * PRECONDICIONES: UNA IMAGEN .PGM VALIDA. */
void PedirDatos(string& cadena, int& filas, int& columnas, short matriz[MAX][MAX]){
	//ALMACENA LA CADENA MAGICA DE LOS ARCHIVOS PGM [P2]
	getline (cin, cadena);
	
	//CARGA EN MEMORIA EL VALOR DE ANCHO Y ALTO DE LA IMAGEN
	cin >> columnas >> filas;
	
	//GUARDA EL VALOR RGB DE CADA PIXEL
	for (int i=0; i<filas; i++){
		for (int j=0; j<columnas; j++)
			cin >> matriz[i][j];
	}
}

/* MOSTRAR DATOS:   FUNCION PARA PRODUCIR UNA SALIDA EN UNA IMAGEN.PGM
 * PRECONDICIONES:  ESPECIFICAR UNA SALIDA .PGM VALIDA */
void Mostrar(string cadena, int filas, int columnas, short matriz[MAX][MAX]){
	//SALIDA DE CADENA MAGICA, COLUMNAS Y FILAS
	cout << "P2" << "\n" << columnas << " " << filas << "\n" << "255\n";
	
	//SALIDA DEL VALOR RGB DE CADA PIXEL
	for (int i=0; i<filas; i++){
		for (int j=0; j<columnas; j++){
			cout << matriz [i][j] << " ";
		}
		
		cout << "\n";
	}
}

/* GIRAR:			FUNCION PARA ROTAR 90º UNA IMAGEN .PGM
 * PRECONDICIONES:  NINGUNA */
void Girar(string& cadena, int& filas, int& columnas, short matriz[MAX][MAX]){
	//COPIA LOS PIXELES E INFORMACION DE LA IMAGEN ORIGINAL EN UNA TEMPORAL
	//SE ROTAN LOS PIXELES EN DICHA IMAGEN Y SE VUELVEN A COPIAR EN LA IMAGEN ORIGINAL
	
	int t; //VARIABLE PARA COLUMNA DE MATRIZ TEMPORAL
	short mTem[MAX][MAX]; //MATRIZ TEMPORAL
	
	//PROCESO DE ROTACION Y ALMACENAMIENTO EN MATRIZ TEMPORAL
	for(int i = 0; i < filas; i++){
		t = 0;
		for(int j = filas-1; j >= 0; j--){
			mTem[i][t] = matriz[j][i];
			t++;
		}
	}

	//VOLCADO DE DATOS EN IMAGEN ORIGINAL
	for(int i = 0; i < filas; i++)
		for(int j = 0; j < columnas; j++)
			matriz[i][j] = mTem[i][j];
}

/* NEGATIVO:		FUNCION PARA OBTENER EL NEGATIVO DE UNA IMAGEN .PGM
 * PRECONDICIONES:  NINGUNA */
void Negativo(string& cadena, int& filas, int& columnas, short matriz[MAX][MAX]){
	//SE OBTIENE EL VALOR DE CADA PIXEL Y SE CALCULA EL COMPLEMENTARIO (255 - VALOR)
	short pixel;

	for (int i=0; i<filas; i++)
		for (int j=0; j<columnas; j++){
			pixel = matriz[i][j];
			matriz[i][j] = 255 - pixel;
		}
}

/* CONTRASTE:		FUNCION PARA PASAR TODOS LOS PIXELES A BLANCO Ó NEGRO
 * PRECONDICIONES:  NINGUNA */
void Contraste(string& cadena, int& filas, int& columnas, short matriz[MAX][MAX]){
	//SI EL PIXEL ES MENOR A 125, SE CAMBIA A NEGRO. EN CASO CONTRARIO, A BLANCO
	for (int i=0; i<filas; i++){
		for (int j=0; j<columnas; j++){
			if (matriz[i][j]<125)
				matriz[i][j]=0;
			else
				matriz[i][j]=255;
		}
	}
}

/* COLOREAR:	    FUNCION PARA CAMBIAR TODOS LOS PIXELES A UN COLOR EN CONCRETO
 * PRECONDICIONES:  ESPECIFICAR UN VALOR RGB VALIDO (DE 0 A 255) (DEFECTO: 255)*/
void Colorear(string& cadena, int& filas, int& columnas, short matriz[MAX][MAX], int rgb){
	//SI SE CUMPLE LA PRECONDICION, SE CAMBIA EL VALOR DE TODOS LOS PIXELES AL DADO
	if(rgb>=0 && rgb<=255){
		for (int i=0; i<filas; i++)
			for (int j=0; j<columnas; j++)
				matriz[i][j] = rgb;
	}
}
