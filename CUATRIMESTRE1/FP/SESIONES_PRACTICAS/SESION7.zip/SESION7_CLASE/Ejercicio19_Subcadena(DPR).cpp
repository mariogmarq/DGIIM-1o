/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

//FUNCI�N PARA DETERMINAR SI LONGITUD DE VECTOR INTRODUCIDA
//ES V�LIDA O NO
bool Check_longitud(int longitud)
{
	if(longitud > 1000)
	{
		return false;
	}
	
	else
	{
		return true;
	}
}

int main()
{
	//DECLARACI�N DE VARIABLES
	const int LENGTH = 1000;
	char vector[LENGTH] = {0};
	
	int longitud = 0;
	int posicion1 = 0, posicion2 = 0;

	//INTRODUCCI�N Y CHECK DE LONGITUD
	cout << "Inserte longitud del vector: ";
	cin >> longitud;
	
	if(!Check_longitud(longitud))
	{
		cout << "\nERROR. El maximo permitido de longitud es 1000.";
		return 0;
	}
	
	//INTRODUCCI�N DE DATOS: VECTOR
	cout << "\nInserte valores del vector y presiona enter.\n";
	
	for(int i = 0; i < longitud; i++)
	{
		cout << ">>> ";
		cin >> vector[i];
	}
	
	cout << "\nInserte dos posiciones (separadas por espacios): \n";
	cout << "NOTA: La primera posicion responde al numero 0\n\n";
	cout << ">>> ";
	cin >> posicion1 >> posicion2;
	
	cout << "\n\nLOS CARACTERES COMPRENDIDOS ENTRE ESAS POSICIONES SON: \n";
	
	for(int i=posicion1; i<=posicion2; i++)
	{
		cout << vector[i];
	}
}
	
