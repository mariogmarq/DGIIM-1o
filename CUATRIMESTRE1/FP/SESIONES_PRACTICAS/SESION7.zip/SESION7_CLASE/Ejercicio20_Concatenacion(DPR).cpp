/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <string>

using namespace std;

//FUNCI�N PARA DETERMINAR SI LONGITUD DE VECTOR INTRODUCIDA
//ES V�LIDA O NO
bool Check_longitud(int longitud)
{
	if(longitud > 1000)
	{
		return false;
	}
	
	else
	{
		return true;
	}
}

int main()
{
	const int LENGTH = 1000;
	int longitud1 = 0, longitud2 = 0;
	int posicion = 0;
	
	char cadena1[LENGTH] = {0};
	char cadena2[LENGTH] = {0};
	
	string concatenacion, part2;
	
	//INTRODUCCI�N Y CHECK DE LONGITUD 1
	cout << "Inserte longitud de la primera cadena: ";
	cin >> longitud1;
	
	if(!Check_longitud(longitud1))
	{
		cout << "\nERROR. El maximo permitido de longitud es 1000.";
		return 0;
	}
	
	//INTRODUCCI�N DE DATOS: CADENA 1
	cout << "\nInserte valores del vector y presiona enter.\n";
	
	for(int i = 0; i < longitud1; i++)
	{
		cout << ">>> ";
		cin >> cadena1[i];
	}
	
	//INTRODUCCI�N Y CHECK DE LONGITUD 2
	cout << "\n\nInserte longitud de la segunda cadena: ";
	cin >> longitud2;
	
	if(!Check_longitud(longitud2))
	{
		cout << "\nERROR. El maximo permitido de longitud es 1000.";
		return 0;
	}
	
	//INTRODUCCI�N DE DATOS: CADENA 2
	cout << "\nInserte valores del vector y presiona enter.\n";
	
	for(int i = 0; i < longitud2; i++)
	{
		cout << ">>> ";
		cin >> cadena2[i];
	}
	
	
	//INTRODUCCION DE POSICION DONDE CONCATENAR CADENAS
	cout << "\n\nInserte posicion donde concatenar cadena2 en cadena1:\n";
	cout << "NOTA: La primera posicion de la cadena responde al numero 0";
	cout << "\n>>> ";
	cin >> posicion;
	
	//PROCESO DE CONCATENACION
	
	//ROMPE LA CADENA1 EN DOS PARTES (SEGUN POSICION INTRODUCIDA
	for(int x = 0; x < posicion; x++)
	{
		concatenacion += cadena1[x];
	}
	
	for(int j = posicion; j < longitud1; j++)
	{
		part2 += cadena1[j];
	}
	
	//SE A�ADE A CONCATENACION LA CADENA2
	for(int y = 0; y < longitud2; y++)
	{
		concatenacion += cadena2[y];
	}
	
	//REUNIFICACI�N DE TODA LA CONCATENACION
	concatenacion = concatenacion + part2;
	
	//SALIDA DE RESULTADOS
	cout << "\n\nCONCATENACION: " << concatenacion;
}
	
	
