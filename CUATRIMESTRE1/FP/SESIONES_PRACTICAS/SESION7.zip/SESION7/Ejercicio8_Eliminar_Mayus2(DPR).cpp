/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

//FUNCI�N PARA DETERMINAR SI LONGITUD DE VECTOR INTRODUCIDA
//ES V�LIDA O NO
bool Check_longitud(int longitud)
{
	if(longitud > 1000)
	{
		return false;
	}
	
	else
	{
		return true;
	}
}

int main()
{
	const int LENGTH = 1000;
	int longitud = 0;
	
	int posicion_lectura = 0, posicion_escritura = 0;
	
	char vector[LENGTH] = {0};
	
	//INTRODUCCI�N Y CHECK DE LONGITUD
	cout << "Inserte longitud del vector: ";
	cin >> longitud;
	
	if(!Check_longitud(longitud))
	{
		cout << "\nERROR. El maximo permitido de longitud es 1000.";
		return 0;
	}
	
	//INTRODUCCI�N DE DATOS: VECTOR
	cout << "\nInserte valores del vector y presiona enter.\n";
	
	for(int i = 0; i < longitud; i++)
	{
		cout << ">>> ";
		cin >> vector[i];
	}
	
	while(posicion_lectura < longitud)
	{
		if(96 < vector[posicion_lectura] && vector[posicion_lectura] < 123)
		{
			vector[posicion_escritura] = vector[posicion_lectura];
			
			posicion_escritura++;
			posicion_lectura++;
		}
		
		else
		{
			posicion_lectura++;
		}
	}
	
	cout << "\nVector sin mayusculas\n";
	for(int k = 0; k < posicion_escritura; k++)
	{
		cout << vector[k];
	}
}
