/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

//FUNCI�N PARA DETERMINAR SI LONGITUD DE VECTOR INTRODUCIDA
//ES V�LIDA O NO
bool Check_longitud(int longitud)
{
	if(longitud > 1000)
	{
		return false;
	}
	
	else
	{
		return true;
	}
}

int main()
{
	const int LENGTH = 1000;
	int longitud = 0;
	
	int vector[LENGTH] = {0};
	bool mayor_siguiente[LENGTH] = {true};
	
	
	//INTRODUCCI�N Y CHECK DE LONGITUD
	cout << "Inserte longitud del vector: ";
	cin >> longitud;
	
	if(!Check_longitud(longitud))
	{
		cout << "\nERROR. El maximo permitido de longitud es 1000.";
		return 0;
	}
	
	//INTRODUCCI�N DE DATOS: VECTOR
	cout << "\nInserte valores del vector y presiona enter.\n";
	
	for(int i = 0; i < longitud; i++)
	{
		cout << ">>> ";
		cin >> vector[i];
	}
	
	for(int j = 0; j < longitud; j++)
	{
		if(vector[j] <= vector[j+1])
		{
			mayor_siguiente[j+1] = true;
		}
		
		else
		{
			mayor_siguiente[j+1] = false;
		}
	}
	
	for(int k=0; k < longitud; k++)
	{
		cout << mayor_siguiente[k];
	}
	
	cout << "\n\n";
	
	for(int x = 0; x < longitud; x++)
	{
		if(mayor_siguiente[x])
		{
			cout << vector[x];
		}
		
		else
		{
			cout << vector[x];
		}
	}
}
