/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

//FUNCI�N PARA DETERMINAR SI LONGITUD DE VECTOR INTRODUCIDA
//ES V�LIDA O NO
bool Check_longitud(int longitud)
{
	if(longitud > 1000)
	{
		return false;
	}
	
	else
	{
		return true;
	}
}

int main()
{
	//DECLARACION DE VARIABLES
	const int LENGTH = 1000;
	bool primo[LENGTH] = {0};
	
	int tope = 0;
	
	//INTRODUCCI�N Y CHECK DE NUMERO TOPE
	cout << "Inserte numero tope: ";
	cin >> tope;
	
	if(!Check_longitud(tope))
	{
		cout << "\nERROR. El maximo permitido de tope es 1000.";
		return 0;
	}
	
	
	//VECTOR BOOLEANO PARA DETERMINAR N�MEROS PRIMOS
	for(int i = 0; i < tope; i++)
	{
		primo[i] = true;
	}
	
	//ELIMINA LOS MULTIPLOS DE 2, DE 3, HASTA TOPE
	for(int x = 2; x < tope; x++)
	{
		for(int y = 2; x*y < tope; y++)
		{
			primo[x*y] = false;
		}
	}
	 
	 
	//MUESTRA DE NUMEROS	
	cout << "\n\nNUMEROS PRIMOS: \n";
	for(int k = 2; k < tope; k++)
	{
		if(primo[k])
		{
			cout << k << " ";
		}
	}
}
	
	
