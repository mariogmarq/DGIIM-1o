/*PROGRAMA PARA CALCULAR GANANCIAS DE DISE�ADOR Y FABRICANTES

Se pedir� al usuario introducir el valor de las ganancias totales
que ha obtenido la empresa.

Despu�s se realizar� las operaciones oportunas (teniendo en cuenta
que el dise�ador gana el doble que un fabricante) y despu�s se
mostrar� el resultado al usuario en pantalla.

Se multiplicar�n las ganancias totales por 0.4 en el caso del dise�ador,
ya que cobra el doble que un fabricante. El resto de las ganancias totales
se dividir� entre 3, que representa el n�mero total de fabricantes.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O

using namespace std;

int main()									//Funci�n principal
{
	double ingresos;						//Declaraci�n de variables con
	double fabricante;					//las que trabajaremos (como reales)
	double designer;
	
	
	cout << "===============================================";				//Mensaje de bienvenida al usuario
	cout << "\nCALCULO DE LA GANANCIA DE UN DISE�ADOR Y LOS";
	cout << "\nFABRICANTES DE UNA EMPRESA";
	cout << "\n===============================================";
	
	
	cout << "\n\nInserte ingresos totales: ";										//Pide al usuario que introduzca
	cin >> ingresos;																		//ingresos totales
	
	designer = 0.4 * ingresos;															//Calculo ingreso dise�ador
	fabricante = (ingresos - designer) / 3;										//y fabricantes
	
	cout << "\n\nEl dise�ador cobrara: " << designer << " euros.";			//Devoluci�n de datos al usuario
	cout << "\nCada fabricante cobrara: " << fabricante << " euros.";
	
	cout << "\n\n===============================================";
	
	cout << "\n\nNOTA: El valor mostrado para fabricante equivale a";
	cout << "\ncada uno de los fabricantes que hay en la empresa.";
	cout << "\nEn total, son 3 fabricantes.\n\n";
	
	system("pause");
}
