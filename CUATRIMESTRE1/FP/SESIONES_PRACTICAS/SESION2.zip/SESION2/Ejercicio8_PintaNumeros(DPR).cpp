/*PROGRAMA PARA SEPARAR D�GITOS DE UN N�MERO

Se pedir� al usuario introducir un n�mero de 3 cifras. Despu�s
se dividir� el n�mero entre 10, obtendremos un cociente y un
m�dulo. Dividiremos cada cociente entre 10 hasta que el �ltimo
cociente sea 0.

Todos los restos obtenidos ser�n los d�gitos del n�mero, que
asignaremos en variables distintas y separaremos por 3 espacios.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos

using namespace std;

int main()									//Funci�n principal
{
	int number;																				//Variable para introducir n�mero
	
	
	int digit1, digit2, digit3;														//Variables para guardar los
																								//d�gitos separados
	
	
	cout << "===============================================";				//Mensaje de bienvenida al usuario
	cout << "\nSEPARAR LOS DIGITOS DE UN NUMERO";
	cout << "\n===============================================";
	
	
	cout << "\n\nInserte numero de 3 cifras: ";									//Pide al usuario que introduzca
	cin >> number;																			//el n�mero
	
	if(100 < number)																		//IF: Si el n�mero tiene menos de 3 d�gitos muestra
	{																							//un error (V�ASE ELSE).
		
		if(number < 999)																	//IF ANIDADO: Si el n�mero tiene m�s de 3 d�gitos
		{																						//muestra un error (V�ASE ELSE).
			
			
			digit3 = number % 10;														//digit3 guarda la tercera cifra.
			number = number / 10;														//number se queda con los dos primeros d�gitos.
	
			digit2 = number % 10;														//digit2 guarda la segunda cifra.
			digit1 = number / 10;														//number se queda con el primer d�gito y
																								//lo asigna a digit1.
	
			cout << "\n\nLOS DIGITOS SON: \n";
			cout << digit1 << "   " << digit2 << "   " << digit3;				//Muestra los d�gitos con 3 separaciones entre s�.
	
			cout << "\n\n";
			system("pause");
		}
		
		else																					//ELSE: Mensaje de error si el n�mero tiene m�s
			{																				   //de 3 d�gitos
				cout << "\nERROR: NO HA INTRODUCIDO UN NUMERO VALIDO";
				cout << "\n\n";
		
				system("pause");
			}
	}
	
	else																						//ELSE: Mensaje de error si el n�mero tiene menos
	{																							//de 3 d�gitos.
		cout << "\nERROR: NO HA INTRODUCIDO UN NUMERO VALIDO";
		cout << "\n\n";
		
		system("pause");
	}
}
