/*C�LCULO DE HORAS, MINUTOS Y SEGUNDOS

Se pedir� al usuario introducir el valor de las horas, minutos
y segundos. Despu�s se devolver�n los datos que ha introducido
en pantalla y despu�s se realizar�n las operaciones pertinentes
para mostrar correctamente el resultado.


C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos

using namespace std;

int main()																					//Funci�n principal
{
	int hora;																				//Variables para introducir
	int minuto;																				//horas, minutos y segundos
	int segundo;
	int dia;																					//Si hay m�s de 24 horas, con esta
																								//variable se cambia a d�a.
																								
	int swap;																				//Variable que usaremos como auxiliar
	swap = 0;
	
	
	cout << "===============================================";				//Mensaje de bienvenida al usuario
	cout << "\nCALCULO DE HORAS, MINUTOS Y SEGUNDOS";
	cout << "\n===============================================";
	
	
	cout << "\n\nInserte horas: ";													//Pide al usuario que introduzca			
	cin >> hora;																			//los datos
	
	cout << "Inserte minutos: ";
	cin >> minuto;
	
	cout << "Inserte segundos: ";
	cin >> segundo;
	
	cout << "\n\n\n";	
	
	cout << "USTED HA INTRODUCIDO:\n";											//Devuelve los datos al usuario
	
	
	cout << hora << " horas " << minuto << " minutos " << segundo << " segundos\n\n";
	
	system("pause");
	
	
	if(segundo > 59)																	//IF: Si los segundos tienen un valor mayor
	{																						//que 59. Se dividen los segundos entre 60,
		swap = segundo / 60;															//y se almacenan en "swap". El valor del
		segundo = segundo % 60;														//resto se almacena en "segundo" y se a�aden
		minuto = minuto + swap;														//los minutos calculados al valor "minuto"
		swap = 0;																		//que el usuario introdujo.
	}
	
	if(minuto > 59)																	//IF: Mismo procedimiento que con los
	{																						//segundos.
		swap = minuto / 60;
		minuto = minuto % 60;
		hora = hora + swap;
	}
	
	if(hora > 23)																		//IF: Si el valor de "hora" excede de 23,
	{																						//se transforma el sobrante en d�as.
		dia = hora / 24;
		hora = hora % 24;
	}
	
	cout << "\n\nEL RESULTADO ES:\n";											//Devuelve la conversi�n al usuario.
	
	
	cout << dia << " dias " << hora << " horas " << minuto << " minutos " << segundo << " segundos\n\n";
	
	system("pause");
}
