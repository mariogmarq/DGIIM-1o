/*C�LCULO DE AREA DE TRI�NGULO A PARTIR DE UN �NGULO

Se pide al usuario introducir el valor de dos lados y el �ngulo 
que forman ambos lados. Se transformar�n esos �ngulos a radianes
y despu�s se calcular� el �rea.

Por �ltimo, se devolver� el �rea al usuario.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ */

#include <iostream>			//Librer�a necesaria para recursos de E/S
#include <cmath>           //librer�a de recursos matem�ticos

using namespace std;

int main()						     //Funci�n principal
{
	double ladoa;				       //Declaraci�n de variables como reales.
	double ladob;				       //(datos que se piden al usuario).
	double angulo;
	
	double angulo_rad;             //Variables que se calculan y se devuelven
	double area;                   //al usuario.
	
	const double PI = 3.1415926535;
	
	cout << "Inserte valor lado a (cm): ";               //Pide al usuario que introduzca los datos
	cin >> ladoa;
	
	cout << "Inserte valor lado b (cm): ";
	cin >> ladob;
	
	cout << "Inserte valor angulo: ";
	cin >> angulo;
	
	if(angulo >= 180)                                                         //IF: Un �ngulo de un tri�ngulo cualquiera no puede superar o igualar 180�. Si lo supera
	{                                                                         //devolver� un mensaje de error.
	   cout << "\n\nERROR: HA INTRODUCIDO UN ANGULO NO VALIDO\n\n";
	   
	   system("pause");
	}
	
	else                                                                      //ELSE: Si cumple los requisitos, opera.
	{
	  angulo_rad = (angulo * PI) / 180;                                       //Cambio de grados a radianes.
	
	  area = (1/2.0) * ladoa * ladob * sin(angulo_rad);                       //C�lculo del �rea.
	
	  cout << "\n\nEL AREA ES: " << area << " cm2\n\n";                       //Devoluci�n de los datos al usuario.
	
	  system("pause");
   }
}
