/*C�LCULO DE DISTANCIA RECORRIDA POR DOS TRENES

Se pide al usuario introducir el de las velocidades de dos trenes que circulan
con velocidad constante y la distancia a la que est�n separados esos dos trenes.

Una vez realizado eso, se calcular� el tiempo a trav�s de una f�rmula, y con ese
tiempo calcularemos el espacio recorrido antes de que se choquen (ese valor se
devolver� al usuario).

C�DIGO FUENTE POR DANIEL P�REZ RUIZ */

#include <iostream>			//Librer�a necesaria para recursos de E/S
#include <cmath>           //librer�a de recursos matem�ticos

using namespace std;

int main()						     //Funci�n principal
{
	double v1;				       //Declaraci�n de variables como reales.
	double v2;				       //(datos que se piden al usuario).
	double d;
	
	double t;                   //Variables que se calculan y se devuelven
	double s1;                   //al usuario.
	double s2;
	
	cout << "Inserte velocidad primer tren (km/h): ";
	cin >> v1;
	
	cout << "Inserte velocidad segundo tren (km/h): ";
	cin >> v2;
	
	cout << "Inserte distancia a la que se encuentran (km): ";
	cin >> d;
	
	t = d / (v1 + v2);
	
	s1 = v1 * t;
	s2 = v2 * t;
	
	cout << "\n\nEL ESPACIO RECORRIDO POR TREN 1 ES: " << s1 << " km\n";
	cout << "EL ESPACIO RECORRIDO POR TREN 2 ES: " << s2 << " km\n\n";
	
	system("pause");
}
