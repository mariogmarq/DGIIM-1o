/*CODIGO FUENTE POR DANIEL PEREZ RUIZ*/

#include <iostream>																//LIBRERIA DE RECURSOS I/O

using namespace std;

int main()
{	
	int contador_0=0;
	int numero=0;
	int contador_1 = 0;


	while(contador_0 <= 4 && (numero==1 || numero==0))
	{
		cout << "INSERTE NUMERO: "; 
		cin >> numero;	
		
		if(numero == 1)
		{
			contador_0 = 0;
			contador_1++;
		}
		
		else
		{
			contador_0++;
			
			if(contador_1 != 0)
			{
				cout << contador_1 << " ";
			}
			
			contador_1 = 0;
		}	
	}
	
	cout << 0 << " ";
}
