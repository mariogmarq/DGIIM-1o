/*CODIGO FUENTE COMPILADO POR DANIEL P�REZ RUIZ*/

#include <iostream>																									//LIBRERIA RECURSOS I/O
#include <string>																										//LIBRERIA PARA CADENA DE CARACTERES STRING

using namespace std;

int main()
{
	int sucursal = 4, producto = 0, ventas = 0;																//VARIABLES
	int suma1 = 0, suma2 = 0, suma3 = 0;
	
	string SUCURSAL = "\nLA SUCURSAL QUE MAS VENTAS TIENE ES: ";
	string PRODUCTO = "\nPRODUCTOS VENDIDOS: ";
	
	while(sucursal > 0)																																			//WHILE: MIENTRAS SUCURSAL NO SEA -1, PIDE DATOS
	{
		cout << "INSERTE SUCURSAL, PRODUCTO Y VENTAS (EN ESTE ORDEN, SEPARADO POR ESPACIO) (-1 0 0 para finalizar): ";
		cin >> sucursal >> producto >> ventas;
		
		if(sucursal == 1)																								//SI SUCURSAL = 1, SUMA SUS VENTAS
		{
			suma1 = suma1 + ventas;
		}
		
		else
		{
			if(sucursal == 2)																							//SUCURSAL = 2, SUMA SUS VENTAS
			{
				suma2 = suma2 + ventas;
			}
			
			else
			{
				if(sucursal == 3)																						//SUCURSAL = 3, SUMA SUS VENTAS
				{
					suma3 = suma3 + ventas;
				}
			}
		}
	}
	
	if((suma1 > suma2) && (suma1 > suma3))																		//EVAL�A QU� SUMA DE VENTAS ES MAYOR. EN FUNCION DE ESO, MUESTRA POR PANTALLA
	{																														//LA MAYOR VENTA Y LA SUCURSAL ASOCIADA
		cout << SUCURSAL << 1;
		cout << PRODUCTO << suma1;
	}
	
	else
	{
		if((suma1 < suma2) && (suma2 > suma3))
		{
			cout << SUCURSAL << 2;
			cout << PRODUCTO << suma2;
		}
		
		else
		{
			cout << SUCURSAL << 3;
			cout << PRODUCTO << suma3;
		}
	}
}
