//CÓDIGO FUENTE POR DANIEL PEREZ RUIZ

#include <iostream>
#include <cmath>

using namespace std;

//FUNCION RECURSIVA PARA SUMAR DIGITOS
//PRECONDICION: NUMERO > 0
int SumaDigitos(int numero){
	int respuesta;
	
	//SI NUMERO > 0 => SUMA DE ULTIMO DIGITO DE NUMERO
	if(numero > 0)
		respuesta = (numero % 10) + SumaDigitos(numero / 10);
	else
		respuesta = 0;
		
	return respuesta;
}

//FUNCION PRINCIPAL
int main(){
	int numero = 0;

	cout << "INSERTE NUMERO: ";
	cin >> numero;
	
	if(numero < 0)
 		numero = -1 * numero;

	cout << "\nSUMA DE DIGITOS: " << SumaDigitos(numero) << "\n";

	system("pause");
}
