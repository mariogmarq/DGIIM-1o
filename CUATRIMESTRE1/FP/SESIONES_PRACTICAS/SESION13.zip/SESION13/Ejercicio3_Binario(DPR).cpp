//CODIGO FUENTE POR DANIEL P�REZ RUIZ

#include <iostream>
#include <vector>

using namespace std;

int GetDigit(int numero){
	int respuesta;
	
	if(numero < 2)
		respuesta = numero;
	else
		respuesta = numero % 2 + (10 * GetDigit(numero / 2));
		
	return respuesta;
}

void ToVectorBinary(int binary, int& vector[], int& length){
	int i = 0;
	
	while(binary != 0){
		vector[i] = binary % 10;
		binary /= 10;
		i++;
	}
	
	length = i;
}

void MostrarVector(int vector[100], int length){
	for(int i=length; i>=0; i--){
		cout << vector[i] << " ";
	}
}

int main(){
	int numero = 0, binario = 0;
	int vector_binarios[100] = {0}, length = 0;
	
	cout << "Inserte numero decimal: ";
	cin >> numero;
	
	if(numero < 0)
		numero = -1 * numero;
	
	binario = GetDigit(numero);
	
	cout << binario;
	
	ToVectorBinary(binario, vector_binarios, length);
	
	MostrarVector(vector_binarios, length);
}
	
