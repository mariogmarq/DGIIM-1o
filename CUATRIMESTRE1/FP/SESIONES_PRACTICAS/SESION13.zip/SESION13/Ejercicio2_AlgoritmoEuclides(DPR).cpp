//CODIGO FUENTE POR DANIEL PEREZ RUIZ

#include <iostream>

using namespace std;

int MCD(int a, int b){
	int respuesta;

	if(b > 0){
		respuesta = MCD(b, a % b);
	}
	
	else{
		respuesta = a;
	}

	return respuesta;
}


int main(){
	int numero1, numero2;

	cout << "INSERTE DOS NUMEROS: ";
	cin >> numero1 >> numero2;

	cout << "\nMCD: " << MCD(numero1, numero2) << "\n";

	system("pause");
}
