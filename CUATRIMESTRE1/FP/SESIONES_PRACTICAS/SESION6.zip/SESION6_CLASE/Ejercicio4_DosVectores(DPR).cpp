/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

int main()
{
	const int LONGITUD = 500;
	
	int length = 0, lon_fin = 0;
	int i = 0, j = 0, k = 0;
	
	int vector1[LONGITUD] = {0} , vector2[LONGITUD] = {0};
	int vector_fin[LONGITUD] = {0};
	
	//DEFINICI�N DE TAMA�O DE VECTOR
	
	cout << "INSERTE LONGITUD DE VECTOR: ";
	cin >> length;
	
	lon_fin = 2 * length;
	cout << "\n";
	
	//INSERCI�N DE DATOS POR EL USUARIO
	
	cout << "INSERTE NUMEROS PARA VECTOR A: \n";
	for(int a=0; a<length; a++)
	{
		cout << ">>> ";
		cin >> vector1[a];
	}
	
	cout << "\n\nINSERTE NUMEROS PARA VECTOR B: \n";
	for(int b=0; b<length; b++)
	{
		cout << ">>> ";
		cin >> vector2[b];
	}
	
	//EVALUACI�N DE ORDEN PARA VECTOR RESULTANTE
	
	while(j < length || i < length)
	{
		if(i < length && j < length)
		{
			if(vector1[i] < vector2[j])
			{
				vector_fin[k] = vector1[i];
				i++;
			}
			
			else
			{
				vector_fin[k] = vector2[j];
				j++;
			}
		}	
		
		else
		{
			if(i < length)
			{
				vector_fin[k] = vector1[i];
				i++;
			}
			
			else
			{
				vector_fin[k] = vector2[j];
				j++;
			}
		}

		k++;
	}
	
	cout << "\n\n";
	
	//MUESTRA DE VECTOR ORDENADO
	
	for(int c=0; c<lon_fin; c++)
	{
		cout << vector_fin[c];
	}
}
	
	
