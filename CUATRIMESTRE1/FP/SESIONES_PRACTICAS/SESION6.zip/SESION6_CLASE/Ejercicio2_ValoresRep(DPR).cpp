/*C�DIGO COMPILADO POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

int main()
{	
	//DECLARACI�N DE VARIABLES
	
	const int LONGITUD = 100;
	
	int vector[LONGITUD] = {0}, copia[LONGITUD] = {0};
	int i = 0, j = 0, length = 0;
	
	bool numero_repetido = false;
	
	//ELECCI�N DE TAMA�O DEL VECTOR
	
	cout << "INSERTE LONGITUD VECTOR: ";
	cin >> length;
	
	//INTRODUCCI�N DE DATOS
	
	for(int k=0; k<length; k++)
	{
		cout << "INSERTE NUMEROS: ";
		cin >> vector[k];
	}
	
	//COMPROBACION DE VALORES REPETIDOS
	
	while(i < length)
	{
		numero_repetido = false;
		j = i;
		
		while((j < length) && !numero_repetido)
		{
			j++;
			
			if(vector[i] == vector[j])
			{
				numero_repetido = true;
			}
		}
		
		if(numero_repetido)
		{
			for(int z=j; z < length; z++)
			{
				vector[z] = vector[z+1];
			}
			length--;
		}
			
		else
		{
			i++;
		}
	}
	
	//MUESTRA DE RESULTADO
	
	cout << "\nVECTOR SIN VALORES REPETIDOS: \n";

	for(int y=0; y < length; y++)
	{
		cout << vector[y] << " ";
	}
}
			
		
		
	
