/*C�DIGO COMPILADO POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

int main()
{	
	//DECLARACI�N DE VARIABLES
	
	const int LONGITUD = 5;
	
	int vector_A[LONGITUD], vector_B[LONGITUD];
	int k = 0;
	
	bool vector_igual = true;
	
	//INTRODUCCI�N DE DATOS POR PARTE DE USUARIO.
	
	//PARA VECTOR A
	
	for(int i=0; i<LONGITUD; i++)
	{
		cout << "Inserte numeros para vector A: ";
		cin >> vector_A[i];
	}
	
	cout << "\n";
	
	//PARA VECTOR B
	
	for(int j=0; j<LONGITUD; j++)
	{
		cout << "Inserte numeros para vector B: ";
		cin >> vector_B[j];
	}
	
	
	//COMPROBACI�N DE VECTORES IGUALES USANDO UN BOOL
	
	while(k < LONGITUD)
	{
		vector_igual = vector_A[k] == vector_B[k];	
		k++;
		
		if(!vector_igual)
		{
			cout << "\nLOS VECTORES A Y B NO SON IGUALES";
			return 0;
		}
	}
	
	if(vector_igual)
	{
		cout << "\nLOS VECTORES A Y B SON IGUALES";
		return 0;
	}
		
	
}
