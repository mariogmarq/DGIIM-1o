/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

int main()
{
	const int LONGITUD = 100;
	const char TERMINADOR = '#';
	
	int length = 0;
	int i = 0, j = 0;
	int swap = 0;
	
	char vector[LONGITUD] = {0}, reves[LONGITUD] = {0};
	bool palindromo = false;
	
	//INSERCI�N DE DATOS POR EL USUARIO
	
	//1. LECTURA ANTICIPADA
	
	cout << "INSERTE CARACTERES UNO A UNO (# fin): \n";
	
	cout << ">>> ";
	cin >> vector[i];
	
	i++;
	
	//2. SIGUE PIDIENDO DATOS HASTA QUE SE INTRODUZCA #

	while(vector[i-1] != TERMINADOR)
	{
		cout << ">>> ";
		cin >> vector[i];
		
		i++;
		length++;
	}
	
	//REORDENACI�N DEL VECTOR AL REV�S
	
	while(i-1 >= 0)
	{
		reves[j] = vector[i-2];
		
		j++;
		i--;
	}
	
	//COMPROBACI�N DE QUE AMBOS VECTORES SON IGUALES
	
	for(int z=0; z<length; z++)
	{
		palindromo = vector[z] == reves[z];
		
		if(!palindromo)
		{
			cout << "\n\nNo es palindromo";
			return 0;
		}
		
		else
		{
			palindromo = true;
		}
	}
	
	//SI SON IGUALES: MUESTRA QUE ES PAL�NDROMO
	
	if(palindromo)
	{
		cout << "\n\nES PALINDROMO";
	}
}
	
	
	
	
