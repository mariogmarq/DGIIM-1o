/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>																	//LIBRERIA DE RECURSOS I/O

using namespace std;

int main()
{
	char pais = 'a', hortaliza;													//DECLARACION E INICIALIZACION DE VARIABLES
	int toneladas = 0, ton1 = 0, ton2 = 0, ton3 = 0;
	
	bool max_esp, max_fr, max_ale;												//VARIABLES BOOL PARA COMPROBAR EL PAIS QUE MAS VENDE
	
	while(pais != '@')																//MIENTRAS PAIS NO SEA '@', PIDE DATOS
	{
		cout << "Inserte ID pais: ";
		cin >> pais;
		
		if(pais != '@')
		{
			cout << "Inserte ID hortaliza: ";
			cin >> hortaliza;
			
			cout << "Inserte numero Toneladas: ";
			cin >> toneladas;
			
			if(pais == 'E')															//SI PAIS ES ESPA�A: CALCULA SUS VENTAS
			{
				ton1 += toneladas;
			}
			
			if(pais == 'F')															//SI PAIS ES FRANCIA: CALCULA SUS VENTAS
			{
				ton2 += toneladas;
			}
			
			if(pais == 'A')															//SI PAIS ES ALEMANIA: CALCULA SUS VENTAS
			{
				ton3 += toneladas;
			}
		}
		
		max_esp = (ton1 > ton2) && (ton1 > ton3);								//COMPRUEBA QU� PAIS HA VENDIDO M�S
		max_fr = (ton2 > ton1) && (ton2 > ton3);
		max_ale = !max_esp && !max_fr;
		
		cout << "\n\n";
	}
	
	if(max_esp)																			//MUESTRA RESULTADO EN FUNCION DEL GANADOR
	{
		cout << "\nGANADOR: Espania";
		cout << "\nTONELADAS VENDIDAS: " << ton1;
	}
	
	if(max_fr)
	{
		cout << "\nGANADOR: Francia";
		cout << "\nTONELADAS VENDIDAS: " << ton2;
	}
	
	if(max_ale)
	{
		cout << "\nGANADOR: Alemania";
		cout << "\nTONELADAS VENDIDAS: " << ton3;
	}
}
