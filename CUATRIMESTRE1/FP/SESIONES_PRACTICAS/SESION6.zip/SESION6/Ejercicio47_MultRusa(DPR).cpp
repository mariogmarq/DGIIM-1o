/*CODIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>										//LIBRERIA DE RECURSOS I/O

using namespace std;

int main()
{
	int multiplicando, multiplicador;					//VARIABLES
	int resultado = 0;
	
	cout << "INSERTE MULTIPLICANDO: ";					//INSERCI�N DE DATOS
	cin >> multiplicando;
	
	cout << "INSERTE MULTIPLICADOR: ";
	cin >> multiplicador;
	
	while(multiplicando >= 1)							//MIENTRAS EL MULTIPLICANDO SEA MAYOR O IGUAL QUE 1, REALIZA
	{													//ALGORITMO DE MULTIPLICACION RUSA
		
		if((multiplicando % 2) != 0)					//CUANDO MULTIPLICANDO SEA IMPAR, SE VA A�ADIENDO EL RESULTADO DE MULTIPLICADOR
		{
			resultado += multiplicador;
		}
		
		multiplicando /= 2;
		multiplicador *= 2;
	}
	
	cout << "\nEL RESULTADO ES: " << resultado;
}
