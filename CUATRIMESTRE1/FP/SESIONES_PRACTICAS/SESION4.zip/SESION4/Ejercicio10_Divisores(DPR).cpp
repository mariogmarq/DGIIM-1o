/*DIVISORES DE UN N�MERO

Lee un n�mero positivo y comprueba todos sus divisores utilizando un bucle while.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O.
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos.

using namespace std;

int main()																		//Funci�n principal.
{	
	int tope = 0;																//Declaracion de la variable numero
	
	do																				//FILTRO PARA EVITAR QUE USUARIO INTRODUZCA NUM NEGATIVO
	{
		cout << "INSERTE NUMERO NATURAL: ";
		cin >> tope;
	}while(tope < 0);
	
		
	for(int i=0; i<10; i++)													//SALTOS DE LINEA
	{
		cout << "\n";
	}
	
	
		
	for(int j=1; j<=tope; j++)												//Bucle FOR: La variable J empieza en 1 y termina en tope, comprobando
	{																				//en cada momento si el modulo del numero tope y j es 0 antes de aumentar
		if((tope % j) == 0)													//en una unidad.
		{
			cout << "DIVISORES: " << j;
			cout << "\n";
		}
	}
}
