/*CALCULO DE RENTA NETA

Se pedira al usuario introducir una serie de datos personales, entre ellos la renta y la retencion aplicada,
se calculara la retencion total en funcion de una serie de parametros y despues se devolvera al usuario
la retencion total y la renta neta.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O.
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos.

using namespace std;

int main()
{
	char autonomo, pensionista, civil;													//DECLARACION DE VARIABLES PARA DATOS PERSONALES
	double r_bruta, r_neta, retencion;													//VARIABLES PARA OPERAR CON RENTA
	
	bool trabajador_normal, chk_autonomo, chk_pensionista;						//VARIABLES BOOLEANAS PARA COMPROBAR PARAMETROS INTRODUCIDOS
	bool chk_soltero, chk_rentabaja, chk_rentaalta;
	
	cout << "INSERTE RENTA BRUTA: ";														//INSERCI�N DE DATOS
	cin >> r_bruta;
	
	cout << "INSERTE RETENCION (en %): ";
	cin >> retencion;
	
	while((autonomo != 'S') && (autonomo != 'N'))
	{
		cout << "\nES AUTONOMO? (Inserte S [SI] o N [NO]): ";
		cin >> autonomo;
	}
	
	while((pensionista != 'S') && (pensionista != 'N'))
	{
		cout << "\nES PENSIONISTA? (Inserte S [SI] o N [NO]): ";
		cin >> pensionista;
	}
	
	while((civil != 'S') && (civil != 'C'))
	{
		cout << "\nINSERTE ESTADO CIVIL (Inserte C [CASADO] o S [SOLTERO U OTROS]): ";
		cin >> civil;
	}
	
	trabajador_normal = (autonomo == 'N') && (pensionista == 'N');							//SI NO ES PENSIONISTA NI AUTONOMO, ES TR. NORMAL
	
	chk_rentabaja = (r_bruta < 20000);																//RENTABAJA: RENTA POR DEBAJO DE 20000
	chk_rentaalta = (r_bruta >= 20000);																//RENTAALTA: RENTA IGUAL O ENCIMA DE 20000
	chk_autonomo = (autonomo == 'S');																//COMPRUEBA AUTONOMO
	chk_pensionista = (pensionista == 'S');														//COMPRUEBA PENSIONISTA
	chk_soltero = (civil == 'S');																		//COMPRUEBA SOLTERO
	
	retencion = (retencion / 100.0);																	//RETENCION A TANTO POR UNO.
	
	if(trabajador_normal)																				//SI ES TRB. NORMAL, PRIMERO APLICA SUBIDA 2%
	{
		retencion = retencion + retencion * 0.02;
		
		if(chk_rentabaja)																					//SI RENTA ES BAJA, SUBE 6% MAS
		{	
			retencion = retencion + retencion * 0,06;
		}
		
		if(chk_rentaalta && (chk_soltero == 0))													//SI RENTA ES ALTA Y CASADO, SUBE 8% MAS
		{
			retencion = retencion + retencion * 0,06;
		}
		
		if(chk_rentaalta && chk_soltero)																//SI RENTA ES ALTA Y SOLTER, SUBE 10% MAS
		{
			retencion = retencion + retencion * 0.10;
		}
	}
	
	else																									
	{
		if(chk_autonomo)																					//SI ES AUTONOMO, BAJA 3%
		{
			retencion = retencion - retencion * 0.03;
		}
		
		else
		{
			if(chk_pensionista)																			//SI ES PENSIONISTA, BAJA 1%
			{
				retencion = retencion - retencion * 0.01;
			}
		}
	}
	
	
	r_neta = r_bruta + r_bruta * retencion;														//CALCULO DE RENTA NETA
	
	cout << "\n\n\nLA RENTA NETA ES: " << r_neta << " euros";								//DEVOLUCION DE DATOS
	
	cout << "\n\nRENTA BRUTA INTRODUCIDA: " << r_bruta << " euros";
	cout << "\nRETENCION TOTAL APLICADA: " << (retencion * 100) << " %"; 	
}
