/*COMPROBAR A�O BISIESTO

Lee 3 n�meros desde teclado y comprueba si est�n ordenados o no

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O.
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos.

using namespace std;

int main()																		//Funci�n principal.
{
	int anio=0;									        						//Declaracion de variables como enteros
	
	bool bisiesto;																//Valores booleanas para comprobar veracidad de expresiones
	
	cout << "INSERTE ANIO: ";												//Pide al usuario que introduzca los datos
	cin >> anio;
	
	
	bisiesto = (anio % 4 == 0) || (anio % 400 == 0);				//Comprueba si el a�o introducido es divisible por 4 � por 400
	
	
	if(bisiesto == 1)															//IF: Si es cierta la expresi�n anterior muestra que es bisiesto
	{
		cout << "\n\nEl anio " << anio << " es bisiesto\n\n";
		
		system("pause");
	}
	
	else																			//ELSE: Si no es cierta, muestra que no es bisiesto
	{
		cout << "\n\nEl anio " << anio << " NO es bisiesto\n\n";
		
		system("pause");
	}
}
