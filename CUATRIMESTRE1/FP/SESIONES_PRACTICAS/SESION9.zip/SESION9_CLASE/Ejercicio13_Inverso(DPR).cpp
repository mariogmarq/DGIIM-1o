/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

void Cambiador(int numero){
   int resultado = 0;
   
   do{
      resultado = numero % 10;
      cout << resultado;
      numero = numero / 10;
   }while(numero != 0);
}

int main(){
   int numero = 0;
   
   cout << "INSERTE NUMERO: ";
   cin >> numero;
   
   cout << "\n\n";
   Cambiador(numero);
}
