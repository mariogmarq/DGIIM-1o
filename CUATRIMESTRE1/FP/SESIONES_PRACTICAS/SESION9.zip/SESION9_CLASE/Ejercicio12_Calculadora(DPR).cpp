/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

void Menu(){
   cout << "===============================\n";
   cout << " OPCIONES DE CALCULADORA\n";
   cout << "===============================\n";
   cout << " 1. Suma (+)\n";
   cout << " 2. Resta (-)\n";
   cout << " 3. Multiplicacion (*)\n";
   cout << " 4. Division (/)\n";
   cout << " 5. MCM (m)\n";
   cout << " 6. MCD (d)\n";
   cout << "===============================\n";
   
   cout << "SINTAXIS: num1 (caracter) num2\n\n";
}

int Calculate(int num1, char caracter, int num2){
   int resultado = 0;
   
   if(caracter == '+'){
      resultado = num1 + num2;
   }
   else{
      if(caracter == '-'){
         resultado = num1 - num2;
      }
      else{
         if(caracter == '*'){
            resultado = num1 * num2;
         }
         else{
            if(num2 == 0){
               cout << "\nERROR: DIVISION POR 0\n";
               resultado = 0;
            }
            else{
               resultado = num1 / num2;
            }
         }
      }
   }
   return resultado;
}

int MCM(int num1, int num2){
	int contador = 2, respuesta = 0;
	bool mcm = false;
	while(!mcm){
		mcm = (contador % num1 == 0 && contador % num2 == 0);
		if(mcm){
			respuesta = contador;
		}
		
		else{
			contador++;
		}
	}
	return respuesta;
}

int MCD(int num1, int num2){
   int maximo_divisor = 0;
   int mcd = 0;
   if(num1 > num2){
      maximo_divisor = num1;
   }
   else{
      maximo_divisor = num2;
   }
   for(int divisor=1; divisor<=maximo_divisor; divisor++){
      if(num1 % divisor == 0 && num2 % divisor == 0){
         mcd = divisor;
      }
   }
   return mcd;
}

bool Terminador(char terminador){
   bool respuesta;
   if(terminador == 'n' || terminador == 'N'){
      respuesta = false;
   }
   if(terminador == 'Y' || terminador == 'y'){
      respuesta = true;
   }
   return respuesta;
}

int main(){
   int num1 = 0, num2 = 0;
   char operador = 'a', terminador = 'b';
   bool operador_valido = true;
   
   Menu();
   do{
      do{
         cout << ">>> ";
         cin >> num1 >> operador >> num2;
      }while(num1 < 0 || num2 < 0);
   
      operador_valido = operador == '+' || operador == '-' || operador == '*' || operador == '/' ||
      operador == 'm' || operador == 'd';
   
      if(!operador_valido){
         cout << "\n\nERROR: OPERACION NO PERMITIDA EN CALCULADORA";
         return 0;
      }
   
      if(operador == 'm'){
         cout << "\nMCM: " << MCM(num1, num2);
      }
      else{
         if(operador == 'd'){
            cout << "\nMCD: " << MCD(num1, num2);
         }
         else{
            cout << "\n\nRESULTADO OPERACION ARITMETICA DE: \n";
            cout << num1 << " " << operador << " " << num2 << " = " << Calculate(num1, operador, num2);
         }
      }
      do{
         cout << "\n\nDesea continuar? [Y/N]: ";
         cin >> terminador;
      }while(terminador != 'n' && terminador != 'N' && terminador != 'Y' && terminador != 'y');
   }while(Terminador(terminador));
}
  
