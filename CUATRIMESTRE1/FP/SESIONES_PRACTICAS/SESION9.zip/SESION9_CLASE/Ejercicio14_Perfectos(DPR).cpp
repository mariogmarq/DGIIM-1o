/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

int Perfecto(int tope){
	int contador;
	int total;
	
	for(int i=2; i<=tope; i++){
		total = 0;
		contador = 1;
		
		do{
			if(i % contador == 0){
				total += contador;
			}
			contador++;
		}while(contador < i);
		
		if(total==i){
			cout << i << " ";
		}
	}
}

int main(){
	int tope = 0;
	
	do{
		cout << "INSERTE NUMERO POSITIVO: ";
		cin >> tope;
	}while(tope<=0);
	
	cout << "\nNUMEROS PERFECTOS: ";
	Perfecto(tope);
}
