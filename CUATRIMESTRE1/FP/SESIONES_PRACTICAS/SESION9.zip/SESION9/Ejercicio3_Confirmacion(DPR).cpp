/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

//FUNCION PARA CONFIRMAR RESPUESTA
//USO: CARACTER DEBE SER 'S' � 's' � 'N' � 'n'
bool Confirmar(char caracter){
	/*DESCRIPCION: Si caracter = 'S' � 's', se devuelve true. Si no, se devuelve false.*/
	bool respuesta;
	
	if(caracter == 'S' || caracter == 's'){
		respuesta = true;
	}
	
	else{
		respuesta = false;
	}
	
	return respuesta;
}

int main(){
	char caracter = 'a';
	bool valido = false;
	
	//PIDE CONFIRMACION HASTA QUE SE CUMPLA LA CONDICI�N DE "V�LIDO"
	do{
		cout << "DESEA CONTINUAR?: ";
		cin >> caracter;
		
		valido = (caracter == 'S' || caracter == 's' || caracter == 'N' || caracter == 'n');
	}while(!valido);
	
	cout << "\n1 = true // 0 = false: " << Confirmar(caracter);
}
