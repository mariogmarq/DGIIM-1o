/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

int MCM(int num1, int num2){
	int contador = 2, respuesta = 0;
	bool mcm = false;
	
	while(!mcm){
		mcm = (contador % num1 == 0 && contador % num2 == 0);
		if(mcm){
			respuesta = contador;
		}
		
		else{
			contador++;
		}
	}
	
	return respuesta;
}

int main(){
	int num1 = 0, num2 = 0;
	
	do{
		cout << "Inserte numeros positivos A y B (separados por espacios): ";
		cin >> num1 >> num2;
	}while(num1 <= 0 || num2 <= 0);
	
	cout << "\nMINIMO COMUN MULTIPLO: " << MCM(num1, num2);
}
