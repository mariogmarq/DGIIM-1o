/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

int Amigos(int num1, int num2){
	int maximo_divisor = 0;
	int suma1 = 0, suma2 = 0;
	
	for(int i=num1; i<=num2; i++){
		for(int j=num1+1; j<=num2; j++){
			for(int divisor=1; divisor<=j; divisor++){
				if(i % divisor == 0){
					suma1 += divisor;
					cout << "\n" << suma1;
				}
				
				if(j % divisor == 0){
					suma2 += divisor;
					cout << "\n" << suma2;
				}
				
				if((suma1 == j && suma2 == i) && (i < j)){
					cout << "AMIGOS: " << i << " " << j << "\n";
				}
			}
			suma1 = suma2 = 0;
		}
	}
}

int main(){
	int numero1 = 0, numero2 = 0;
	
	do{
		cout << "Inserta intervalo de numeros (separados por espacios): ";
		cin >> numero1 >> numero2;
	}while((numero1 <= 0 || numero2 <= 0) || (numero1 > numero2));
	
	Amigos(numero1, numero2);
}
	
