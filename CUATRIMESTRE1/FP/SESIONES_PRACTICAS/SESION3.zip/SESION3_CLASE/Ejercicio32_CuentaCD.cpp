//CODIGO FUENTE CREADO POR DANIEL P�REZ RUIZ

#include <iostream>
#include <string>

using namespace std;

struct CuentaCD 
{
   double saldo;
   double tasa_de_interes;
   int plazo;
   char inicial1;
   char inicial2;
};

int main()
{
   CuentaCD cuenta;
   
   /*APARTADO A: cuenta.saldo
   
   Est� bien escrito.
   Tipo de dato: double */
   
   cout << "Inserte saldo: ";
   cin >> cuenta.saldo;
   
   
   /*APARTADO B: cuenta.tasa_de_interes
   
   Est� bien escrito
   Tipo de dato: double*/
   
   cout << "Inserte tasa de interes: ";
   cin >> cuenta.tasa_de_interes;
   
   
   /*APARTADO C: CuentaCD.plazo
   
   NO est� bien escrito -> Correcto: cuenta.plazo
   Tipo de dato: int*/
   
   cout << "Inserte Plazo: ";
   cin >> cuenta.plazo;
   
   
   /*APARTADO D: cuenta_ahorros.inicial1
   
   NO est� bien escrito -> Correcto: cuenta.inicial1
   Tipo de dato: char*/
   
   cout << "Inserte inicial1: ";
   cin >> cuenta.inicial1;
   
   
   /*APARTADO E: cuenta.inicial2
   
   Est� bien escrito
   Tipo de dato: char*/
   
   cout << "Inserte inicial2: ";
   cin >> cuenta.inicial2;
   
   
   /*APARTADO F: cuenta
   No est� bien escrito -> cuenta.<campo>*/
   
   cout << "\n\n===========================================\n\n";
   
   cout << "CUENTA SALDO: " << cuenta.saldo << endl;
   cout << "CUENTA TASA DE INTERES: " << cuenta.tasa_de_interes << endl;
   cout << "CUENTA PLAZO: " << cuenta.plazo << endl;
   cout << "CUENTA INICIAL 1: " << cuenta.inicial1 << endl;
   cout << "CUENTA INICIAL 2: " << cuenta.inicial2 << endl << endl;
   
   system("pause");
}
   
