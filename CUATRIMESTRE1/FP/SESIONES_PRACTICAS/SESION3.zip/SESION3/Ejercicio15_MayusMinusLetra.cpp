/*CAMBIO DE CAR�CTER MAY�SCULA A MIN�SCULA

Se pedir� al usuario introducir una letra en may�sculas. Despu�s
teniendo en cuenta la relaci�n entre los datos enteros y car�cteres
gracias a la tabla de valores ASCII, se pasar� esa letra a min�scula.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ */


#include <iostream>					//Inclusi�n de librer�a de recursos I/O

using namespace std;

int main ()											//Funci�n principal
{
	char caracter;									//Variable a utilizar para almacenar car�cter
	
	
	cout << "INSERTE UNA LETRA (EN MAYUSCULAS): ";				//Pide a usuario que introduzca los datos
	cin >> caracter;
	
	caracter = caracter + 32;									//Se procede a cambiar la letra may�scula por min�scula
	
	cout << "\n\nLA LETRA EN MINUSCULA ES: " << caracter;		//Devuelve letra min�scula al usuario		
	
	cout << "\n\n";
	system("pause");
}
