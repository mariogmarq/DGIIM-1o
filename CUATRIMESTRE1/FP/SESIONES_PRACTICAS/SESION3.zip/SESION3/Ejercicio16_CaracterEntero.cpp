/*CAMBIO DE CAR�CTER NUM�RICO A ENTERO

Se pedir� al usuario introducir un n�mero del 0 al 9 y se asignar�
a una variable de tipo car�cter. Despu�s se devolver� al usuario
el mismo valor que introdujo pero como un dato de tipo entero.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ */

#include <iostream>

using namespace std;

int main ()											//Funci�n principal
{
	int entero; 									//Declaraci�n de variables a utilizar
	char caracter;
	
	
	
	cout << "=======================================\n";				//Mensaje de bienvenida al usuario
	cout << "CONVERSION DE CARACTER A ENTERO\n";
	cout << "=======================================\n";
	
	cout << "\nInserte numero (del 0 al 9): ";							//Pide a usuario que introduzca los datos
	cin >> caracter;
	

	entero = caracter - 48;												//Conversi�n de car�cter a entero.
	
	cout << "\nEl valor numerico es: " << entero;						//Devuelve los datos al usuario

	cout << "\n\n";
	system("pause");

}
