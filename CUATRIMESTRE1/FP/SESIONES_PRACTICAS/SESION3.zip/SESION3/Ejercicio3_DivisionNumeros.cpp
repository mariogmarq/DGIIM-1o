/*DIVISI�N DE N�MEROS

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>													//Inclusi�n de librer�a de recursos I/O

using namespace std;



int main()															//Funci�n principal
{
	int numero1, numero2;											//Variables para guardar n�meros (como enteros)
	bool verificate_1, verificate_2, verificate_3;					//Variables booleanas para verificar expresiones l�gicas
	
	
	
	cout << "===========================================\n";		//Mensaje de bienvenida al usuario
	cout << "COMPROBAR DIVISIBILIDAD DE DOS NUMEROS\n";
	cout << "===========================================\n\n";
	
	cout << "INSERTE NUMERO 1: ";									//Pide al usuario que introduzca los datos
	cin >> numero1;
	
	cout << "INSERTE NUMERO 2: ";
	cin >> numero2;
	
	
	for(int i=0; i<10; i++)											//FOR: Realiza 10 saltos de linea.
	{
		cout << "\n";
	}
	
	
	/*ALGORITMO: A continuaci�n procedo a explicar c�mo se va a determinar la divisibilidad entre los dos n�meros.
	Se presentan 4 casos posibles:
	
	CASO A: N�MERO 1 y N�MERO 2 se dividen entre s�. (S�lo pasa s�, y s�lo s� numero1==numero2
	CASO B: N�MERO 1 DIVIDE A N�MERO 2. Esto quiere decir que numero2 % numero1 = 0.
	CASO C: N�MERO 2 DIVIDE A N�MERO 1. Esto quiere decir que numero1 % numero2 = 0.
	CASO D: N�MERO 1 Y N�MERO 2 no se dividen entre s�.
	
	Se utilizar�n las variables booleanas verificate_1, verificate_2, verificate_3 para ir comprobando poco a poco
	qu� caso sucede, utilizando adem�s tambi�n sentencias IF anidadas.
	
	1. verificate_1 -> comprueba el CASO A. Si devuelve 1, muestra por pantalla que los n�meros se dividen entre s�.
	2. verificate_2 -> (Si verificate_1 no es cierto) Se encarga de comprobar el CASO B. Si devuelve 1, muestra
	por pantalla que N�MERO1 DIVIDE A N�MERO2.
	3. verificate_3 -> (Si verificate_1 y verificate_2 no es cierto) Se encarga de comprobar el CASO C. Si devuelve 1,
	muestra por pantalla que N�MERO2 DIVIDE A N�MERO1.
	4. ELSE: El �ltimo ELSE hace mostrar por pantalla que N�MERO1 Y N�MERO2 NO SE DIVIDEN ENTRE S�.*/
	
	
	verificate_1 = numero1 % numero2 == 0 && numero2 % numero1 == 0;								//COMPRUEBA CASO A
	
	if(verificate_1 == 1)																			//SI CASO A SE CUMPLE
	{
		cout << "Los numeros: \n" 
		<< "NUMERO 1: " << numero1 << "\nNUMERO 2: " << numero2 << "\n\nSE DIVIDEN ENTRE SI.";	
	}
	
	else																							//SI CASO A NO SE CUMPLE: CASO B�?
	{
		verificate_2 = numero2 % numero1 == 0;														//COMPRUEBA CASO B
		
		if(verificate_2 == 1)																		//SI CASO B SE CUMPLE
		{
				cout << "EL NUMERO " << numero1 << " DIVIDE A " << numero2;								
			}
		
		else																						//SI CASO B NO SE CUMPLE: CASO C�?
		{
			verificate_3 = numero1 % numero2 == 0;													//COMPRUEBA CASO C
			
			if(verificate_3 == 1)																	//SI CASO C SE CUMPLE
			{
				cout << "EL NUMERO " << numero2 << " DIVIDE A " << numero1;
			}
			
			else																					//SI CASO C NO SE CUMPLE: CASO D
			{
				cout << "Los numeros: \n" 
				<< "NUMERO 1: " << numero1 << "\nNUMERO 2: " << numero2 << "\n\nNO SE DIVIDEN ENTRE SI.";	
			}
			
		}
	}
	
	cout << "\n\n\n";
	system("pause");
}

