/*INTERCAMBIO DEL VALOR DE 3 VARIABLES

Se asignar� un determinado valor a las variables x,y,z. Despu�s se proceder� a intercambiar
sus valores de forma que:

Valor[X] => Valor[Y]
Valor[Y] => Valor[Z]
Valor[Z] => Valor[X]

C�DIGO FUENTE POR DANIEL P�REZ RUIZ */


#include <iostream>					//Inclusi�n de librer�a de recursos I/O
#include <cmath>					//Inclusi�n de librer�a de recursos matem�ticos

using namespace std;

int main ()
{
	int x, y, z;					//Variables a utilizar
	int swap; 						//Variable de intercambio
	
	x = 10;							//Asignaci�n de valor a variables
	y = 20;
	z = 30;
	
	
	//PROCESO DE INTERCAMBIO DE VALOR DE VARIABLES
	
	swap = x;						
	x = z;
	z = y;
	y = swap;
	
	
	//MUESTRA LOS RESULTADOS POR PANTALLA
	
	cout << "Valor X: " << x;
	cout << "\nValor Y: " << y;
	cout << "\nValor Z: " << z;
	
	cout << "\n\n";
	system("pause");
}
