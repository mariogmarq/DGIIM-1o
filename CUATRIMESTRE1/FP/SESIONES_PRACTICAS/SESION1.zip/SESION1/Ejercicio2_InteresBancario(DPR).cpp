/*PROGRAMA PARA CALCULAR CAPITAL TOTAL APLICANDO UN INTER�S BANCARIO

Se pedir� al usuario introducir el valor del capital inicial depositado
en el banco. Despu�s se le pedir� introducir el inter�s al que se ver�
afectado ese capital.

Se admite meter el inter�s en tanto por ciento y en tanto por uno.

Se mostrar� el pantalla el resultado final despu�s de operar en base
a la f�rmula proporcionada.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>					//Inclusi�n de librear�a de recursos I/O

using namespace std;

int main()								//Funci�n principal
{
	double capital;					//Declaraci�n de variables con
	double interes;					//las que trabajaremos (como reales)
	double total;
	
	
	cout << "===============================================";				//Mensaje de bienvenida al usuario
	cout << "\nPROGRAMA PARA CALCULAR EL CAPITAL TOTAL";
	cout << "\n===============================================";
	
	
	cout << "\n\nInserte capital inicial: ";													//Pide al usuario que introduzca
	cin >> capital;																					//los datos.
	
	cout << "Inserte interes a aplicar: ";
	cin >> interes;
	
	if(interes<1)																						//Si el interes se escribe en tanto por ciento
		{																									//el IF se encarga de que ese dato pase por
			total = capital + capital * interes;												//una f�rmula que ya haga la operaci�n sin
		 																									//realizar (interes/100).
			
			cout << "\n\nEl capital total es de: " << total << " euros\n\n";			//Devuelve el valor total al usuario
		}

	else																									//Si el inter�s se escribe como n�mero natural
		{																									//ELSE se encarga de operar con la f�rmula			
			total = capital + capital * (interes / 100);										//proporcionada.
			
			cout << "\n\nEl capital total es de: " << total << " euros\n\n";			//Devuelve el valor total al usuario
		}
		
	system("pause");	
}
