/*PROGRAMA PARA CALCULAR LONGITUD Y �REA DE UNA CIRCUNFERENCIA

Se pedir� al usuario introducir el valor del radio de la circunferencia.
Se le recordar� adem�s que introduzca el radio en cm.

Se crear� la constante PI con 15 decimales para una aproximaci�n m�s exacta.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>					//Inclusi�n de librear�a de recursos I/O
#include <cmath>						//Inclusi�n de librer�a de recursos matem�ticos

using namespace std;

int main()								//Funci�n principal
{
	double radio;						//Declaraci�n de variables con
	double area;						//las que trabajaremos (como reales)
	double longitud;
	
	const double PI = 3.141592653589793; 				//Constante PI
	
	
	cout << "===============================================";				//Mensaje de bienvenida al usuario
	cout << "\nPROGRAMA PARA CALCULAR AREA Y LONGITUD";
	cout << "\nDE UNA CIRCUNFERENCIA";
	cout << "\n===============================================";
	
	
	cout << "\n\nInserte radio (cm): ";												//Pide al usuario que introduzca
	cin >> radio;																			//el valor del radio.
	
	
	area = PI * radio * radio;															//C�lculo de �rea.
	
	longitud = 2 * PI * radio;															//C�lculo de longitud.
	
	cout << "\n\nEl area es: " << area << " cm2";								//Devuelve el valor de �rea y
	cout << "\nLa longitud es: " << longitud << " cm\n\n";					//longitud al usuario.
	
	system("pause");
}
