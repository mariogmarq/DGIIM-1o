/*PROGRAMA PARA INTERCAMBIAR EDAD DE DOS PERSONAS

Se pedir� al usuario introducir dos variables enteras. Despu�s se
mostrar� en pantalla los datos introducidos y despu�s se intercambiar�n
sus valores.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>					//Inclusi�n de librear�a de recursos I/O

using namespace std;

int main()														//Funci�n principal
{
	int edad_juan;												//Declaraci�n variables
	int edad_pedro;											//para edad de Juan y Pedro.
	
	int exchange;												//Declaraci�n variable de intercambio.
	
	
	cout << "===============================================";				//Mensaje de bienvenida al usuario
	cout << "\nINTERCAMBIO DE EDADES DE PEDRO Y JUAN";
	cout << "\n===============================================";
	
	
	cout << "\n\nInserte edad de Juan: ";											//Introducci�n edad de Juan				
	cin >> edad_juan;																
	
	cout << "Inserte edad de Pedro: ";												//Introducci�n edad de Pedro
	cin >> edad_pedro;
	
	for(int i=1; i<=100; i++)															//FOR: Realiza 100 saltos de linea.
	{																							//(finalidad est�tica)
		cout << "\n";
	}
	
	cout << "La edad de Juan introducida es: " << edad_juan;					//Muestra las edades introducidas
	cout << "\nLa edad de Pedro introducida es: " << edad_pedro;
	
	exchange = edad_juan;																//Se procede a realizar el cambio
	edad_juan = edad_pedro;																//utilizando la variable exchange
	edad_pedro = exchange;
	
	cout << "\n\n================================================\n";
	
	cout << "\nLa edad de Juan ahora es: " << edad_juan;						//Muestra las edades intercambiadas.
	cout << "\nLa edad de Pedro ahora es: " << edad_pedro;
	
	cout << "\n\n";
	
	system("pause");
}
