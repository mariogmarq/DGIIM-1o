/*PROGRAMA PARA CALCULAR DISTRIBUCI�N NORMAL POR F�RMULA

Se pedir� al usuario introducir la media, desviaci�n normal y valor X.

Se crear� la constante PI con 15 decimales para una aproximaci�n m�s exacta.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>					//Inclusi�n de librear�a de recursos I/O
#include <cmath>						//Inclusi�n de librer�a de recursos matem�ticos

using namespace std;

int main()														//Funci�n principal
{
	double mean;												//Declaraci�n de mean (media)
	double stderivation;										//Declaraci�n de stderivation (desviaci�n media)
	double xvalue;												//Declaraci�n de x
	double gaussian;											//Declaraci�n de variable resultado
	double c;													//Variable para primera parte de la f�rmula a usar
	
	const double PI = 3.141592653589793; 				//Constante PI
	
	
	cout << "===============================================";				//Mensaje de bienvenida al usuario
	cout << "\nDISTRIBUCION NORMAL (GAUSSIANA)";
	cout << "\n===============================================";
	
	
	cout << "\n\nInserte media: ";										//Pide al usuario que introduzca
	cin >> mean;																//media, desviaci�n, y valor de X.
	
	cout << "Inserte desviacion normal: ";
	cin >> stderivation;
	
	cout << "Inserte valor de X: ";
	cin >> xvalue;
	
	c = 1 / (stderivation * sqrt(2 * PI));
	gaussian = c * exp(-0.5 * pow((xvalue - mean) / stderivation, 2));
	
	
	
	cout << "\n\nGaussiana(X) = " << gaussian;						//Despu�s de operar muestra el resultado al usuario	
	
	cout << "\n\n";
	
	system("pause");
}
