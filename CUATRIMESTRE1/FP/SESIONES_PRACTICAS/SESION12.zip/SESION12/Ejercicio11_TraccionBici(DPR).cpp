/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <vector>

using namespace std;

const int LONGITUD_PINION = 7;
const int LONGITUD_ESTRELLA = 3;

class TraccionBici{
	private:
		const int pinion[LONGITUD_PINION] = {1,2,3,4,5,6,7};
		const int estrella[LONGITUD_ESTRELLA] = {1,2,3};
		int posicion_pinion;
		int posicion_estrella;
		vector<char> movimientos;
		
		bool SeguridadMecanismo(char componente){
			bool respuesta;
			
			if(componente == 'p'){
				if(-1 < posicion_pinion && posicion_pinion < 7){
					respuesta = true;
				}
				else{
					respuesta = false;
				}
			}
			if(componente == 'e'){
				if(-1 < posicion_estrella && posicion_estrella < 3){
					respuesta = true;
				}
				else{
					respuesta = false;
				}
			}
			return respuesta;
		}
		
		bool SeguridadCadena(){
			bool respuesta = true;
			
			if(GetPosicionEstrella() == 1 && GetPosicionPinion() >= 5){
				respuesta = false;
			}
			if(GetPosicionEstrella() == 2 && GetPosicionPinion() == 1 || GetPosicionEstrella() == 2 && GetPosicionPinion() == 7){
				respuesta = false;
			}
			if(GetPosicionEstrella() == 3 && GetPosicionPinion() <= 3){
				respuesta = false;
			}
			return respuesta;
		}
	public:
		TraccionBici(){
			posicion_pinion = 0;
			posicion_estrella = 0;
		}
		void LeerSecuencia(){
			char caracter;
			vector<char> vec_parameter;
	
			cout << "INSERTE SECUENCIA >>> ";
			do{
	    	   cin >> caracter;
			   if(caracter != '#'){
			   		vec_parameter.push_back(caracter);
				}
			}while(caracter != '#');
			
			movimientos = vec_parameter;
		}
		void SetPosiciones(){
			for(int i=0; i<movimientos.size(); i++){
				if(movimientos[i] == 'E'){
					if(movimientos[i+1] == 'S'){
						posicion_estrella++;
						if(!SeguridadMecanismo('e')){
							posicion_estrella--;
						}
					}
					if(movimientos[i+1] == 'B'){
						posicion_estrella--;
						if(!SeguridadMecanismo('e')){
							posicion_estrella++;
						}
					}
				}
				if(movimientos[i] == 'P'){
					if(movimientos[i+1] == 'S'){
						posicion_pinion++;
						if(!SeguridadMecanismo('p')){
							posicion_estrella--;
						}
					}
					if(movimientos[i+1] == 'B'){
						posicion_pinion--;
						if(!SeguridadMecanismo('p')){
							posicion_estrella++;
						}
					}
					if(movimientos[i+1] == 'T'){
						posicion_pinion += 2;
						if(!SeguridadMecanismo('p')){
							posicion_estrella -= 2;
						}
					}
					if(movimientos[i+1] == 'C'){
						posicion_pinion -= 2;
						if(!SeguridadMecanismo('e')){
							posicion_estrella += 2;
						}
					}
				}
			}
			if(!SeguridadCadena()){
				posicion_estrella = posicion_pinion = 0;
			}
		}
		int GetPosicionEstrella(){
			return estrella[posicion_estrella];
		}
		int GetPosicionPinion(){
			return pinion[posicion_pinion];
		}
		void GetPosiciones(){
			if(posicion_estrella == 0 && posicion_pinion == 0 && movimientos.size() != 0){
				cout << "\n\nPOR TEMAS DE PROTECCION DE CADENA, SE RESETEARA LA ESTRELLA Y PINION\n";
			}
			cout << "\nPosicion Estrella: " << estrella[posicion_estrella];
			cout << "\nPosicion Pinion: " << pinion[posicion_pinion];
		}
};

int main(){
	TraccionBici bici;
	
	bici.LeerSecuencia();
	bici.SetPosiciones();
	bici.GetPosiciones();
}
