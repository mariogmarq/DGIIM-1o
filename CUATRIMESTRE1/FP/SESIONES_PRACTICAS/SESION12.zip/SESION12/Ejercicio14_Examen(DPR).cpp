/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Examen{
	private:
		string asignatura;
		vector<string> preguntas;
		vector<char> soluciones;
	public:
		Examen(){
		}
		void SetAsignatura(string asign_value){
			asignatura = asign_value;
		}
		//FUNCION PARA A�ADIR PREGUNTAS Y RESPUESTAS (LISTA INICIAL) 
		void SetTest(){
			string pregunta;
			char respuesta, continuar='a';
			do{
				if(continuar != 'N' && continuar != 'n'){
					cout << "Inserte nueva pregunta: ";
					cin.ignore();
					getline(cin, pregunta);
				
					cout << "Inserte respuesta asociada a pregunta: ";
					cin >> respuesta;
				
					preguntas.push_back(pregunta);
					soluciones.push_back(respuesta);
				}
				
				do{
					cout << "\nDESEA CONTINUAR?[Y/N] >>> ";
					cin >> continuar;
				}while(continuar != 'Y' && continuar != 'y' && continuar != 'N' && continuar != 'n');
				cout << "\n";
			}while(continuar == 'Y' || continuar == 'y');
		}
		void NuevaPregunta(){
			string new_pregunta;
			char new_solucion;
			
			cout << "\nInserte nueva Pregunta: ";
			cin.ignore();
			getline(cin, new_pregunta);
			
			cout << "Inserte respuesta a Pregunta asociada: ";
			cin >> new_solucion;
			
			preguntas.push_back(new_pregunta);
			soluciones.push_back(new_solucion);
		}
		int NumeroPreguntas(){
			return preguntas.size();
		}
		void GetEnunciado(){
			int busqueda_pregunta;
			do{
				cout << "Inserte numero de pregunta a buscar: ";
				cin >> busqueda_pregunta;
			}while(busqueda_pregunta < 0 || busqueda_pregunta > preguntas.size());
			
			cout << "\n\nENUNCIADO PREGUNTA " << busqueda_pregunta << " : " << preguntas[busqueda_pregunta];
		}
		void GetRespuesta(){
			int busqueda_respuesta;
			do{
				cout << "Inserte numero de pregunta a buscar respuesta: ";
				cin >> busqueda_respuesta;
			}while(busqueda_respuesta < 0 || busqueda_respuesta > soluciones.size());
			
			cout << "\n\nRESPUESTA DE LA PREGUNTA " << busqueda_respuesta << ": " << soluciones[busqueda_respuesta];
		}
		void MostrarPreguntas(){
			for(int i=0; i<preguntas.size(); i++){
				cout << i << ". " << preguntas[i] << "\n";
			}
		}
		vector<char> LeerRespuestas(){
			vector<char> soluciones_alumno;
			char respuesta;
			cout << "Inserte respuestas a las preguntas proporcionadas anteriormente (X significa no responder)\n";
			for(int i=0; i<NumeroPreguntas();i++){
				cout << "PREGUNTA " << i << ": ";
				cin >> respuesta;
				soluciones_alumno.push_back(respuesta);
			}
	
			return soluciones_alumno;
		}
		int ObtencionResultados(){
			int calificacion=0;
			
			vector<char> resultados = LeerRespuestas();
			
			for(int i=0; i<NumeroPreguntas();i++){
				if(soluciones[i] == resultados[i]){
					calificacion++;
				}
				if(soluciones[i] != resultados[i] && resultados[i] != 'X'){
					calificacion--;
				}
			}
			if(calificacion < 0){
				calificacion = 0;
			}
			return calificacion;
		}
};

int main(){
	Examen examen1;
	string asignatura_value;
	string line = "\n\n===============================================\n";
	
	//PEDIR ASIGNATURA
	cout << "Inserte asignatura: ";
	cin >> asignatura_value;
	examen1.SetAsignatura(asignatura_value);
	cout << line;
	
	//PREGUNTAS INICIALES
	examen1.SetTest();
	cout << line;
	
	//A�ADIR UNA PREGUNTA NUEVA
	examen1.NuevaPregunta();
	cout << line;
	
	//MOSTRAR NUMERO DE PREGUNTAS TOTALES
	cout << "Numero preguntas: " << examen1.NumeroPreguntas();
	cout << line;
	
	//DEVUELVE EL ENUNCIADO DE UNA PREGUNTA
	examen1.GetEnunciado();
	cout << line;
	
	//DEVUELVE LA RESPUESTA DE UNA PREGUNTA
	examen1.GetRespuesta();
	cout << line;
	
	//MUESTRA LAS PREGUNTAS Y HACER EXAMEN
	examen1.MostrarPreguntas();
	cout << "\n\nCALIFICACION: " << examen1.ObtencionResultados();
}
