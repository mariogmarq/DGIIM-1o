/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <string>

using namespace std;

//FUNCION PARA COMPROBAR QUE LA DIMENSION DE LA MATRIZ ES CORRECTA
bool CheckMatriz(int fila, int columna){
	if(fila < 100 && columna < 100){
		return true;
	}
	else{
		return false;
	}
}

//FUNCION PARA LEER LOS DATOS DE LA MATRIZ
double LeerMatriz(int filas, int columnas, double Matriz[100][100]){
	for(int i=0; i<filas; i++){
		for(int j=0; j<columnas; j++){
			cout << "FILA " << i << " // COLUMNA " << j;
			cout << "\n>>> ";
			cin >> Matriz[i][j];
		}
	}
}

//FUNCION PARA MOSTRAR LOS DATOS DE LA MATRIZ
double MostrarMatriz(int filas, int columnas, double Matriz[100][100]){
	for(int j=0; j<filas; j++){
		for(int k=0; k<columnas; k++){
			cout << Matriz[j][k] << " ";
		}
		cout << "\n";
	}
}

//FUNCION PARA C�LCULO DE MATRIZ TRANSPUESTA
double MatrizTranspuesta(int filas, int columnas, double Matriz[100][100], double MTrans[100][100]){
	for(int i=0; i<filas; i++){
		for(int k=0; k<columnas; k++){
			MTrans[k][i] = Matriz[i][k];
		}
	}
}

//FUNCION PARA C�LCULO DE POSICION M�XIMO DE LOS M�NIMOS DE CADA FILA
double MaximoMinor(int filas, int columnas, double Matriz[100][100]){
	int pos_i, pos_j, maximo_minimos = 0; 
	int minimo = 10000, candidato_minimo;
	int vector_minimos[100] = {0};
	
	for(int i=0; i<filas; i++){
		for(int j=0; j<columnas; j++){
			candidato_minimo = Matriz[i][j];
			if(candidato_minimo < minimo){
				minimo = candidato_minimo;
				pos_j = j;
			}
		}
		vector_minimos[i] = minimo;
		minimo = 10000;
	}
	
	maximo_minimos = vector_minimos[0];
	for(int i=1; i<filas; i++){
		if(vector_minimos[i] > maximo_minimos){
			maximo_minimos = vector_minimos[i];
			pos_i=i;
		}
		else{
			pos_i=0;
		}
	}

	cout << "FILA: " << pos_i << " / COLUMNA: " << pos_j;
}

//FUNCION PARA COMPROBAR SI UN ELEMENTO ES MAXIMO DE SU FILA Y M�NIMO DE SU COLUMNA
bool Maximin(int filas, int columnas, double Matriz[100][100]){
	int vector_maximofilas[100] = {0}, vector_minimocolumnas[100] = {0};
	int maximo_fila = Matriz[0][0], minimo_columna = Matriz[0][0];
	int compare = 0;
	
	for(int i=0; i<filas; i++){
		for(int j=1; j<columnas; j++){
			if(maximo_fila < Matriz[i][j]){
				maximo_fila = Matriz[i][j];
			}
			
			if(minimo_columna > Matriz[i][j]){
				minimo_columna = Matriz[i][j];
			}
			vector_minimocolumnas[j];
		}
		vector_maximofilas[i] = maximo_fila;
	}
	
	if(filas < columnas){
		compare = filas;
	}
	
	else{
		compare = columnas;
	}
	
	for(int k=0; k<compare; k++){
		if(vector_maximofilas[k] == vector_minimocolumnas[k]){
			return true;
		}
	}
}	
			
//FUNCION PRODUCTO MATRICIAL
double ProductoMatricial(int filas, int columnas, double Matriz1[100][100], int filas2, int columnas2, double Matriz2[100][100]){
	double Producto_Matriz[100][100] = {0};
	
	if(columnas != filas2){
		cout << "\n\nERROR: PRODUCTO MATRICIAL NO COMPATIBLE\n";
		return 0;
	}
	
	for(int i=0; i<filas; i++){
		for(int j=0; j<columnas2; j++){
			for(int k=0; k<filas; k++){
				Producto_Matriz[i][j] += Matriz1[i][k] * Matriz2[k][j];
			}
		}
	}
	
	for(int x=0; x<filas; x++){
		for(int y=0; y<columnas2; y++){
			cout << Producto_Matriz[x][y] << " ";
		}
		cout << "\n";
	}
}
	

int main(){
	const int MAXIMA_DIMENSION = 100;
	double matriz_original [MAXIMA_DIMENSION][MAXIMA_DIMENSION] = {0};
	double matriz_transpuesta [MAXIMA_DIMENSION][MAXIMA_DIMENSION] = {0};
	double matriz_2 [MAXIMA_DIMENSION][MAXIMA_DIMENSION] = {0};
	
	int filas = 0, columnas = 0, filas2 = 0, columnas2 = 0;
	
	
	cout << "INSERTE NUMERO DE FILAS DE LA MATRIZ: ";
	cin >> filas;
	
	cout << "INSERTE NUMERO DE COLUMNAS DE MATRIZ: ";
	cin >> columnas;
	
	//CHECK DE DIMENSIONES MATRIZ
	if(!CheckMatriz(filas, columnas))
	{
		cout << "\n\nERROR: DIMENSION MAXIMA DE MATRIZ: " << MAXIMA_DIMENSION << "x" << MAXIMA_DIMENSION;
		return 0;
	}

	cout << "\n\n";
	
	//PIDE DATOS PARA LA MATRIZ
	LeerMatriz(filas, columnas, matriz_original);
	
	MatrizTranspuesta(filas, columnas, matriz_original, matriz_transpuesta);
	
	cout << "\n\nMATRIZ INTRODUCIDA: \n";
	MostrarMatriz(filas, columnas, matriz_original);
	
	cout << "\n\n******APARTADO A******";
	
	cout << "\n\nMATRIZ TRANSPUESTA: \n";
	MostrarMatriz(columnas, filas, matriz_transpuesta);
	
	cout << "\n\n******APARTADO B******";
	
	cout << "\n\nPOSICION DEL MAXIMO VALOR DE LOS MINIMOS DE CADA FILA: \n";
	MaximoMinor(filas, columnas, matriz_original);
	
	cout << "\n\n******APARTADO C******";
	
	cout << "\n\nMAXIMO DE FILA Y MINIMO DE COLUMNA: \n";
	if(Maximin(filas, columnas, matriz_original)){
		cout << "Existe un elemento MaxiMin";
	}
	
	else{
		cout << "NO existe un elemento Maximin";
	}
	
	cout << "\n\n******APARTADO D******";
	
	cout << "\n\nINSERTE NUMERO DE FILAS DE LA MATRIZ 2: ";
	cin >> filas2;
	
	cout << "INSERTE NUMERO DE COLUMNAS DE MATRIZ 2: ";
	cin >> columnas2;
	
	//CHECK DE DIMENSIONES MATRIZ
	if(!CheckMatriz(filas, columnas))
	{
		cout << "\n\nERROR: DIMENSION MAXIMA DE MATRIZ: " << MAXIMA_DIMENSION << "x" << MAXIMA_DIMENSION;
		return 0;
	}

	cout << "\n\n";
	
	//PIDE DATOS PARA LA MATRIZ 2
	LeerMatriz(filas2, columnas2, matriz_2);
	
	//CALCULO DEL PRODUCTO MATRICIAL
	cout << "\n\nPRODUCTO MATRICIAL: \n";
	ProductoMatricial(filas, columnas, matriz_original, filas2, columnas2, matriz_2);
}
	
	
