/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <cctype>
#include <string>

using namespace std;

int main()
{
	int N = 0, caracter=0, siguiente_caracter = 0, longitud = 0;
	int k = 0, a = 0;
	bool espacio = false;
	string cadena, username;
	
	cout << "Inserte cadena: ";
	getline(cin, cadena);

	cout << "Inserte numero: ";
	cin >> N;
	
	while(cadena[a] != '\0'){
		longitud++;
		a++;
	}
	
	while(cadena[caracter] != '\0'){
		if(!espacio){
			while(k < N){
				if(cadena[k] != ' '){
					username += tolower(cadena[k]);
				}
				k++;
			}
		}
		
		if(cadena[caracter] == ' '){
			espacio = true;
			siguiente_caracter = caracter+1;
			k=0;
			do{	
				username += tolower(cadena[siguiente_caracter]);
				k++;
				siguiente_caracter++;
				if(cadena[siguiente_caracter] == ' ' || cadena[siguiente_caracter] == '\0'){
					siguiente_caracter++;
					k = N;
				}
			}while(k < N);
		}
		caracter++;
	}

	cout << "\n\nNOMBRE SUGERIDO DE USUARIO: " << username;		
}
