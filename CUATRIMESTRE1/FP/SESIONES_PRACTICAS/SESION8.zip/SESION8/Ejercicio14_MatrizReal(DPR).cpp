/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

//FUNCION PARA COMPROBAR QUE LA DIMENSION DE LA MATRIZ ES CORRECTA
bool CheckMatriz(int fila, int columna){
	if(fila < 20 && columna < 20){
		return true;
	}
	else{
		return false;
	}
}

//FUNCION PARA LEER LOS DATOS DE LA MATRIZ
double LeerMatriz(int filas, int columnas, double Matriz[20][20]){
	for(int i=0; i<filas; i++){
		for(int j=0; j<columnas; j++){
			cout << "FILA " << i << " // COLUMNA " << j;
			cout << "\n>>> ";
			cin >> Matriz[i][j];
		}
	}
}

//FUNCION PARA MOSTRAR LOS DATOS DE LA MATRIZ
double MostrarMatriz(int filas, int columnas, double Matriz[20][20]){
	for(int j=0; j<filas; j++){
		for(int k=0; k<columnas; k++){
			cout << Matriz[j][k] << " ";
		}
		cout << "\n";
	}
}

//FUNCION SUMA DE LOS ELEMENTOS DE LAS FILAS DE UNA MATRIZ
double SumaFilas(int filas, int columnas, double Matriz[20][20], double vector[20]){
	int i = 0;
	for(int j=0; j<filas; j++){
		for(int k=0; k<columnas; k++){
			vector[i] += Matriz[j][k];
		}
		i++;
	}
	
	return vector[20];
}

//FUNCION SUMA DE LOS ELEMENTOS DE LAS COLUMNAS DE UNA MATRIZ
double SumaColumnas(int filas, int columnas, double Matriz[20][20], double vector[20]){
	int i = 0;
	for(int j=0; j<columnas; j++){
		for(int k=0; k<filas; k++){
			vector[i] += Matriz[k][j];
		}
		i++;
	}
	
	return vector[20];
}

int main(){
	const int MAXIMA_DIMENSION = 20;
	double matriz_original [MAXIMA_DIMENSION][MAXIMA_DIMENSION] = {0};
	double vector_filas [MAXIMA_DIMENSION] = {0};
	double vector_columnas [MAXIMA_DIMENSION] = {0};
	int filas = 0, columnas = 0;
	
	cout << "INSERTE NUMERO DE FILAS DE LA MATRIZ: ";
	cin >> filas;
	
	cout << "INSERTE NUMERO DE COLUMNAS DE MATRIZ: ";
	cin >> columnas;
	
	//CHECK DE DIMENSIONES MATRIZ
	if(!CheckMatriz(filas, columnas))
	{
		cout << "\n\nERROR: DIMENSION MAXIMA DE MATRIZ: " << MAXIMA_DIMENSION << "x" << MAXIMA_DIMENSION;
		return 0;
	}

	cout << "\n\n";
	
	//PIDE DATOS PARA LA MATRIZ
	LeerMatriz(filas, columnas, matriz_original);
	
	//MUESTRA LA MATRIZ INTRODUCIDA
	cout << "\n\nMATRIZ INTRODUCIDA: \n";
	MostrarMatriz(filas, columnas, matriz_original);
	
	//REALIZA LA SUMA DE LAS FILAS
	SumaFilas(filas, columnas, matriz_original, vector_filas);
	
	//MUESTRA VECTOR SUMA DE FILAS
	cout << "\n\nLA SUMA DE LAS FILAS ES: \n";
	for(int j=0; j<filas; j++){
		cout << vector_filas[j] << " ";
	}
	
	//REALIZA LA SUMA DE LAS COLUMNAS
	SumaColumnas(filas, columnas, matriz_original, vector_columnas);
	
	//MUESTRA VECTOR SUMA DE COLUMNAS
	cout << "\n\nLA SUMA DE LAS COLUMNAS ES: \n";
	for(int j=0; j<columnas; j++){
		cout << vector_columnas[j] << " ";
	}
}	
