/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <string>
#include <cctype>

using namespace std;

class Libro{
	private:
		string autor, libro, editorial, year;
	public:
		Libro(){
			autor="Unknown Autor";
			libro="Unknown Libro";
			editorial="Unknown Editorial";
			year="Unknown Year";
		}
		
		void SetAutor(string autor_value){
			autor=autor_value;
		}
		void SetLibro(string libro_value){
			libro=libro_value;
		}
		void SetEditorial(string editorial_value){
			editorial=editorial_value;
		}
		void SetYear(string year_value){
			year=year_value;
		}
		
		void MostrarDatos(){
			cout << "\nTITULO: " << libro;
			cout << "\nAUTOR: " << autor;
			cout << "\nEDITORIAL: " << editorial;
			cout << "\nANIO: " << year;
		}
		
		void CompareLibros(Libro libro2){
			bool equal_libro, equal_autor, equal_edit, equal_year;
			
			equal_libro = libro == libro2.libro;
			equal_autor = autor == libro2.autor;
			equal_edit = editorial == libro2.editorial;
			equal_year = year == libro2.year;
			
			if(equal_libro && equal_autor && equal_edit && equal_year){
				cout << "\n\nLOS LIBROS SON IGUALES";
			}
			else{
				cout << "\n\nLOS LIBROS NO SON IGUALES";
			}
		}
		
		void FindField(){
			char find;
			cout << "\nInserte campo a mostrar de " << libro << "\n";
			cout << "A. Autor\n E. Editorial\n Y. Anio\n >>> ";
			cin >> find;
			
			find = toupper(find);
			if(find == 'A'){
				cout << "\nAUTOR: " << autor;
			}
			if(find == 'E'){
				cout << "\nEDITORIAL: " << editorial;
			}
			if(find == 'Y'){
				cout << "\nANIO: " <<year;
			}
			if(find != 'A' && find != 'E' && find != 'Y'){
				cout << "\nCaracter no encontrado";
			}	
		}
};

void LeerDatos(Libro& libro){
	string autor, titulo, editorial, year;
	
	cout << "Inserte nombre autor: ";
	getline(cin, autor);
	libro.SetAutor(autor);
	cout << "Inserte nombre libro: ";
	getline(cin, titulo);
	libro.SetLibro(titulo);
	cout << "Inserte nombre editorial: ";
	getline(cin, editorial);
	libro.SetEditorial(editorial);
	cout << "Inserte anio publicacion: ";
	getline(cin, year);
	libro.SetYear(year);
}

int main(){
	Libro libro1, libro2;
	
	LeerDatos(libro1);
	libro1.MostrarDatos();
	
	cout << "\n\n";
	
	LeerDatos(libro2);
	libro2.MostrarDatos();
	
	libro1.CompareLibros(libro2);
	libro1.FindField();
}
	
	
