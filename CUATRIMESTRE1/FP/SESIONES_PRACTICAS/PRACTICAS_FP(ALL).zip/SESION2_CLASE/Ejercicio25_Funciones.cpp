/*C�LCULO DE VALORES DE UNA FUNCI�N

Se pide al usuario introducir el valor de 3 variables: x,y,h. Despu�s se
calcular�n las 3 funciones de las que dependen esas variables y se devolver�
el resultado al usuario

C�DIGO FUENTE POR DANIEL P�REZ RUIZ */

#include <iostream>			//Librer�a necesaria para recursos de E/S
#include <cmath>           //librer�a de recursos matem�ticos

using namespace std;

int main()						//Funci�n principal
{
	double x;				       //Declaraci�n de variables como reales.
	double y;				
	double h;
	
	double function1;           //Variables donde se guardar� el resultado 
	double function2;           //de cada funci�n.
	double function3;
	
	cout << "Inserte valor de variable X: ";                            //Pide al usuario que introduzca los datos
	cin >> x;
	
	cout << "Inserte valor de variable Y: ";
	cin >> y;
	
	cout << "Inserte valor de variable H: ";
	cin >> h;
	
	function1 = (1 + pow(x,2) / y) / (pow(x,3) / (1 + y));       //Realiza las funciones pedidas
	
	function2 = (1 + (sin(h) / 3) - cos(h) / 7) / (2 * h) ;
	
	function3 = sqrt(1 + pow( exp(x) / pow(x,2), 2));
	
	cout << "\n\nEL RESULTADO DE LAS FUNCIONES SON:";                   //Devuelve los datos al usuario
	cout << "\nFUNCION 1: " << function1;
	cout << "\nFUNCION 2: " << function2;
	cout << "\nFUNCION 3: " << function3 << "\n\n";
	
	system("pause");
}
