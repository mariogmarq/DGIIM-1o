/*C�LCULO DEL CAMBIO DE UNA M�QUINA DE REFRESCOS

Se pedir� al usuario introducir el precio del producto,
as� como el importe que realizar�, que debe ser una cantidad
igual o superior al precio del producto en cuesti�n.

Se mostrar� en pantalla una vez finalizados los c�lculos las
monedas de euro y c�ntimos que se les devolver� al usuario
como cambio.


C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos

using namespace std;

int main()																		//Funci�n principal
{
	double precio;																//Declaracion de variables como					
	double importe;															//reales
	
	double total_devolucion;												//Variable para mostrar el total a devolver
	
	int devolucion;															//Variable para obtener cambio en monedas.
	
	int euro;																	//Variables en los que se guardar� en n�mero
	int cent50;																	//total de monedas a devolver. Es importante
	int cent20;																	//que se declare como enteros ya que no existen
	int cent10;																	//cantidades racionales de monedas.
	int cent5;
	int cent2;
	int cent1;
	
	
	cout << "==================================================";				//Mensaje de bienvenida al usuario
	cout << "\nDEVOLUCI�N DE CAMBIO DE UNA M�QUINA DE REFRESCOS";
	cout << "\n==================================================";
	
	cout << "\n\nInserte precio producto: ";											//Pide al usuario que introduzca			
	cin >> precio;																				//los datos
	
	cout << "Inserte importe a realizar: ";
	cin >> importe;
	
	if(importe < precio)																		//IF: Si el importe es menor que el
	{																								//precio del producto da un mensaje
		cout << "\nERROR: USTED NO HA INTRODUCIDO LA SUFICIENTE\n";				//de error.
		cout << "CANTIDAD DE DINERO PARA ESTE PRODUCTO.\n\n";
		
		system("pause");
	}
	
	else																				//ELSE: Si el importe >= precio,
	{																					//comienza a operar.
	
		total_devolucion = importe - precio;								//Guarda el total a devolver
																						//como real.
																							
		devolucion = (importe - precio) * 100;								//Transforma el cambio en c�ntimos
	
		euro = devolucion / 100;												//Se queda con el cociente de la division
																						//y lo almacena en valor de la moneda pertinente.
																						
		devolucion = devolucion % 100;										//Cada vez que se guarda un valor en una moneda
																						//Se coge el resto para seguir operando despu�s.
	
		cent50 = devolucion / 50;												//Mismo procedimiento para el resto de monedas.
		devolucion = devolucion % 50;
	
		cent20 = devolucion / 20;
		devolucion = devolucion % 20;
	
		cent10 = devolucion / 10;
		devolucion = devolucion % 10;
	
		cent5 = devolucion / 5;
		devolucion = devolucion % 5;
	
		cent2 = devolucion / 2;
		devolucion = devolucion % 2;
	
		cent1 = devolucion;
		
		for(int i=0; i<100; i++)												//FOR: Realiza 100 saltos de lina (por est�tica)
		{
			cout << "\n";
		}
		
		cout << "\n\n\nEL PRECIO DEL PRODUCTO ES: " << precio << " euros";			//Devoluci�n de datos introducidos
		cout << "\nUSTED HA INTRODUCIDO: " << importe << " euros\n";					//a usuario
	
		cout << "\n\nTOTAL A DEVOLVER: " << total_devolucion << " euros";				//Devoluci�n del total de cambio
		cout << "\n==================================================\n\n";
	
		cout << "-> " << euro   << " moneda(s) de 1 euro\n";								//Devoluci�n de cada cantidad
		cout << "-> " << cent50 << " moneda(s) de 50 centimos\n";						//de monedas a entregar al
		cout << "-> " << cent20 << " moneda(s) de 20 centimos\n";						//usuario.
		cout << "-> " << cent10 << " moneda(s) de 10 centimos\n";
		cout << "-> " << cent5  << " moneda(s) de 5 centimos\n";
		cout << "-> " << cent2  << " moneda(s) de 2 centimos\n";
		cout << "-> " << cent1  << " moneda(s) de 1 centimo\n\n\n";
	
		system("pause");
	}
}
	
