/*C�LCULO DE MEDIA ARITM�TICA Y DESVIACI�N EST�NDAR

******************************************************
MODIFICACI�N EJERCICIO 7
******************************************************

Se pedir� al usuario introducir el valor de la altura
de tres personas distintas. Despu�s se devolver� al usuario
el valor de la media aritm�tica muestral y de la desviaci�n
t�pica.

CHANGE: Se mostrar� si los valores introducidos est�n por encima
o debajo de la media.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O.
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos.

using namespace std;

int main()																		//Funci�n principal.
{
	double altura1, altura2, altura3;								           //Declaracion de variables como reales					
														

	double media;																//Declaraci�n variable media.
	double stderivation;														//Declaraci�n desviaci�n est�ndar.
	double arg_raiz;															//Variable para argumento de ra�z (desv. est).
	
	string BAJO_MEDIA;															//Variables para mostrar mensaje de informaci�n
	string SOBRE_MEDIA;															//sobre la media
	
	BAJO_MEDIA =  " ESTA POR DEBAJO DE LA MEDIA.";
	SOBRE_MEDIA = " ESTA IGUAL O POR ENCIMA DE LA MEDIA";
	
	
	
	cout << "==================================================";				//Mensaje de bienvenida al usuario
	cout << "\nCALCULO DE MEDIA Y DESVIACION ESTANDAR";
	cout << "\n==================================================";
	
	cout << "\n\nInserte altura1: ";														//Pide al usuario que introduzca		
	cin >> altura1;																			//los datos
	
	cout << "Inserte altura2: ";
	cin >> altura2;
	
	cout << "Inserte altura3: ";
	cin >> altura3;
	
	media = (altura1 + altura2 + altura3) / 3;										//Calcula la media
	
	
	
	
	arg_raiz = (pow(altura1 - media,2) * pow(altura2 - media,2) * pow(altura3 - media,2)) / 3;
	
	
	stderivation = sqrt(arg_raiz);														//Calcula la desviaci�n habiendo
																						//calculado anteriormente el argumento
																						//de la ra�z.
																						
	cout << "\n\n\n\n";
	
	cout << "LA MEDIA ES: " << media << " m\n";										//Muestra los resultados
	cout << "LA DESVIACI�N ESTANDAR ES: " << stderivation << " m\n\n";
	
	cout << "========================================================\n";
	
	
	//EVAL�A SI ALTURA 1 EST� POR ENCIMA O POR DEBAJO DE LA MEDIA
	
	if(altura1 < media)
	{
		cout << "\nLA ALTURA 1: " << altura1 << BAJO_MEDIA;
	}
	
	if(altura1 >= media)
	{
		cout << "\nLA ALTURA 1: " << altura1 << SOBRE_MEDIA;		
	}
	
	
	//EVAL�A SI ALTURA 2 EST� POR ENCIMA O POR DEBAJO DE LA MEDIA
	
	if(altura2 < media)
	{
		cout << "\nLA ALTURA 2: " << altura2 << BAJO_MEDIA;
	}
	
	if(altura2 >= media)
	{
		cout << "\nLA ALTURA 2: " << altura2 << SOBRE_MEDIA;	
	}
	
	
	//EVAL�A SI ALTURA 3 EST� POR ENCIMA O POR DEBAJO DE LA MEDIA
	
	if(altura3 < media)
	{
		cout << "LA ALTURA 3: " << altura3 << BAJO_MEDIA;
	}
	
	if(altura3 >= media)
	{
		cout << "LA ALTURA 3: " << altura3 << SOBRE_MEDIA;	
	}
	
	cout << "\n\n\n";
	system("pause");
}
