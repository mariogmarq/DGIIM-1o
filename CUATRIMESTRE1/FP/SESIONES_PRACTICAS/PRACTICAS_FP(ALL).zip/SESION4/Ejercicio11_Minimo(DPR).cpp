/*COMPROBAR EL MINIMO DE UNA SUCESION

Lee un numero una serie de veces hasta que se introduce 0. Devuelve el m�nimo valor introducido
y las veces que se ha introducido un dato

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O.
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos.

using namespace std;

int main()																		//Funci�n principal.
{	
	int dato = 1;																//Declaracion de la variable numero
	int minimo = 1;															//Variable para mostrar el minimo
	int contador = 0;															//Variable que contar� las veces que introducimos un dato
	
	cout << "INSERTE NUMERO: ";										//INTRODUCCI�N DE DATOS
	cin >> dato;
	minimo = dato;
	
	while(dato != 0)
	{	
		if(dato < minimo)													//SI EL DATO ES MENOR QUE EL M�NIMO, SE ASIGNA AL M�NIMO ESE VALOR
		{																		//DE DATO
			minimo = dato;
		}
		
		contador++;															//Se incrementa en 1 el valor del contador
		cout << "INSERTE NUMERO: ";									//INTRODUCCI�N DE DATOS NUEVAMENTE
		cin >> dato;
	}
	
	cout << "\n\nEL MINIMO ES: " << minimo;							//Muestra los resultados
	cout << "\nDATOS INTRODUCIDOS: " << contador;
}
