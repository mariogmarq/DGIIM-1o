/*COMPROBAR 3 ENTEROS ORDENADOS

Lee 3 n�meros desde teclado y comprueba si est�n ordenados o no

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O.
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos.

using namespace std;

int main()																		//Funci�n principal.
{
	int num1=0, num2=0, num3=0;								         //Declaracion de variables como enteros
	
	bool num2_desc, num2_asc;												//Valores booleanas para comprobar veracidad de expresiones
	
	cout << "INSERTE 3 NUMEROS SEPARADOS POR ESPACIO: ";			//Pide al usuario que introduzca los datos
	cin >> num1 >> num2 >> num3;
	
	num2_asc = (num1 < num2) && (num2 < num3);						//Comprueba si el numero 2 es mayor que 1 y menor que 3 (Or. Ascendente)
	num2_desc = (num1 > num2) && (num2 > num3);						//Comprueba si el numero 2 es menor que 1 y mayor que 3 (Or. Descendente)
	
	if((num2_asc == 1) || (num2_desc == 1))							//IF: Si se cumple alguna de las 2 expresiones variables
	{																				//Muestra un mensaje diciendo que est�n ordenados
		cout << "\nLos numeros estan ordenados\n\n";
		
		system("pause");
	}
	
	else																			//ELSE: Si no se cumple ninguna muestra que no est�n ordenados
	{
		cout << "\nLos numeros no estan ordenados\n\n";
		
		system("pause");
	}
}
