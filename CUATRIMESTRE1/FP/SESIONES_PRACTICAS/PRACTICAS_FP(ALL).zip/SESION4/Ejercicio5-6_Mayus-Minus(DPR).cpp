/*CONVERSI�N DE MAY�SCULA A MIN�SCULA (EJERCICIOS 5-6)

Se pedir� introducir una letra may�scula o min�scula y se realizar� la conversi�n a min�scula o
may�scula, respectivamente.

Se utilizar�n los valores ASCII para corregir errores y para acotar el rango de par�metros a introducir
por el usuario.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O.

using namespace std;

int main()																		//Funci�n principal.
{	
	char letra;																	//Declaracion de la variable numero
	char letra_convertida;
	
	cout << "INSERTE CARACTER: ";											//EL USUARIO INTRODUCE LOS DATOS
	cin >> letra;
	
	
	if((64 < letra) && (letra < 91))										//'A'=65 'Z'=90 -> RANGO DE LETRAS MAY�SCULAS. SI EST� DENTRO DE ESTE
	{																				//RANGO, SE CAMBIA A MIN�SCULA
		letra_convertida = letra + 32;
		
		cout << "LA LETRA INTRODUCIDA ES MAYUSCULA: " << letra;
		cout << "\nLA LETRA MINUSCULA ES: " << letra_convertida;
	}
	
	if((96 < letra) && (letra < 123))									//'a'=97 'Z'=122 -> RANGO DE LETRAS MIN�SCULA. SI EST� DENTRO DE ESTE
	{																				//RANGO, SE CAMBIA A MAY�SCULA
		letra_convertida = letra - 32;
		
		cout << "LA LETRA INTRODUCIDA ES MINUSCULA: " << letra;
		cout << "\nLA LETRA MAYUSCULA ES: " << letra_convertida;
	}
}
	
	
