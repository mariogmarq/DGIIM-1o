/*SUBIDA DE SALARIO

El usuario inserta la edad de una persona y el salario asociado. Si es jubilado se incrementa
ese salario en un 5%, si no lo es, se devuelve un mensaje de error.

NOTA: EN ESTE EJERCICIO SE MUESTRAN 3 RESOLUCIONES DISTINTAS QUE SON LAS PEDIDAS POR EL EJERCICIO.
A LA HORA DE COMPILAR EL PROGRAMA, MU�VASE POR LOS APARTADOS INTRODUCIENDO A, B O C:

APARTADO A: Combinando expresiones l�gicas dentro del if.
APARTADO B: Estructurando las condiciones por bloques.
APARTADO C: Combinando m�s de una posibilidad para la edad (65 o 35)

C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/


#include <iostream>						//Inclusi�n de librer�a de recursos I/O.
#include <cmath>							//Inclusi�n de librer�a de recursos matem�ticos.

using namespace std;

int main()																		//Funci�n principal.
{
	int edad=0;									        						//Declaracion de variables como enteros
	double ingresos=0;														//y como reales
	
	bool apC_edad, apC_ingresos;											//Variables para el apartado C.
	
	char metodo;																//VARIABLES PARA ELEGIR ENTRE APARTADOS
	bool chk_metA, chk_metB, chk_metC;
	
	
	
	//INSERCI�N DE DATOS POR EL USUARIO
	
	cout << "Inserte edad: ";
	cin >> edad;
	
	cout << "Inserte ingresos: ";
	cin >> ingresos;
	
	
	//DIALOGO PARA MOSTRAR DIFERENTES RESOLUCIONES
	
	cout << "\n\n\nINSERTE METODO A UTILIZAR (a,b,c): ";
	cin >> metodo;
	
	chk_metA = (metodo == 'a') || (metodo == 'A');				//APARTADO A (Soluci�n con E/S combinadas)
	chk_metB = (metodo == 'b') || (metodo == 'B');				//APARTADO B (Por bloques diferentes)
	chk_metC = (metodo == 'c') || (metodo == 'C');				//APARTADO C (Cambio en las subidas de salario)
	
	//SALTOS DE LINEA
	
	for(int i=0; i<21; i++)
	{
		cout << "\n";
	}
	
	/*********************************************************************************************
	RESOLUCI�N POR M�TODO A
	**********************************************************************************************/
	if(chk_metA == 1)
	{
		cout << "RESOLUCION POR PRIMER METODO\n\n";
		
		if((edad >= 65) && (ingresos < 300))
		{
			ingresos = ingresos + (ingresos * 0.05);
			
			cout << "El ingreso por ser jubilado ahora es: " << ingresos << " euros\n\n";
			
			system("pause");
			return 0;
		}
		
		else
		{
			cout << "No es aplicable la subida de ingresos porque no cumple las condiciones necesarias\n\n";
			
			system("pause");
			return 0;
		}
	}
	
	/*********************************************************************************************
	RESOLUCI�N POR M�TODO B
	**********************************************************************************************/
	
	if(chk_metB == 1)
	{
		cout << "RESOLUCION POR SEGUNDO METODO\n\n";
		
		if(edad >= 65)
		{
			if(ingresos < 300)
			{
				ingresos = ingresos + (ingresos * 0.05);
				
				cout << "El ingreso por ser jubilado ahora es: " << ingresos << " euros\n\n";
				
				system("pause");
				return 0;
			}	
			
			else
			{
				cout << "No es aplicable la subida de ingresos porque dispone de mayores ingresos\n\n";
				
				system("pause");
				return 0;
			}
		}
		
		else
		{
			cout << "No es aplicable la subida de ingresos porque no es jubilado\n\n";
			
			system("pause");
			return 0;
		}
	}
	
	/*********************************************************************************************
	RESOLUCI�N POR M�TODO C
	**********************************************************************************************/
	
	if(chk_metC == 1)
	{
		cout << "RESOLUCION POR TERCER METODO\n\n";
		
		apC_edad = (edad >= 65) || (edad <= 35);
		apC_ingresos = ingresos < 300;
		
		if(apC_edad == 1)
		{
			if(apC_ingresos == 1)
			{
				ingresos = ingresos + (ingresos * 0.07);
				
				cout << "Los ingresos ahora son: " << ingresos << " euros\n\n";
				
				system("pause");
				return 0;
			}
			
			else
			{
				ingresos = ingresos + (ingresos * 0.04);
				
				cout << "Los ingresos ahora son: " << ingresos << " euros\n\n";
				
				system("pause");
				return 0;
			}
		}
		
		else
		{
			cout << "No es aplicable la subida de ingresos porque no cumple las condiciones necesarias\n\n";
			
			system("pause");
			return 0;
		}
	}
}
	
	
	
