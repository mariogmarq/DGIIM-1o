/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

//FUNCION MENU
void Menu(){
	cout << "OPCIONES: \n";
	cout << "1. Convertir de Matriz a Vector\n";
	cout << "2. Convertir de Vector a Matriz\n";
	cout << "\n\nInserte Opcion >>> ";
}

//FUNCION PARA COMPROBAR QUE LA DIMENSION DE LA MATRIZ ES CORRECTA
bool CheckMatriz(int dimension){
	if(dimension < 20){
		return true;
	}
	else{
		return false;
	}
}

//FUNCION PARA COMPROBAR MATRIZ SIMETRICA
bool ComprobarSimetrica(int dimension, int Matriz[20][20]){
	for(int i=0; i<dimension; i++){
		for(int j=0; j<dimension; j++){
			if(Matriz[i][j] != Matriz[j][i]){
				return false;
			}
			else{
				return true;
			}
		}
	}
}

//FUNCION PARA LEER LOS DATOS DE LA MATRIZ
int LeerMatriz(int dimension, int Matriz[20][20]){
	for(int i=0; i<dimension; i++){
		for(int j=0; j<dimension; j++){
			cout << "FILA " << i << " // COLUMNA " << j;
			cout << "\n>>> ";
			cin >> Matriz[i][j];
			cout << "\n";
		}
	}
}

//FUNCION PARA MOSTRAR DATOS DE LA MATRIZ
int MostrarMatriz(int dimension, int Matriz[20][20]){
	for(int j=0; j<dimension; j++){
		for(int k=0; k<dimension; k++){
			cout << Matriz[j][k] << " ";
		}
		cout << "\n";
	}
}

//FUNCION PARA LEER LOS DATOS DE VECTOR
int LeerVector(int longitud, int Vector[40]){
	for(int i=0; i<longitud; i++){
		cout << "Posicion " << i << " >>> ";
		cin >> Vector[i];
	}
}

int main()
{
	const int MAXIMA_DIMENSION = 20;
	int matriz_simetrica [MAXIMA_DIMENSION][MAXIMA_DIMENSION] = {0};
	int vector_simetrica [MAXIMA_DIMENSION] = {0};

	int dimension = 0, longitud = 0, filas = 0, columnas = 0;
	int opcion = 0, x=0, y=0, k=0;
	
	Menu();
	cin >> opcion;
	
	if(opcion == 1)
	{
		cout << "INSERTE FILAS Y COLUMNAS DE MATRIZ SIMETRICA (un unico valor): ";
		cin >> dimension;
	
		//CHECK DE DIMENSIONES MATRIZ
		if(!CheckMatriz(dimension)){
			cout << "\n\nERROR: DIMENSION MAXIMA DE MATRIZ: " << MAXIMA_DIMENSION << "x" << MAXIMA_DIMENSION;
			return 0;
		}
		LeerMatriz(dimension, matriz_simetrica);
		
		for(int i=0; i<dimension; i++){
			for(int j=0; j<dimension; j++){
				if(i >= j){
					vector_simetrica[k] = matriz_simetrica[i][j];
					k++;
					longitud++;
				}
			}
		}
		
		if(!ComprobarSimetrica(dimension, matriz_simetrica)){
			cout << "\n\nERROR: MATRIZ NO SIMETRICA";
			return 0;
		}
		
		cout << "\n\n\nMATRIZ INTRODUCIDA: \n";
		MostrarMatriz(dimension, matriz_simetrica);
		
		cout << "\n\n\nVECTOR ASOCIADO A MATRIZ: \n";
		for(int i=0; i<longitud; i++){
			cout << vector_simetrica[i] << " ";
		}
	}
	
	if(opcion == 2)
	{
		cout << "INSERTE LONGITUD DEL VECTOR: ";
		cin >> longitud;
		
		if(longitud > MAXIMA_DIMENSION){
			cout << "\nERROR: SE HA SOBREPASADO EL LIMITE DE LONGITUD";
			return 0;
		}
		
		LeerVector(longitud, vector_simetrica);
		
		//SE CREA MATRIZ SIM�TRICA
		while(k < longitud){
			for(int j=0; j<=columnas; j++){
				matriz_simetrica[filas][j] = vector_simetrica[k];
				matriz_simetrica[j][filas] = vector_simetrica[k];
				k++;	
			}
			columnas++;
			filas++;
		}
		
		cout << "\n\n\nMATRIZ ASOCIADA A VECTOR: \n";
		MostrarMatriz(filas, matriz_simetrica);
	}
}
