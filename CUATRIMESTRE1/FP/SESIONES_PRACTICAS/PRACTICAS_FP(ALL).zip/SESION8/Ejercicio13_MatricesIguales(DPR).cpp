/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
using namespace std;

bool CheckMatriz(int fila, int columna)
{
	if(fila < 20 && columna < 20)
	{
		return true;
	}
	
	else
	{
		return false;
	}
}

bool DimensionIgual(int fila1, int fila2, int columna1, int columna2)
{
	if(fila1 == fila2 && columna1 == columna2)
	{
		return true;
	}
	
	else
	{
		return false;
	}
}

int main()
{
	const int LONGITUD_FILAS = 20;
	const int LONGITUD_COLUMNAS = 20;
	
	double matriz1 [LONGITUD_FILAS][LONGITUD_COLUMNAS];
	double matriz2 [LONGITUD_FILAS][LONGITUD_COLUMNAS];
	
	int filas1 = 0, columnas1 = 0, filas2 = 0, columnas2 = 0;
	int contador = 0, dimension1 = 0, dimension2 = 0;
	
	//DIMENSIONES DE MATRIZ 1
	cout << "INSERTE NUMERO DE FILAS DE LA MATRIZ 1: ";
	cin >> filas1;
	
	cout << "INSERTE NUMERO DE COLUMNAS DE MATRIZ 1: ";
	cin >> columnas1;
	
	//CHECK DE DIMENSIONES MATRIZ
	if(!CheckMatriz(filas1, columnas1))
	{
		cout << "\n\nERROR: DIMENSION MAXIMA DE MATRIZ: " << LONGITUD_FILAS << "x" << LONGITUD_COLUMNAS;
		return 0;
	}
	
	dimension1 = filas1 * columnas1;
	
	
	//INTRODUCCION DE DATOS MATRIZ1
	cout << "\n\n";
	
	for(int i=0; i<filas1; i++)
	{
		for(int j=0; j<columnas1; j++)
		{
			cout << "FILA " << i << " // COLUMNA " << j;
			cout << "\n >>> ";
			cin >> matriz1[i][j];
			cout << "\n";
		}
	}
	
	//DIMENSIONES DE MATRIZ 2
	cout << "\nINSERTE NUMERO DE FILAS DE LA MATRIZ 2: ";
	cin >> filas2;
	
	cout << "INSERTE NUMERO DE COLUMNAS DE MATRIZ 2: ";
	cin >> columnas2;
	
	//CHECK DE DIMENSIONES VALIDAS DE MATRIZ
	if(!CheckMatriz(filas2, columnas2))
	{
		cout << "\n\nERROR: DIMENSION MAXIMA DE MATRIZ: " << LONGITUD_FILAS << "x" << LONGITUD_COLUMNAS;
	}
	
	dimension2 = filas2 * columnas2;
	
	//INTRODUCCION DE DATOS
	cout << "\n\n";
	
	for(int i=0; i<filas2; i++)
	{
		for(int j=0; j<columnas2; j++)
		{
			cout << "FILA " << i << " // COLUMNA " << j;
			cout << "\n >>> ";
			cin >> matriz2[i][j];
			cout << "\n";
		}
	}
	
	//EVALUACION DE MATRICES IGUALES:
	//1. COMPROBAR QUE DIMENSIONES SON IGUALES
	if(!DimensionIgual(filas1, filas2, columnas1, columnas2))
	{
		cout << "\n\nLAS MATRICES NO SON IGUALES. (DIMENSIONES DIFERENTES)";
		return 0;
	}
	
	//2. COMPRUEBA QUE COMPONENTES SON IGUALES
	for(int i=0; i<filas1; i++)
	{
		for(int j=0; j<columnas1; j++)
		{
			if(matriz1[i][j] == matriz2[i][j])
			{
				contador++;
			}
		}
	}
	
	//SI MATRICES SON IGUALES: MUESTRA EL RESULTADO
	if(contador == dimension1)
	{
		cout << "\nLAS MATRICES SON IGUALES\n";
	}
	
	else
	{
		cout << "\nLAS MATRICES NO SON IGUALES\n";
	}
	
	//MUESTRA MATRIZ 1
	cout << "\nMATRIZ 1: \n";
	for(int i=0; i<filas1; i++)
	{
		for(int j=0; j<columnas1; j++)
		{
			cout << matriz1[i][j];
		}
		cout << "\n";
	}
	
	//MUESTRA MATRIZ2
	cout << "\nMATRIZ 2: \n";
	for(int i=0; i<filas2; i++)
	{
		for(int j=0; j<columnas2; j++)
		{
			cout << matriz2[i][j];
		}
		cout << "\n";
	}
}
	
