/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <cctype>

using namespace std;

char CambioCaracter(char caracter){
	bool minuscula;
	char caracter_cambiado;
	
	minuscula = (96 < caracter) && (caracter < 123);
	
	if(minuscula){
		caracter_cambiado = toupper(caracter);
	}
	
	else{
		caracter_cambiado = tolower(caracter);
	}
	
	return caracter_cambiado;
}

int main(){
	char caracter;
	bool mayuscula = false, minuscula = false;
	
	do{
		cout << "Inserte letra mayuscula o minuscula: ";
		cin >> caracter;
		
		mayuscula = (64 < caracter) && (caracter < 91);
		minuscula = (96 < caracter) && (caracter < 123);
	}while(!mayuscula && !minuscula);
	
	cout << "\nLETRA CAMBIADA: " << CambioCaracter(caracter);
}
	
