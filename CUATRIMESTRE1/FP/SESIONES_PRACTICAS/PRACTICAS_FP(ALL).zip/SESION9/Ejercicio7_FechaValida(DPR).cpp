/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

bool FechaValida(int day, int month, int year){
	bool bisiesto, feb_29, day_31;
	bool mes_infJulio, mes_sobreAgosto;
	bool mes_par;
	
	bool respuesta;
	
	bisiesto = (year % 4 == 0) && (year % 100 != 0) || ((year % 100 == 0) && (year % 400 == 0));
	day_31 = day == 31;
	feb_29 = (day == 29) && (month == 2);
	mes_par = month % 2 == 0;
	mes_infJulio = month <= 7;
	mes_sobreAgosto = month >= 8;
	
	if(feb_29){
		if(bisiesto){
			respuesta = true;
		}
		else{
			respuesta = false;
		}
	}
	
	if(day_31){
		if(!mes_par && mes_infJulio){
			respuesta = true;
		}
		else{
			if(mes_par && mes_sobreAgosto){
				respuesta = true;
			}
			else{
				respuesta = false;
			}
		}
	}
	
	if(!day_31 && !feb_29){
		if(day == 30 && month == 2){
			respuesta = false;
		}
		else{
			respuesta = true;
		}
	}
	
	return respuesta;
}

int main(){
	int dia = 0, mes = 0, anio = 0;
	
	do{
		cout << "Inserte dia, mes, anio (separado por espacio): ";
		cin >> dia >> mes >> anio;
	}while(dia <= 0 || dia > 31 || mes <= 0 || mes > 12 || anio <= 0);
	
	if(FechaValida(dia, mes, anio)){
		cout << "\nLA FECHA INTRODUCIDA ES VALIDA";
	}
	
	else{
		cout << "\nLA FECHA INTRODUCIDA NO ES VALIDA";
	}
}
