/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

//FUNCI�N PARA DETERMINAR SI LONGITUD DE VECTOR INTRODUCIDA
//ES V�LIDA O NO
bool Check_longitud(int longitud)
{
	if(longitud > 1000)
	{
		return false;
	}
	
	else
	{
		return true;
	}
}

//FUNCI�N PRINCIPAL
int main()
{
	//DECLARACION DE VARIABLES
	const int LENGTH = 1000;
	int longitud = 0;
	
	int vector1[LENGTH] = vector2[LENGTH] = {0};
	int posicion = 0, i = 0, j = 0, k = 0;
	
	bool posicion_igual = true;
	
	//INTRODUCCI�N Y CHECK DE LONGITUD 1
	cout << "Inserte longitud del vector: ";
	cin >> longitud1;
	
	if(!Check_longitud(longitud1))
	{
		cout << "\nERROR. El maximo permitido de longitud es 1000.";
		return 0;
	}
	
	//INTRODUCCI�N DE DATOS: VECTOR 1
	cout << "\nInserte valores del vector y presiona enter.\n";
	
	for(int i = 0; i < longitud1; i++)
	{
		cout << ">>> ";
		cin >> vector[i];
	}
	
	//INTRODUCCI�N Y CHECK DE LONGITUD 2
	cout << "Inserte longitud del vector: ";
	cin >> longitud2;
	
	if(!Check_longitud(longitud2))
	{
		cout << "\nERROR. El maximo permitido de longitud es 1000.";
		return 0;
	}
	
	//INTRODUCCI�N DE DATOS: VECTOR 2
	cout << "\nInserte valores del vector y presiona enter.\n";
	
	for(int j = 0; j < longitud2; j++)
	{
		cout << ">>> ";
		cin >> vector[j];
	}
}
	
	
	
