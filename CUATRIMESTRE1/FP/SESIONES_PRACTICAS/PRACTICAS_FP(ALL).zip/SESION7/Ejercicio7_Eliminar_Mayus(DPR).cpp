/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

//FUNCI�N PARA DETERMINAR SI LONGITUD DE VECTOR INTRODUCIDA
//ES V�LIDA O NO
bool Check_longitud(int longitud)
{
	if(longitud > 1000)
	{
		return false;
	}
	
	else
	{
		return true;
	}
}

int main()
{
	const int LENGTH = 1000;
	int longitud = 0, ascii_value = 0;
	
	char vector[LENGTH] = {0};
	char vector_A[LENGTH] = {0};
	
	//INTRODUCCI�N Y CHECK DE LONGITUD
	cout << "Inserte longitud del vector: ";
	cin >> longitud;
	
	if(!Check_longitud(longitud))
	{
		cout << "\nERROR. El maximo permitido de longitud es 1000.";
		return 0;
	}
	
	//INTRODUCCI�N DE DATOS: VECTOR
	cout << "\nInserte valores del vector y presiona enter.\n";
	
	for(int i = 0; i < longitud; i++)
	{
		cout << ">>> ";
		cin >> vector[i];
	}
	
	//COMPRUEBA QUE COMPONENTE DE VECTOR ES MINUSCULA
	for(int j = 0; j < longitud; j++)
	{
		ascii_value = vector[j];
		
		if(96 < ascii_value && ascii_value < 123)
		{
			vector_A[j] = static_cast<char>(ascii_value);
		}
	}
	
	//DEVUELVE DATOS A USUARIO
	cout << "\n\nVector sin mayusculas\n";
	
	for(int k = 0; k < longitud; k++)
	{
		cout << vector_A[k];
	}
	
}
