/*C�DIGO FUENTE POR DANIEL PEREZ RUIZ*/

#include <iostream>

using namespace std;


//FUNCI�N PARA DETERMINAR SI LONGITUD DE VECTOR INTRODUCIDA
//ES V�LIDA O NO
bool Check_longitud(int longitud)
{
	if(longitud > 1000)
	{
		return false;
	}
	
	else
	{
		return true;
	}
}

int main()
{
	//DECLARACI�N DE VARIABLES
	const int LENGTH = 1000;
	int longitud = 0;
	
	int vector[LENGTH] = {0};
	bool check_componente[LENGTH] = {0};
	
	int swap = 0, change1 = 0, change2 = 0;
	
	//INTRODUCCI�N DE DATOS: LONGITUD
	cout << "Inserte longitud del vector: ";
	cin >> longitud;
	
	//CHECK LONGITUD V�LIDA
	if(!Check_longitud(longitud))
	{
		cout << "\nERROR. El maximo permitido de longitud es 1000.";
		return 0;
	}
	
	//INTRODUCCI�N DE DATOS: VECTOR
	cout << "\nInserte valores del vector y presiona enter.\n";
	
	for(int i = 0; i < longitud; i++)
	{
		check_componente[i] = true;
		cout << ">>> ";
		cin >> vector[i];
	}
	
	//PREGUNTA AL USUARIO DE CAMBIO DE COMPONENTES
	cout << "\n\nInserte dos componentes separadas por espacios que desea cambiar\n";
	cout << "NOTA: RECUERDE QUE LA PRIMERA POSICION EQUIVALE AL 0\n";
	cout << ">>> ";
	cin >> change1 >> change2;
	
	//COMPRUEBA QUE LOS PARAMETROS DEL USUARIO SON CORRECTOS
	if(!check_componente[change1] || !check_componente[change2])
	{
		cout << "\nERROR. Alguna posicion introducida no es correcta.";
	}
	
	//SI SON CORRECTOS: SE PRODUCE INTERCAMBIO DE VALORES
	else
	{
		swap = vector[change1];
		vector[change1] = vector[change2];
		vector[change2] = swap;
	}
	
	//DEVOLUCI�N DE DATOS POR EL USUARIO
	cout << "\n\nEl vector con valores cambiados es: \n";
	
	for(int j=0; j<longitud; j++)
	{
		cout << vector[j];
	}
}
	
