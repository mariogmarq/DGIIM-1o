/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

int MCD(int a, int b){
	int divisor = 0, maximo_divisor = 0;
	
	if(a < b){
		maximo_divisor = a;
	}
	
	else{
		maximo_divisor = b;
	}
	
	for(int i=1; i<=a; i++){
		if(a % i == 0 && b % i == 0){
			divisor = i;
		}
	}
	
	return divisor;
}

int main(){
	int a = 0, b = 0;
	
	cout << "Inserte numeros a y b (separados por espacios): ";
	cin >> a >> b;
	
	cout << "MCD: " << MCD(a, b);
}
	
