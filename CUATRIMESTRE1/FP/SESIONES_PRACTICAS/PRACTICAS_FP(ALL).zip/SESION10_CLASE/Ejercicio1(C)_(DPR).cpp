/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <cmath>

using namespace std;

class Recta{
	private:
		double A, B, C;
	public:
		void setA(double valor){
			A = valor;
		}
		void setB(double valor){
			B = valor;
		}
		void setC(double valor){
			C = valor;
		}
		void MuestraRecta(){
			cout << "\n\n";
			cout << A << "x + " << B << "y + " << C << " = 0";
		}
		void Opciones(){
			cout << "\n\nQue desea calcular?: \n";
			cout << "1. Pendiente recta: \n";
			cout << "2. Valor Ordenada a partir de Abcisa: \n";
			cout << "3. Valor Abcisa a partir de Ordenada: \n";
		}
		double PendienteRecta(){
			double pendiente;
			if(B == 0){
				pendiente = INFINITY;
			}
			else{
				pendiente = (-1) * (A / B);
			}
			return pendiente;
		}
		
		double Y_Value(double x){
			double y;
			y = (-C - x * A) / B;
			return y;
		}
		
		double X_Value(double y){
			double x;
			x = (-C - y * B) / A;
			return x;
		}
};

void LeerCoeficientes(Recta& recta){
	double A, B, C;
	cout << "Inserte coeficientes recta: ";
	cin >> A >> B >> C;	
	
	recta.setA(A);
	recta.setB(B);
	recta.setC(C);
}

int main(){
	Recta recta;
	int abcisa, ordenada, respuesta;
	
	LeerCoeficientes(recta);
	recta.Opciones();
	
	do{
		cout << ">>> ";
		cin >> respuesta;
	}while(respuesta < 0 || 3 < respuesta);
	recta.MuestraRecta();
	
	if(respuesta == 1){
		cout << "\nPENDIENTE RECTA: " << recta.PendienteRecta();
	}
	if(respuesta == 2){
		cout << "\nInserte Valor Abcisa: ";
		cin >> abcisa;
		cout << "\nVALOR ORDENADA: " << recta.Y_Value(abcisa);
	}
	if(respuesta == 3){
		cout << "\nInserte Valor Ordenada: ";
		cin >> ordenada;
		cout << "\nVALOR ABCISA: " << recta.X_Value(ordenada);
	}
}
