/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <cmath>

using namespace std;

class Recta{
	private:
		double A, B, C;
	public:
		Recta(){
			A = 1;
			B = 1;
			C = 0;
		}
		void SetCoeficientes(double value_A, double value_B, double value_C){
			A = value_A;
			B = value_B;
			C = value_C;
		}
		void MuestraRecta(){
			cout << "\n\n";
			cout << A << "x + " << B << "y + " << C << " = 0";
		}
		void Opciones(){
			cout << "\n\nQue desea calcular?: \n";
			cout << "1. Pendiente recta: \n";
			cout << "2. Valor Ordenada a partir de Abcisa: \n";
			cout << "3. Valor Abcisa a partir de Ordenada: \n";
		}
		double PendienteRecta(){
			double pendiente;
			if(B == 0){
				pendiente = INFINITY;
			}
			else{
				pendiente = (-1) * (A / B);
			}
			return pendiente;
		}
		
		double Y_Value(double x){
			double y;
			y = (-C - x * A) / B;
			return y;
		}
		
		double X_Value(double y){
			double x;
			x = (-C - y * B) / A;
			return x;
		}
};

void LeerCoeficientes(Recta& recta){
	double A, B, C;
	cout << "\n\nInserte coeficientes recta: ";
	cin >> A >> B >> C;
	
	recta.SetCoeficientes(A, B, C);
}

int main(){
	Recta recta;
	int abcisa, ordenada, respuesta;
	
	recta.MuestraRecta();
	LeerCoeficientes(recta);
	recta.Opciones();
	
	do{
		cout << ">>> ";
		cin >> respuesta;
	}while(respuesta < 0 || 3 < respuesta);
	recta.MuestraRecta();
	
	if(respuesta == 1){
		cout << "\nPENDIENTE RECTA: " << recta.PendienteRecta();
	}
	if(respuesta == 2){
		cout << "\nInserte Valor Abcisa: ";
		cin >> abcisa;
		cout << "\nVALOR ORDENADA: " << recta.Y_Value(abcisa);
	}
	if(respuesta == 3){
		cout << "\nInserte Valor Ordenada: ";
		cin >> ordenada;
		cout << "\nVALOR ABCISA: " << recta.X_Value(ordenada);
	}
}
