/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <cmath>

using namespace std;

class Recta{
	public:
		double A, B, C;
	public:
		double PendienteRecta(){
			double pendiente;
			if(B == 0){
				pendiente = INFINITY;
			}
			else{
				pendiente = (-1) * (A / B);
			}
			return pendiente;
		}
		
		double Y_Value(double x){
			double y;
			y = (-C - x * A) / B;
			return y;
		}
		
		double X_Value(double y){
			double x;
			x = (-C - y * B) / A;
			return x;
		}
};

int main(){
	int abcisa, ordenada;
	Recta recta1;
	
	cout << "Inserte coeficientes recta: ";
	cin >> recta1.A >> recta1.B >> recta1.C;
	
	cout << "\nPENDIENTE DE LA RECTA: " << recta1.PendienteRecta();
	
	cout << "\n\nInserte valor de abcisa para la recta: " << 
	recta1.A << "x + " << recta1.B << "y + " << recta1.C << " = 0";
	cout << "\n>>> ";
	cin >> abcisa;
	
	cout << "\nSu valor ordenada es: " << recta1.Y_Value(abcisa);
	
	cout << "\n\nInserte valor de ordenada para la recta: " << 
	recta1.A << "x + " << recta1.B << "y + " << recta1.C << " = 0";
	cout << "\n>>> ";
	cin >> ordenada;
	
	cout << "\nSu valor abcisa es: " << recta1.X_Value(ordenada);
}
