/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

class DepositoSimulacion{
	private:
		double interes;
		double capital;
		
		bool ParametrosCorrectos(double& value_capital, double& value_interes){
			bool respuesta;
			if(value_capital < 0 && value_interes < 0){
				respuesta = false;
			}
			else{
				respuesta = true;
			}
			return respuesta;
		}
	public:
		//CONSTRUCTOR
		DepositoSimulacion(){
			capital = 0;
			interes = 100;
		}
		DepositoSimulacion(double A, double B){
			if(ParametrosCorrectos(A, B)){
				capital = A;
				interes = B;
			}
			else{
				cout << "PROTECCION DE DATOS INICIALIZADA\n";
				DepositoSimulacion();
			}
		}
		
		void SetCapital(double a){
			if(a>0){
				capital = a;
			}
			else{
				cout << "El capital no puede ser negativo";
			}	
		}

		void SetInteres(double a){
			if(a>0){
				interes = a;
			}
			else{
				cout << "El interes debe ser positivo";
			}	
		}
		
		void CambioDatos(int option){
			double new_capital, new_interes;
			if(option == 1){
				cout << "\nINSERTE NUEVO VALOR CAPITAL: ";
				cin >> new_capital;
				SetCapital(new_capital);
			}
			if(option == 2){
				cout << "\nINSERTE NUEVO VALOR INTERES: ";
				cin >> new_interes;
				SetInteres(new_interes);
			}
		}
		void MostrarDatos(){
			cout << "\n\nINTERES: " << interes;
			cout << "\nCAPITAL: " << capital;
		}
		void CapitalObtenido(double capital, double interes){
			int anios = 0;
  			double resultado = capital;
			
			do{
				cout << "\nInserte Numero Anios: ";
				cin >> anios;
			}while(anios < 0);
			
			for (int i=0; i<anios; i++){
				resultado += resultado * (interes/100);
			}
			cout << "\n\nTras " << anios << " anios se obtendra: " << resultado << " euros";
		}
		void CalculoAnios(double capital, double interes){
			int anios = 0, resultado;
			double acumulado = capital;

			do{
				cout << "\nInserte Numero Anios: ";
				cin >> anios;
			}while(anios < 0);
			
			while(acumulado < 2*capital){
				acumulado += capital*(interes/100);
				resultado += 1;
			}
			
			cout << "\nSe doblara la cantidad en " << resultado << " anios";
		}
		void Menu(){
			int opcion;
			cout << "\n\n==============================\n";
			cout << " MENU DE OPCIONES \n";
			cout << "==============================\n";
			cout << "0. Mostrar este menu\n";
			cout << "1. Capital obtenido tras X anios\n";
			cout << "2. Anios necesarios tras doblar cantidad\n";
			cout << "3. Visualizar valores introducidos\n";
			cout << "4. Modificar Variables\n";
			cout << "5. Salir del programa\n";
			cout << "==============================\n";
			do{
				cout << "Inserte numero opcion >>> ";
				cin >> opcion;
			}while(opcion < 0 || opcion > 5);
			
			switch (opcion){
				case 0:
					cout << "\n\n\n\n";
					Menu();
				break;
				case 1:
					CapitalObtenido(capital, interes);
				break;
				case 2:
					CalculoAnios(capital, interes);
				break;
				case 3:
					MostrarDatos();
					Menu();
				break;
				case 4:
					int response = 0;
					cout << "\n\nQue datos desea modificar?: \n";
					cout << "1. Capital\n";
					cout << "2. Interes\n";
					cout << "3. Ambos\n";
					
					do{
						cout << "\nINSERTE NUMERO OPCION: >> ";
						cin >> response;
					}while(0 > response || response > 4);
					
					CambioDatos(response);
					
					if(response == 3){
						cout << "Inserte valor capital: ";
						cin >> capital;
						SetCapital(capital);
	
						cout << "Inserte valor interes: ";
						cin >> interes;
						SetInteres(interes);
					}
					Menu();
				break;
			}
		}
};

void LeerDatos(DepositoSimulacion& Cliente){
	double capital, interes;
	cout << "Inserte valor capital: ";
	cin >> capital;
	Cliente.SetCapital(capital);
	
	cout << "Inserte valor interes: ";
	cin >> interes;
	Cliente.SetInteres(interes);
}

int main(){
	DepositoSimulacion Cliente;
	
	LeerDatos(Cliente);
	
	Cliente.Menu();
	
}
