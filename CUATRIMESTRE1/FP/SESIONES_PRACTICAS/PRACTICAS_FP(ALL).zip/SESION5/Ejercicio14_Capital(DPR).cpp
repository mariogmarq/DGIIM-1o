/*CODIGO FUENTE COMPILADO POR DANIEL P�REZ RUIZ*/

#include <iostream>                                                                    

using namespace std;

int main()
{
   double capital, interes, doble;                                                         //DECLARACION DE LAS VARIABLES
   int anio = 0;
   
   cout << "Inserte capital inicial: ";                                                   //PIDE AL USUARIO QUE INTRODUZCA LOS DATOS   
   cin >> capital;

   cout << "Inserte interes (en %): ";
   cin >> interes;
   
   doble = capital * 2;
   
   while(capital <= doble)
   {
      capital = capital + capital * (interes / 100);
      
      anio++;
   }
   
   cout << "\nPasaran " << anio << " anios hasta doblar el capital";
}
   
   
