/*CODIGO COMPILADO POR DANIEL PEREZ RUIZ*/

#include <iostream>															//Librer�a de recursos de I/O

using namespace std;

int main()																	//funcion principal
{
	char caracter='a';
	
	do																		//DO: Pide may�scula hasta que se introduzca una.
	{
		cout << "INSERTE CARACTER MAYUSCULA: ";
		cin >> caracter;
	}while((caracter < 64) || (caracter > 91));								//WHILE: Se hace el DO mientras caracter no sea mayuscula (ASII values)
	
	cout << "LA LETRA INTRODUIDA ES: " << caracter;							//Devuelve may�scula
}
