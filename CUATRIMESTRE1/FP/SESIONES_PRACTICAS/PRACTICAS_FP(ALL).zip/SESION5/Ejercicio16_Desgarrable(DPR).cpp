/*CODIGO FUENTE COMPILADO POR DANIEL P�REZ RUIZ*/

#include <iostream>	
#include <cmath>                                                            

using namespace std;

int main()
{
   int num_candidato = 0, num_izda = 1, num_dcha = 0;											//VARIABLES
   int divisor = 10;
   
   bool num_desgarrable = 0;
   
   cout << "INSERTE NUMERO: ";																		//PIDE NUMERO A EVALUAR
   cin >> num_candidato;
   
   while((num_desgarrable == 0) && (num_izda != 0))											//MIENTRAS NUMERO NO SEA DESGARRABLE Y LA PARTE IZDA
   {																											//NO SEA 0, DIVIDE NUM EN 2 PARTES Y EVALUA SI SE CUMPLE IGUALDAD
   	num_izda = num_candidato / divisor;
   	num_dcha = num_candidato % divisor;
   	
   	num_desgarrable = pow((num_izda + num_dcha), 2) == num_candidato;
   	divisor *= 10;
   }
   
   if(num_desgarrable)																					//EVALUA SI NUM ES DESGARRABLE
   {
   	cout << "\nEL NUMERO " << num_candidato << " ES DESGARRABLE";
   }
   
   else
   {
   	cout << "\nEL NUMERO " << num_candidato << " NO ES DESGARRABLE";
   }
}
