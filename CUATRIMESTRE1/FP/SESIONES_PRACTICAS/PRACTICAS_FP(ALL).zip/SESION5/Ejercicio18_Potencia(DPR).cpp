/*CODIGO FUENTE COMPILADO POR DANIEL P�REZ RUIZ*/

#include <iostream>											//LIBRERIA DE RECURSOS I/O

using namespace std;

int main()													//FUNCION PRINCIPAL
{
	int n = 0, factorial = 1;								//DATOS A UTILIZAR
	double x = 0, potencia = 1;
	
	cout << "INSERTE NUMERO NATURAL N: ";					//INTRODUCCION DE DATOS
	cin >> n;
	
	cout << "INSERTE NUMERO REAL X: ";
	cin >> x;
	
	if(n == 0)												//SI N = 0; ENTONCES 0! = 1 (CONVENIO MATEM�TICO)
	{
		factorial = 1;
	}
	
	else													//ELSE: CALCULA FACTORIAL USANDO FOR (desde 1 hasta n multiplica i)
	{
		for(int i=1; i<=n; i++)
		{
			factorial *= i;
		}
	}
	
	for(int j=1; j<=n; j++)									//FOR: CALCULA POTENCIA (desde 1 hasta n multiplica x)
	{
		potencia *= x;
	}
	
	cout << "\nEL RESULTADO DE " << n << "!" << " ES: " << factorial << endl;
	cout << "LA POTENCIA DE " << x << " ELEVADO A " << n << " ES: " << potencia << endl;
}	
