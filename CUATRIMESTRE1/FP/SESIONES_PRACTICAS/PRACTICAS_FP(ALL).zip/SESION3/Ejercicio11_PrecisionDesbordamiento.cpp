/*EVALUACI�N DE DESBORDAMIENDO DE MEMORIA EN DIFERENTES CASOS

Se expondr�n diferentes casos en los que se comentar� si se produce
un desbordamiento de memoria o problema de precisi�n.

Se habilitar� un men� para que a la hora de compilar el c�digo se
pueda elegir con facilidad todos los casos pedidos.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ */


#include <iostream>					//Inclusi�n de librer�a de recursos I/O
#include <cmath>					//Inclusi�n de librer�a de recursos matem�ticos

using namespace std;

int main ()
{
	int chico, chico1, chico2;			//VARIABLES PARA LOS CASOS "A", "B"
	long grande;						//VARIABLE PARA CASO "B"
	
	double resultado, real1, real2;		//VARIABLES PARA CASOS "C", "D"
	
	double real, otro_real;				//VARIABLES PARA CASOS "E"; "F"
	
	float chico_G; 						//VARIABLES PARA CASO "G"
	double grande_G;
	
	int option;							//VARIABLE PARA ELEGIR ENTRE OPCIONES
	
	
	
	
	cout << "SELECCIONE UNA OPCION: \n";
	cout << "======================================\n";
	cout << "1. APARTADO A\n";
	cout << "2. APARTADO B\n";
	cout << "3. APARTADO C\n";
	cout << "4. APARTADO D\n";
	cout << "5. APARTADO E\n";
	cout << "6. APARTADO F\n";
	cout << "7. APARTADO G\n";
	cout << "======================================\n\n";
	
	cout << "INSERTE NUMERO DE OPCION >> ";
	cin >> option;
	
	
	
	for(int i=0; i<50; i++)
	{
		cout << "\n";
	}
	
	
	
	/* CASO A: En este caso se declaran dos variables como enteros (chico1 y chico2), y se 
	asignan en ambas un n�mero de 9 d�gitos. Despu�s se multiplican y devuelve un resultado
	que no se ajuta ni se aproxima al valor real del resultado (la variable "chico" est�
	declarada como entero).
	
	�QU� SE PRODUCE EN ESTE CASO?: DESBORDAMIENTO DE MEMORIA.*/
	
	
	if(option == 1)
	{
		chico1 = 123456789;
		chico2 = 123456780;
		chico = chico1 * chico2;
		
		cout << "======================================\n";
		cout << "CASO A\n";
		cout << "======================================\n";
		
		cout << "\nVALOR CHICO1: " << chico1;
		cout << "\nVALOR CHICO2: " << chico2;
		
		cout << "\nRESULTADO OPERACION: " << chico;
		
		cout << "\n\n";
		system("pause");	
	}
	
	
	/* CASO B: Se declaran dos variables como enteros (chico1, chico2) y se almacena
	en ambas un n�mero de 9 cifras. Despu�s se multiplican y devuelve un resultado
	que no se ajuta ni se aproxima al valor real del resultado (la variable "grande" est�
	declarada como entero largo).
	
	�QU� SE PRODUCE EN ESTE CASO?: DESBORDAMIENTO DE MEMORIA.*/
	
	if(option == 2)
	{
		chico1 = 123456789;
		chico2 = 123456780;
		grande = chico1 * chico2;
		
		cout << "======================================\n";
		cout << "CASO B\n";
		cout << "======================================\n";
		
		cout << "\nVALOR CHICO1: " << chico1;
		cout << "\nVALOR CHICO2: " << chico2;
		
		cout << "\nRESULTADO OPERACION: " << grande;
		
		cout << "\n\n";
		system("pause");	
	}
	
	
	/*CASO C: Se declaran dos variables como reales (real1 y real2). Despu�s
	se multiplican, almacen�ndose en la variable resultado (declarada como real). Al
	mostrarse el valor por pantalla, no muestra la parte decimal.
	
	�QU� SE HA PRODUCIDO EN ESTE CASO?: ERROR DE PRECISI�N */
	
	if(option == 3)
	{
		real1 = 123.1;
		real2 = 124.2;
		resultado = real1 * real2;
		
		cout << "======================================\n";
		cout << "CASO C\n";
		cout << "======================================\n";
		
		cout << "\nVALOR REAL1: " << real1;
		cout << "\nVALOR REAL2: " << real2;
		
		cout << "\nRESULTADO OPERACION: " << resultado;
		
		cout << "\n\n";
		system("pause");	
	}
	
	
	/*CASO D: Se declaran dos variables como reales (real1 y real2). Despu�s
	se multiplican, almacen�ndose en la variable resultado (declarada como real). Al
	mostrarse el valor por pantalla, lo muestra en notaci�n cient�fica. 1.234*e+018
	
	�QU� SE HA PRODUCIDO EN ESTE CASO?: ERROR DE PRECISI�N */
	
	if(option == 4)
	{
		real1 = 123456789.1;
		real2 = 123456789.2;
		resultado = real1 * real2;
		
		cout << "======================================\n";
		cout << "CASO D\n";
		cout << "======================================\n";
		
		cout << "\nVALOR REAL1: " << real1;
		cout << "\nVALOR REAL2: " << real2;
		
		cout << "\nRESULTADO OPERACION: " << resultado;
		
		cout << "\n\n";
		system("pause");	
	}
	
	
	/*CASO E: Se declaran dos variables (real, otro_real) como reales. Se le asigna
	un valor a real, y en la variable "otro_real" se guarda el valor de "real" + 1.
	
	Despu�s se calcula la diferencia de esos n�meros, dando como resultado 0, cuando
	deber�a ser -1.
	
	�QU� SE HA PRODUCIDO EN ESTE CASO?: ERROR DE PRECISI�N.*/
	
	if(option == 5)
	{
		real = 2e34;
		otro_real = real + 1; 
		
		cout << "======================================\n";
		cout << "CASO E\n";
		cout << "======================================\n";
		
		cout << "\nVALOR REAL: " << real;
		cout << "\nVALOR OTRO_REAL: " << otro_real;
		
		otro_real = otro_real - real;
		
		cout << "\nRESULTADO OPERACION: " << otro_real;
		
		cout << "\n\n";
		system("pause");	
	}
	
	
	/*CASO F: Se declaran dos variables (real, otro_real) como reales. Se le asigna
	un valor a real, y otro a "otro_real". Despu�s se multiplican entre s�, dando
	como resultado "INF". 
	
	�QU� SE HA PRODUCIDO EN ESTE CASO?: ERROR DE PRECISI�N.*/
	
	
	if(option == 6)
	{
		real = 1e+300; 
		otro_real = 1e+200;
		
		cout << "======================================\n";
		cout << "CASO F\n";
		cout << "======================================\n";
		
		cout << "\nVALOR REAL: " << real;
		cout << "\nVALOR OTRO_REAL: " << otro_real;
		
		otro_real = otro_real * real;
		
		cout << "\nRESULTADO OPERACION: " << otro_real;
		
		cout << "\n\n";
		system("pause");	
	}
	
	
	/*CASO G: Se declaran dos variables (chico_G , grande_G). Se asigna un valor a
	grande_G. Despu�s se asigna ese mismo valor a chico_G. 
	
	Por pantalla se muestra: "INF". 
	
	�QU� SE HA PRODUCIDO EN ESTE CASO?: ERROR DE PRECISI�N.*/
	
	
	if(option == 7)
	{
		grande_G = 2e+150; 
		chico_G = grande_G;
		
		cout << "======================================\n";
		cout << "CASO G\n";
		cout << "======================================\n";
		
		cout << "\nVALOR GRANDE: " << grande_G;
		
		cout << "\nRESULTADO OPERACION: " << chico_G;
		
		cout << "\n\n";
		system("pause");	
	}
	
	else
	{
		cout << "ERROR: NO HA INTRODUCIDO UN VALOR DE OPCION CORRECTO\n";
	}
}
