/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>                                //Inclusi�n de librer�a de recursos de I/O.
#include <string>                                  //Inclusi�n de librer�a para trabajar con cadena de caracteres.

using namespace std;

struct TipoPunto                                   //Creaci�n de tipo de dato para coordenadas de ciudades
{
   double abscisa;
   double ordenada;
};

struct TipoCiudad                                  //Creaci�n de tipo de dato para nombre de ciudad
{
   TipoPunto situacion;
   string nombre;
};

int main()
{
   TipoCiudad ciudad1;                             //Variables para nombre ciudad
   TipoCiudad ciudad2;
   
   TipoPunto abs_1;                                //Variables para coordenada (X)
   TipoPunto abs_2;
   
   TipoPunto ord_1;                                //Variables para coordenada (y)
   TipoPunto ord_2;
   
   string ciudad_nueva;                            //Variables para nueva ciudad
   double abs_nueva;
   double ord_nueva;
   
   cout << "INSERTE NOMBRE PRIMERA CIUDAD: ";                                 //Pide a usuario que introduzca los datos
   cin >> ciudad1.nombre;
   
   cout << "\nINSERTE COORDENADA X (PRIMERA CIUDAD): ";
   cin >> abs_1.abscisa;
   
   cout << "INSERTE COORDENADA Y (SEGUNDA CIUDAD): ";
   cin >> ord_1.ordenada;
   
   cout << "\n\n========================================\n\n";
   
   cout << "INSERTE NOMBRE PRIMERA CIUDAD: ";
   cin >> ciudad2.nombre;
   
   cout << "\nINSERTE COORDENADA X (PRIMERA CIUDAD): ";
   cin >> abs_2.abscisa;
   
   cout << "INSERTE COORDENADA Y (SEGUNDA CIUDAD): ";
   cin >> ord_2.ordenada;
   
   ciudad_nueva = ciudad1.nombre + ciudad2.nombre;                            //Realiza concatenaci�n de nombres de ciudad
   
   abs_nueva = abs_1.abscisa * abs_2.abscisa;                                 //Crea nuevas coordenadas
   ord_nueva = ord_1.ordenada * ord_2.ordenada;
   
   cout << "\n\n========================================\n\n";
   
   cout << "NOMBRE DE NUEVA CIUDAD: " << ciudad_nueva << endl;                                           //Muestra datos a usuario
   cout << "COORDENADAS NUEVA CIUDAD: " << "(" << abs_nueva << " , " << ord_nueva << ")" << endl;
   
   cout << endl;
   system("pause");
}
