/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <string>

using namespace std;

struct fecha
{
   int day;
   int month;
   int year;
};

int main()
{
   fecha fecha_original;								//VARIABLES
   fecha fecha_siguiente;
   fecha fecha_anterior;
   fecha fecha_copia;
   
   char option;

   //INTRODUCCION DE DATOS
   
   cout << "INSERTE DIA DE LA FECHA: ";
   cin >> fecha_original.day;
   
   cout << "INSERTE MES DE LA FECHA: ";
   cin >> fecha_original.month;
   
   cout << "INSERTE ANIO DE LA FECHA: ";
   cin >> fecha_original.year;
 
	//CHECKING DE FECHA BIEN INTRODUCIDA
      
   //CHECKING 1: COMPRUEBA SI EL DIA 31 EST� O NO EN ESE MES
      
   if(fecha_original.day == 31)
   {
      //CHECKING 1.1: COMPRUBEA SI EL DIA 31 EST� EN MESES ANTERIORES A JULIO
      
      if((fecha_original.month < 7) && (fecha_original.month % 2 == 0))
      {
         cout << "\n\nERROR: FECHA INTRODUCIDA NO VALIDA." << endl;
         cout << "CODE_ERROR: 0 (Dia no incluido en mes)";      
         
			cout << endl << endl;
         system("pause");
         return 0;
      }
      
      //CHECKING 1.2: COMPRUEBA SI EL DIA 31 EST� EN MESES POSTERIORES A AGOSTO
   
      if((fecha_original.month > 8) && (fecha_original.month % 2 != 0))
      {
         cout << "\n\nERROR: FECHA INTRODUCIDA NO VALIDA." << endl;
         cout << "CODE_ERROR: 0 (Dia no incluido en mes)";         
         
			cout << endl << endl;
         system("pause");
         return 0;
      }
   }

   //CHECKING 2: COMPRUEBA SI SE HA INTRODUCIDO 30 EN MES FEBRERO (O 29 SI A�O NO ES BISIESTO)
   
	if((fecha_original.year % 4) != 0)
   {
      if(((fecha_original.day == 30) || (fecha_original.day == 29)) && (fecha_original.month == 2))
      {
         cout << "\n\nERROR: FECHA INTRODUCIDA NO VALIDA." << endl;
         cout << "CODE_ERROR: 0.1 (Dia no introducido en mes // FEBRERO EXCEPTION).";            
         
			cout << endl << endl;
         system("pause");
         return 0;
      }
   }
   
   cout << "\n\n===========================================\n\n";

   //MEN� DE OPCIONES
   
   cout << "Que desea realizar?" << endl;
   cout << "A. Ver fecha introducida." << endl;
   cout << "B. Ver fecha siguiente a la introducida." << endl;
   cout << "C. Ver fecha anterior a la introducida." << endl;
   cout << "D. Hacer copia de la fecha introducida." << endl;
   cout << "E. Comprobar si el a�o es bisiesto." << endl << endl;
   
   cout << "Inserte letra de opcion: ";
   cin >> option;

   //SALTOS DE L�NEA
   
   for(int i=0; i<50; i++)
   {
      cout << endl;
   }
   
   //OPCI�N A
   
   if(option == 'A' || option == 'a')
   {
      cout << "LA FECHA ES: " << endl << endl;
      
      cout << fecha_original.day << "/" << fecha_original.month << "/" << fecha_original.year;  
		 
      cout << endl << endl;
      system("pause");
   }
   
   //OPCI�N B
   
   if(option == 'B' || option == 'b')
   {     
      //AJUSTE DE FECHA
      
      if(fecha_original.month == 2)													//COMPRUEBA SI EL MES ES FEBRERO
      {
      	if(fecha_original.day >= 28)												//COMPRUEBA SI EL DIA ES 28 O 29
      	{
      		if(fecha_original.year % 4 == 0)										//COMPRUEBA SI A�O ES BISIESTO
      		{
      			fecha_siguiente.day = 29;
      			fecha_siguiente.month = fecha_original.month;
      			fecha_siguiente.year = fecha_original.year;
      		}
      	
      		if(fecha_original.year % 4 != 0)										//COMPRUEBA SI A�O NO ES BISIESTO
      		{
      			fecha_siguiente.day = 1;
      			fecha_siguiente.month = 3;
      			fecha_siguiente.year = fecha_original.year;
				}
			}
			
			else																				//COMPRUEBA SI DIA ES MENOR QUE 28
			{
				fecha_siguiente.day = fecha_original.day + 1;
      		fecha_siguiente.month = fecha_original.month;
      		fecha_siguiente.year = fecha_original.year;
      	}
      }
      
   	else																									//COMPRUEBA QUE EL MES NO ES FEBRERO
   	{
   		if(fecha_original.day == 30)																//COMPRUEBA QUE EL D�A INTRODUCIDO ES 30
   		{
   			if((fecha_original.month < 7) && (fecha_original.month % 2 == 0))			//COMPRUEBA MESES CON SOLO 30 DIAS ( < JULIO)
      		{
      			fecha_siguiente.day = 1;
      			fecha_siguiente.month = fecha_original.month + 1;
      			fecha_siguiente.year = fecha_original.year;
      		}
      	
      		if((fecha_original.month > 8) && (fecha_original.month % 2 != 0))			//COMPRUEBA MESES CON SOLO 30 DIAS ( > AGOSTO)
      		{
      			fecha_siguiente.day = 1;
      			fecha_siguiente.month = fecha_original.month + 1;
      			fecha_siguiente.year = fecha_original.year;
      		}
      		
      		if(6 < fecha_original.month < 9)														//COMPRUEBA MESES JULIO O AGOSTO
      		{
      			fecha_siguiente.day = 31;
      			fecha_siguiente.month = fecha_original.month;
      			fecha_siguiente.year = fecha_original.year;
      		}
      	}
      	
      	else																										//COMPRUEBA QUE EL DIA NO ES 30
      	{
      		if(fecha_original.day == 31)																	//COMPRUEBA QUE EL DIA ES 31
      		{
      			if((fecha_original.month <= 7) && (fecha_original.month % 2 != 0))			//COMPRUEBA MESES CON 31 DIAS (<= JULIO)
      			{
      				fecha_siguiente.day = 1;
      				fecha_siguiente.month = fecha_original.month + 1;
      				fecha_siguiente.year = fecha_original.year;
					}
			
					if(((fecha_original.month >= 8) != 12) && (fecha_original.month % 2 == 0))  //COMPRUEBA MESES CON 31 DIAS (>= AGOSTO)
					{
						fecha_siguiente.day = 1;
						fecha_siguiente.month = fecha_original.month + 1;
      				fecha_siguiente.year = fecha_original.year;
      			}
      	
      			if(fecha_original.month == 12)															  //COMPRUEBA SI MES ES DICIEMBRE
      			{
      				fecha_siguiente.day = 1;
      				fecha_siguiente.month = 1;
      				fecha_siguiente.year = fecha_original.year + 1;
      			}
      		}
      		
      		else																									  //COMPRUEBA FECHA NORMAL
      		{
      			fecha_siguiente.day = fecha_original.day + 1; 
      			fecha_siguiente.month = fecha_original.month;
      			fecha_siguiente.year = fecha_original.year;
      		}
      	}
      }
      
      //MUESTRA FECHA
      
      cout << "LA FECHA SIGUIENTE ES: " << endl << endl;															
      
      cout << fecha_siguiente.day << "/" << fecha_siguiente.month << "/" << fecha_siguiente.year;
      
      cout << endl << endl;
      system("pause");
   }
   
   //OPCION C
   
   if(option == 'C' || option == 'c')
   {     
      //AJUSTE DE FECHA
      
      if(fecha_original.month == 3)											//COMPRUEBA MES MARZO
      {
      	if(fecha_original.day == 1)										//COMPRUEBA
      	{
      		if(fecha_original.year % 4 == 0)
      		{
      			fecha_anterior.day = 29;
      			fecha_anterior.month = 2;
      			fecha_anterior.year = fecha_original.year;
      		}
      		
      		else
      		{
      			fecha_anterior.day = 28;
      			fecha_anterior.month = 2;
      			fecha_anterior.year = fecha_original.year;
      		}
      	}
      }
      
      else
      {
      	if(fecha_original.month == 1)
      	{
      		fecha_anterior.day = 31;
      		fecha_anterior.month = 12;
      		fecha_anterior.year = fecha_original.year - 1;
      	}
      		
      	else
      	{
      		if(fecha_original.month <= 7)
				{
					if(fecha_original.month % 2 == 0)
					{
						fecha_anterior.day = 31;
      				fecha_anterior.month = fecha_original.month - 1;
      				fecha_anterior.year = fecha_original.year;
      			}
      		
      			if(fecha_original.month % 2 != 0)
      			{
      				fecha_anterior.day = 30;
      				fecha_anterior.month = fecha_original.month - 1;
      				fecha_anterior.year = fecha_original.year;
      			}
      		}
      		
				else
      			{
      				if(fecha_original.month >= 8)
						{
							if(fecha_original.month % 2 == 0)
							{
								fecha_anterior.day = 30;
      						fecha_anterior.month = fecha_original.month - 1;
      						fecha_anterior.year = fecha_original.year;
      					}
      					
      					else
      					{
      						fecha_anterior.day = 31;
      						fecha_anterior.month = fecha_original.month - 1;
      						fecha_anterior.year = fecha_original.year;
      					}
      				}
      					
      				else
      				{
      					fecha_anterior.day = fecha_original.day - 1;
      					fecha_anterior.month = fecha_original.month;
      					fecha_anterior.year = fecha_original.year;
      				}
      			}
      		}
      	}
      
      //MUESTRA FECHA
      
      cout << "LA FECHA ANTERIOR ES: " << endl << endl;															
      
      cout << fecha_anterior.day << "/" << fecha_anterior.month << "/" << fecha_anterior.year;
      
      cout << endl << endl;
      system("pause");
   }
   
   //OPCI�N D
   
   if(option == 'D' || option == 'd')
   {
      fecha_copia.day = fecha_original.day;										//COPIA DE DATOS
      fecha_copia.month = fecha_original.month;
      fecha_copia.year = fecha_original.year;
		  
		cout << "COPIA DE LA FECHA REALIZADA" << endl << endl;				//MENSAJE DE FINALIZACI�N
		
      cout << endl << endl;
      system("pause");
   }
   
   //OPCI�N E
   
   if(option == 'E' || option == 'e')
   {
      if(fecha_original.year % 4 == 0)
      {
      	cout << "EL ANIO: " << fecha_original.year << " ES BISIESTO" << endl << endl;				//COMPRUEBA QUE ES BISIESTO
      }
      
      else
      {
      	cout << "EL ANIO: " << fecha_original.year << " NO ES BISIESTO" << endl << endl;			//COMPRUEBA QUE NO ES BISIESTO
      }
      
      system("pause");
   }
}
