/*CAMBIO DE CAR�CTER NUM�RICO A ENTERO

Se pedir� al usuario introducir un n�mero del 0 al 9 y se asignar�
a una variable de tipo car�cter. Despu�s se devolver� al usuario
el mismo valor que introdujo pero como un dato de tipo entero.

C�DIGO FUENTE POR DANIEL P�REZ RUIZ */

#include <iostream>

using namespace std;

int main ()											//Funci�n principal
{
	bool apA, apB, apD, apE, apF, apG;
	double apC;
	
	string TRUE;
	string FALSE;
	
	TRUE = "TRUE";
	FALSE = "FALSE";
	
	int x, y, z;
	
	char a;
	
	cout << "==========================================\n";
	cout << "EXPRESIONES LOGICAS\n";
	cout << "==========================================\n\n";
	
	
	/*APARTADO A: La variable apA comprueba la veracidad de la desigualdad. En este caso,
	es cierta y por lo tanto muestra en pantalla el valor 1 (TRUE).
	
	Devuelve un dato de tipo: BOOLEANO.*/
	
	apA = 2 + 3 < 5 + 8;
	
	if(apA == 1)
	{
		cout << "APARTADO A: " << apA << " = " << TRUE << "\n";	
	}
	
	else
	{
		cout << "APARTADO A: " << apA << " = " << FALSE << "\n";
	}
	
	
	
	/*APARTADO B: La variable apB comprueba la veracidad de la desigualdad. En este caso,
	es cierta y por lo tanto muestra en pantalla el valor 1 (TRUE).
	
	Devuelve un dato de tipo: BOOLEANO.*/
	
	apB = 2 < 3 < 4;
	
	if(apB == 1)
	{
		cout << "APARTADO B: " << apB << " = " << TRUE << "\n";	
	}
	
	else
	{
		cout << "APARTADO B: " << apB << " = " << FALSE << "\n";
	}
	
	
	/*APARTADO C: La variable apC guarda el resultado de la operaci�n. Tal y como
	est� puesto, obtiene el cociente de 7/3 y a�ade el valor de 4.0.
	
	Devuelve un dato de tipo: ENTERO.*/
	
	apC = 7/3 + 4.0;
	cout << "APARTADO C: " << apC << "\n";
	
	
	/*APARTADO D: La variable apD comprueba la veracidad de la expresi�n l�gica.
	Como se cumple, devuelve 1 (TRUE).
	
	Devuelve un dato de tipo: BOOLEANO.*/
	
	x = 4;
	y = 4;
	z = 4;
	
	apD = x == 4 && y == 3 || z!= 2 == 1!= 2;
	
	if(apD == 1)
	{
		cout << "APARTADO D: " << apD << " = " << TRUE << "\n";	
	}
	
	else
	{
		cout << "APARTADO D: " << apD << " = " << FALSE << "\n";
	}
	
	
	/*APARTADO E: La variable apE comprueba la veracidad de la expresi�n l�gica.
	Como se cumple, devuelve 1 (TRUE).
	
	Devuelve un dato de tipo: BOOLEANO.*/
	
	apE = x <= 4 || x >= 4;
	
	if(apE == 1)
	{
		cout << "APARTADO E: " << apE << " = " << TRUE << "\n";	
	}
	
	else
	{
		cout << "APARTADO E: " << apE << " = " << FALSE << "\n";
	}
	
	
	/*APARTADO F: La variable apF comprueba la veracidad de la expresi�n l�gica.
	Como NO se cumple, devuelve 0 (FALSE).
	
	Devuelve un dato de tipo: BOOLEANO.*/
	
	apF = x < 4 && x > 4;
	
	if(apF == 1)
	{
		cout << "APARTADO F: " << apF << " = " << TRUE << "\n";	
	}
	
	else
	{
		cout << "APARTADO F: " << apF << " = " << FALSE << "\n";
	}
	
	
	/*APARTADO G: La variable apG comprueba la veracidad de la expresi�n l�gica.
	Como se cumple, devuelve 1 (TRUE).
	
	Devuelve un dato de tipo: BOOLEANO.*/
	
	(z > 6 || a < 'z') && (a > 'a' || z < 6);
	
	if(apG == 1)
	{
		cout << "APARTADO G: " << apG << " = " << TRUE << "\n";	
	}
	
	else
	{
		cout << "APARTADO G: " << apG << " = " << FALSE << "\n";
	}
}
	
	
	
