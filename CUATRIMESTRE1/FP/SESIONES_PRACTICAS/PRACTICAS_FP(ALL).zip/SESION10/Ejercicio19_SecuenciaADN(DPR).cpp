/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <string>

using namespace std;

struct Especie{
	string nombre;
	string ADN;
};


void NewEntry(Especie baseDatos[1000], int& longitud){
	
	char respuesta;
	
	cout << "ENTRADAS DE LA BASE DE DATOS: " << longitud << "\n";
	for (int i=0; i<longitud; i++){
		cout << i+1 << "- " << baseDatos[i].nombre << "\n";
	}
	
	cout << "\nINTRODUCIR NUEVA ENTRADA? [Y / N]: ";
	cin >> respuesta;
		
	while(respuesta == 'Y' || respuesta == 'y'){
		longitud++;
		cout << "\nINTRODUCE NOMBRE ESPECIE: ";
		cin.ignore();
		getline(cin, baseDatos[longitud-1].nombre);
		cout << "SECUENCIA DE ADN: ";
		cin >> baseDatos[longitud-1].ADN;
		cout << "\nINTRODUCIR NUEVA ENTRADA? [Y / N]: ";
		cin >> respuesta;
	}
	
	cout << "ENTRADAS DE LA BASE DE DATOS ACTUALMENTE: " << longitud << "\n";
	for (int i=0; i<longitud; i++){
		cout << i+1 << "- " << baseDatos[i].nombre << "\n" ;
	}	
}

bool CompararSecuencia(string adn, string secuencia){
	
	bool encontrada = false;
	int longitudADN, longitudSecuencia;
	int contadorIzquierda, contadorDerecha;
	string nuevaSecuencia;
	
	longitudADN = adn.length();
	longitudSecuencia = secuencia.length();
	
	if(longitudADN == longitudSecuencia){
		
		for(int i=0; i < longitudADN && encontrada == false; i++){
			contadorIzquierda = i;
			contadorDerecha = longitudADN - contadorIzquierda;
			nuevaSecuencia = "";
			
			for(int k=contadorIzquierda; k < longitudADN; k++){
				nuevaSecuencia += secuencia[k];
			}
			
			for(int j=0; j < contadorIzquierda; j++){
				nuevaSecuencia += secuencia[j];
			}
			
			if(nuevaSecuencia == adn){
				encontrada = true;
			}
		}
	}
	
	return encontrada;	
}


int main(){
	Especie mosca = {"Mosca del vinagre", "ATAATGGACAAT"};
	Especie lombriz = {"Lombriz de tierra", "GGATACT"};
	Especie ameba = {"Ameba verde", "AGAGAT"};
	
	Especie baseDatos[1000] = {mosca, lombriz, ameba};	
	int longitud = 3;	
	
	string secuencia;
	string especieEncontrada;
	
	bool encontrado = false;
	
	NewEntry(baseDatos, longitud);
	
	cout << "\nINTRODUCE SECUENCIA AND A BUSCAR: ";
	cin >> secuencia;
	
	for(int i=0; i<longitud && encontrado == false; i++){
		encontrado = CompararSecuencia(baseDatos[i].ADN, secuencia);
		if (encontrado){
			especieEncontrada = baseDatos[i].nombre;
		} 
	}
	
	if(encontrado){
		cout << "\nSE HA ENCONTRADO COINCIDENCIA: " << especieEncontrada;
	}
	else{
		cout << "\nNO SE HA ENCONTRADO NINGUNA COINCIDENCIA";
	}
}

