/*CODIGO FUENTE COMPILADO POR DANIEL P�REZ RUIZ*/

#include <iostream>                                                                    

using namespace std;

int main()
{
   double capital, interes;                                                               //DECLARACION DE LAS VARIABLES
   int anio;
   
   cout << "Inserte capital inicial: ";                                                   //PIDE AL USUARIO QUE INTRODUZCA LOS DATOS   
   cin >> capital;

   cout << "Inserte interes (en %): ";
   cin >> interes;
   
   cout << "Inserte numero de anios: ";
   cin >> anio;
   
   cout << "\n";
   
   for(int i=1; i<=anio; i++)                                                             //CALCULA EL BENEFICIO Y LO MUESTRA SEGUN EL A�O
   {
      capital = capital + capital * (interes / 100);
      
      cout << "Capital en el anio " << i << " es " << capital << "     euros\n";
   }
}
   
   
