/*CODIGO FUENTE COMPILADO POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <string>

using namespace std;

int main()
{
   int sucesion1, sucesion2;                                            //DECLARACION DE VARIABLES
   int minimo1, maximo2;                                                //VARIABLES PARA COMPROBAR QU� SUCESION TIENE LOS ELEMENTOS M�S GRANDES
   
   int contador1 = 0, contador2 = 0;                                    //CONTADORES PARA MOSTRAR AL USUARIO EL NUMERO DE ELEMENTOS INTRODUCIDOS
   
   string MESSAGE = "Inserte numeros para SUCESION ";                   //MENSAJES PARA EL USUARIO
   string FINALIZADOR = " (0 para terminar): ";
   
   cout << MESSAGE << 1 << FINALIZADOR;                                 //PIDE AL USUARIO QUE INTRODUZCA LOS DATOS
   cin >> sucesion1;
   
   minimo1 = sucesion1;                                                 //INICIALIZACION DEL MINIMO DE LA SUCESION1
   
   while(sucesion1 != 0)                                                //WHILE: MIENTRAS NO SE INTRODUZCA EL 0, SIGUE PIDIENDO DATOS E INCREMENTA CONTADOR EN 1
   {
      if(sucesion1 < minimo1)                                           //SI EL NUMERO INTRODUCIDO ES MENOR QUE EL MINIMO, SE CAMBIA EL VALOR DEL MINIMO POR ESE NUM.
      {
         minimo1 = sucesion1;
      }
      
      contador1++;
      cout << MESSAGE << 1 << FINALIZADOR;
      cin >> sucesion1;
   }
   
   for(int i=0; i<10; i++)
   {
      cout << "\n";
   }
   
   
   cout << MESSAGE << 2 << FINALIZADOR;
   cin >> sucesion2;
   
   maximo2 = sucesion2;
   
   while(sucesion2 != 0)                                                      //LO MISMO QUE EN ANTERIOR WHILE
   {
      if(sucesion2 < maximo2)
      {
         maximo2 = sucesion2;
      }
      
      contador2++;
      cout << MESSAGE << 2 << FINALIZADOR;
      cin >> sucesion2;
   }
   
   if(minimo1 > maximo2)                                                                              //MUESTRA DE MENSAJES DE USUARIO
   {
      cout << "\n\nTodos los elementos de la sucesion 1 son mayores que los de la sucesion 2\n\n";
      return 0;
   }
   
   else
   {
      cout << "\n\nTodos los elementos de la sucesion 2 son mayores que los de la sucesion 1\n\n";
   }
   
   cout << "Elementos introducidos en sucesion 1: " << contador1 << "\n";
   cout << "Elementos introducidos en sucesion 2: " << contador2 << "\n";
}
