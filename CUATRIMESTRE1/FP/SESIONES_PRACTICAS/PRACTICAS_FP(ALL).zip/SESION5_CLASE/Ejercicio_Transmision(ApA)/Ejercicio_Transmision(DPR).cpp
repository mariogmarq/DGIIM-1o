/*C�DIGO COMPILADO POR DANIEL P�REZ RUIZ*/

#include <iostream>																//LIBRERIA DE RECURSOS I/O

using namespace std;

int main()
{	
	int count0=0, num=0, count1=0;											//DECLARACI�N DE VARIABLES
	int cifra_unlock=0;
	bool checking = false;


	while(count0 <= 4 && (num == 1 || num == 0))							//WHILE: PIDE DATOS MIENTRAS INTRODUZCA 1 o 0 Y NO SE INTRODUZCAN
	{																					//5 CEROS SEGUIDOS
		cout << "INSERTE 1 | 0 Y PRESIONE ENTER: ";
		cin >> num;	
		
		if(num == 1)																//IF: SI NUMERO ES 1, INCREMENTA EN 1 EL VALOR DEL CONTADOR DE UNOS
		{
			if(checking == false)
			{
				cifra_unlock = 1;
				checking = true;
			}
			
			count0 = 0;																//RESETEA EL CONTADOR DE 0
			count1++;
		}
		
		else																			//ELSE: SI NUMERO ES 0, INCREMENTA EN 1 EL VALOR DE CONTADOR DE CEROS
		{
			count0++;
			
			if(count1 != 0)														//SI EL CONTADOR DE 1 ES DISTINTO DE 0, CALCULA EL NUMERO
			{
				cifra_unlock *= count1;
			}
			
			count1 = 0;
		} 
	}
	
	cout << "\nNUMERO DESCODIFICADO: " << cifra_unlock << "\n";
}
