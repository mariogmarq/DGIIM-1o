/*CODIGO FUENTE COMPILADO POR DANIEL PEREZ RUIZ*/

#include <iostream>															//LIBRERIA DE RECURSOS I/O

using namespace std;

int main()
{

	int resultado = 1;														//DECLARACION DE VARIABLES
	int numero = 1;
	
	while(numero != 0)														//WHILE = PIDE QUE INTRODUZCA 1 Y CALCULA RESULTADO HASTA QUE
	{																				//USUARIO PONGA 0.
		resultado *= numero;
		cout << "INTRODUCE 1: ";
		cin >> numero;
	}
	
	cout << "\n EL RESULTADO ES: " << resultado << "\n"; 
		
}
