/*CODIGO FUENTE POR DANIEL PEREZ RUIZ*/

#include <iostream>

using namespace std;

int main()
{
	int num_tope = 0, divisores = 0;
	int modulo = 0, count = 1;
	int perfecto = 0, perfecto_mayor = 0;
	
	bool check_perfecto;
	
	cout << "INSERTE NUMERO TOPE: ";
	cin >> num_tope;
	
	while(count < num_tope)
	{
		for(int j=1; j <= count; j++)
		{
			modulo = count % j;
		
			if(modulo == 0);
			{
				perfecto += j;
				
				if(perfecto == count)
				{
					perfecto_mayor = perfecto;
					perfecto = 0;
				}
				
				if(count == j)
				{
					perfecto = 0;
				}
			}
		}
	
		if(perfecto_mayor < perfecto)
		{
			perfecto_mayor = perfecto;
		}
		
		count++;
	}

	cout << "\nPERFECTO MAYOR: " << perfecto_mayor;
}
