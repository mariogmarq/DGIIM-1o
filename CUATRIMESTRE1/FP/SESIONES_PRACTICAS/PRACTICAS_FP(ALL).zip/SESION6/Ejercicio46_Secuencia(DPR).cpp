/*CODIGO FUENTE POR DANIEL PEREZ RUIZ*/

#include <iostream>														   //LIBRERIA DE RECURSOS I/O

using namespace std;

int main()
{
	int num = 0, num2 = 100;												//DECLARACION DE VARIABLES
	int posicion1 = 0, posicion_mayor = 0;

	int length = 1, length_superior = 0, count = 1;
	bool end;
	
	cout << "INSERTE SECUENCIA DE NUMEROS (-1 O 101 FIN): ";				//LECTURA ANTICIPADA DE DATOS
	cin >> num;
	end = (num < 0) || (num > 100);											//END: NUMERO ES NEGATIVO O MAYOR QUE 100
	
	while(!end)																//EJECUTA WHILE MIENTRAS NO SE CUMPLA END
	{	
		if(num >= num2)
		{
			length++;														//INCREMENTA 1 LONGITUD SI NUMERO INTRODUCIDO
		}																	//ES MAYOR QUE EL ANTERIOR
		
		else														
		{
			posicion1 = count;												//POSICION INICIAL SE IGUALA A CONTADOR DE POSICION
			length = 1;														//Y LONGITUD SE RESETEA
		}
		
		if((posicion_mayor <= posicion1) && (length_superior < length))		//SI EL NUMERO DE POSICION1 ES MAYOR O IGUAL QUE EL NUMERO INTRODUCIDO DESPUES
		{																	//Y SI LA LONGITUD DE ESA SUCESION ES MAYOR A LA ANTERIOR, SE COPIAN PARAMETROS
			posicion_mayor = posicion1;
			length_superior = length;
		}
		
		count++;
		num2 = num;
		
		cout << "INSERTE SECUENCIA DE NUMEROS (-1 O 101 FIN): ";
		cin >> num;
		end = (num < 0) || (num > 100);
	}
		
	cout << "\nPRIMERA POSICION: " << posicion1;
	cout << "\nLONGITUD: " << length_superior;
}
