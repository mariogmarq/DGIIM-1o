/*CODIGO FUENTE POR DANIEL PEREZ RUIZ*/

#include <iostream>														//LIBRERIA DE RECURSOS I/O
#include <string>														   //LIBRERIA PARA USO STRING

using namespace std;

int main()
{
	string descodificado, ESP = " ";												//DECLARACION DE VARIABLES
	int count = 1, num = 1, num_anterior = 1;
	
	cout << "INSERTE NUMERO (-1 PARA FINALIZAR): ";							//LECTURA ANTICIPADA DE NUMERO
	cin >> num;
	
	num_anterior = num;
	
	while(num > 0)																		//MIENTRAS NUMERO SEA POSITIVO, PIDE DATOS
	{
		cout << "INSERTE NUMERO (-1 PARA FINALIZAR): ";
		cin >> num;
		
		if(num == num_anterior)														//IF: SI NUMERO ES MENOR O IGUAL QUE ANTERIOR (Y DIF. -1)
		{																					//INCREMENTA EN 1 EL CONTADOR.
			count++;
		}
		
		else																				//ELSE: SI NUMERO ES MAYOR QUE ANTERIOR, SE ALMACENA EN UN
		{																					//STRING LOS VALORES DE CONTADOR Y ULTIMA CIFRA INTRODUCIDA
		
			descodificado += to_string(count) + ESP + to_string(num_anterior) + ESP;
			num_anterior = num;	
			count = 1;
		}
	}
	
	cout << "\nNUM DESCODIFICADO: " << descodificado;					//MUESTRA EL RESULTADO
}
