/* EJERCICIO 1: C�LCULO DEL VOLTAJE A TRAV�S DE LA LEY DE OHM

SE REQUIEREN LOS DATOS DE LA INTENSIDAD Y LA RESISTENCIA PARA RESOLVER LA SIGUIENTE IGUALDAD:
VOLTAJE(V) = RESISTENCIA(OHMIOS) * INTENSIDAD(A)

SE PEDIR� AL USUARIO TAMBI�N QUE INTRODUZCA LOS DATOS EN LAS MAGNITUDES DEL S.I.

C�DIGO FUENTE ESCRITO POR DANIEL P�REZ RUIZ */


#include <iostream>			//Inclusi�n de librer�a de recursos de E/S
#include <cmath>				//Inclusi�n de librer�a para recursos matem�ticos

using namespace std;

int main()									//Programa principal
	{
		double resistencia; 				//Variable para guardar valor de resistencia
		double intensidad;				//Variable para guardar valor de intensidad
		double voltaje;					//Variable para guardar valor de voltaje
		
		
		//INTERACCI�N USUARIO-> M�QUINA
		
		cout << "PROGRAMA PARA CALCULAR EL VOLTAJE SEG�N LA LEY DE OHM\n\n";
		
		cout << "INTRODUZCA VALOR DE RESISTENCIA (EN OHMIOS): ";
		cin >> resistencia;
		
		cout << "\nINTRODUZCA VALOR DE INTENSIDAD (EN AMPERIOS): ";
		cin >> intensidad;
		
		
		//C�LCULO DEL RESULTADO
		
		voltaje = resistencia * intensidad;
		
		
		//MUESTRA DE RESULTADO
		
		cout << "\nEL VOLTAJE ES: " << voltaje << "\n\n";
		
		system("pause");
		cout << "\n\nC�DIGO FUENTE ESCRITO POR DANIEL P�REZ RUIZ\n\n";
	}
