/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

struct FrecuenciaCaracter{
	char caracter;
	int frecuencia;
} 

void Moda(char cadena[1000], int longitud){
	const int DIMENSION_MAX = 100;
	char Matriz[DIMENSION_MAX][DIMENSION_MAX] = {0};
	
	for(int i=0; i<)

int main(){
	FrecuenciaCaracter resultado;
	const int DIMENSION = 1000;
	char cadena[DIMENSION] = {0};
	int longitud = 0;
	
	do{
		cout << "Inserte longitud cadena: ";
		cin >> longitud;
	}while(0>longitud || longitud > DIMENSION);
	
	cout << "Inserte cadena: ";
	for(int i=0)
	
	Moda()
		

	
