/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

const int DIMENSION_MAXIMA = 1000;

void ImparPar(int vector[DIMENSION_MAXIMA], int longitud){
	int vector_par[DIMENSION_MAXIMA] = {0};
	int vector_impar[DIMENSION_MAXIMA] = {0};
	int longitud1 = 0, longitud2 = 0;
	
	for(int i=0; i<longitud; i++){
		if(vector[i] % 2 == 0){
			vector_par[longitud1] = vector[i];
			longitud1++;
		}
		
		else{
			vector_impar[longitud2] = vector[i];
			longitud2++;
		}
	}
	
	cout << "\n\nVECTOR DE NUMEROS PARES: ";
	for(int i=0; i<longitud1; i++){
		cout << vector_par[i] << " ";
	}
	
	cout << "\nVECTOR DE NUMEROS IMPARES: ";
	for(int i=0; i<longitud2; i++){
		cout << vector_impar[i] << " ";
	}
}

int main(){
	int vector[DIMENSION_MAXIMA] = {0};
	int longitud = 0;
	
	do{
		cout << "Inserte una longitud valida: ";
		cin >> longitud;
	}while(0>=longitud || longitud > 1000);
	
	cout << "Inserte vector separado por espacios: ";
	for(int i=0; i<longitud;i++){
		cin >> vector[i];
	}
	
	ImparPar(vector, longitud);
}
	
