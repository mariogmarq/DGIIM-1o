/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <string>

using namespace std;

bool BuscarCaracter(string cadena, int longitud, char caracter){
	bool respuesta = false;
	
	for(int i=0; i<=longitud; i++){
		if(cadena[i] == caracter){
			respuesta = true;
		}
	}
	return respuesta;
}

int main(){
	string cadena;
	char caracter;
	int longitud = 0, a = 0;
	
	cout << "INSERTE CADENA (intro fin): ";
	cin >> cadena;
	
	while(cadena[a] != '\0'){
		longitud++;
		a++;
	}
	
	cout << "\nINSERTE CARACTER A BUSCAR: ";
	cin >> caracter;
	
	if(BuscarCaracter(cadena, longitud, caracter)){
		cout << "\n\nEL CARACTER SE HA ENCONTRADO EN LA CADENA";
	}
	
	else{
		cout << "\n\nNO SE HA PODIDO ENCONTRAR CARACTER";
	}
}
