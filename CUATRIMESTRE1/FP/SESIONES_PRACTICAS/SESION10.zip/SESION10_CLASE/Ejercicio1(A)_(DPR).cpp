/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>
#include <cmath>

using namespace std;

class Recta{
	public:
		double A, B, C;
};

int main(){
	double pendiente1 = 0, pendiente2 = 0;
	Recta recta1, recta2;
	
	cout << "Inserte coeficientes recta 1: ";
	cin >> recta1.A >> recta1.B >> recta1.C;
	
	cout << "Inserte coeficientes recta 2: ";
	cin >> recta2.A >> recta2.B >> recta2.C;
	
	if(recta1.B == 0){
		pendiente1 = INFINITY;
	}
	else{
		pendiente1 = (-1) * (recta1.A / recta1.B);
	}
	if(recta2.B == 0){
		pendiente2 = INFINITY;
	}
	else{
		pendiente2 = (-1) * (recta2.A / recta2.B);
	}
	
	cout << "\n\nPENDIENTE DE LA RECTA 1: " << pendiente1;
	cout << "\nPENDIENTE DE LA RECTA 2: " << pendiente2;
}
	
	
	
