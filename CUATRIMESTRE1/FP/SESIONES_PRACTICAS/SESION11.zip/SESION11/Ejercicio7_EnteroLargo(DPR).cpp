/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

class EnteroLargo{
	private:
		static const int MAX_LONG = 1000;
		int numero[MAX_LONG];
		int longitud;
		
	public:
		//CONSTRUCTOR
		EnteroLargo(){
			numero[MAX_LONG] = {0};
			longitud = MAX_LONG;
		}
		void SetLongitud(int length){
			longitud = length;
		}
		void SetNumero(int number_value[MAX_LONG], int longitud){
			numero[0] = number_value[0];
			for(int i=1; i<longitud; i++){
				if(number_value[i] < 0){
					numero[i] = -number_value[i];
				}
				else{
					numero[i] = number_value[i];
				}
			}
		}
		void MostrarNumero(){
			for(int i=0; i<longitud; i++){
				cout << numero[i];
			}
		}
		EnteroLargo operator +(EnteroLargo &num2){
			EnteroLargo suma;
			int length_max, a=longitud, b=num2.longitud, i;
			if(longitud >= num2.longitud){
				length_max = longitud;
			}
			else{
				length_max = num2.longitud;
			}
			i = length_max;
			while(i != -1){
				if(a == -1)
					suma.numero[i] += num2.numero[b];
				else
					if(b == -1)
						suma.numero[i] += numero[a];
						else
							suma.numero[i] += this->numero[a] + num2.numero[b];
				if(((suma.numero[i] / 10) > 0) && i>0){
					suma.numero[i-1] = suma.numero[i] / 10;
					suma.numero[i] = suma.numero[i] % 10;
				}
				i--;
				a--;
				b--;	
			}
			suma.SetLongitud(length_max);
			suma.SetNumero(suma.numero, length_max);
			return suma;
		}
};

void LeerNumero(EnteroLargo& number_value){
	int longitud;
	int numb_array[1000] = {0};
	
	do{
		cout << "Inserte longitud: ";
		cin >> longitud;
	}while(longitud < 0 || longitud > 1000);
	number_value.SetLongitud(longitud);
	
	cout << "Inserte numero para longitud de: " << longitud << " digitos\n >>> ";
	for(int i=0; i<longitud; i++){
		cin >> numb_array[i];
	}
	number_value.SetNumero(numb_array, longitud);
}

int main(){
	EnteroLargo numero1, numero2, suma;
	
	LeerNumero(numero1);
	LeerNumero(numero2);
	numero1.MostrarNumero();
	cout << "\n";
	numero2.MostrarNumero();
	suma = numero1 + numero2;
	cout << "\n";
	suma.MostrarNumero();
}
