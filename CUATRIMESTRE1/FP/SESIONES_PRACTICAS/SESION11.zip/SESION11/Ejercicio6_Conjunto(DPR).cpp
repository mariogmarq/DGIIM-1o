/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

class Conjunto{
	private:
		static const int MAXELEM = 100;
		int num_elem;
		int elementos[MAXELEM];
		
		void OrdenarConjunto(int VectorCon[MAXELEM], int length){
			int swap = 0;
			for(int j=0; j<length; j++){
				for(int i=0; i<length; i++){
					if(VectorCon[i] < VectorCon[i+1]){
						elementos[i] = VectorCon[i];
					}
					else{
						swap = elementos[i];
						elementos[i] = VectorCon[i+1];
						elementos[i+1] = swap;
					}
				}
			}
		}	
	public:
		//CONSTRUCTOR
		Conjunto(){
			num_elem = 0;
			elementos[MAXELEM] = {0};
		}
		void SetNumElem(int elementos){
			num_elem = elementos;
		}
		void SetElementos(int componentes[MAXELEM], int longitud){
			for(int i=0; i<longitud; i++){
				elementos[i] = componentes[i];
			}
			OrdenarConjunto(elementos, longitud);
		}
		void MostrarConjunto(){
			cout << "\n\nCONJUNTO: ";
			for(int i=0; i<num_elem; i++){
				cout << elementos[i] << " ";
			}
		}
		void MostrarCardinal(){
			cout << "\nCARDINAL DEL CONJUNTO: " << num_elem;
		}
		void FindComponente(){
			bool encontrado = false;
			int i=0, componente;
			
			cout << "\nINSERTE COMPONENTE A BUSCAR: ";
			cin >> componente;
			
			while(!encontrado && i!=num_elem){
				encontrado = componente == elementos[i];
				i++;
			}
			if(encontrado){
				cout << "\nEL ELEMENTO " << componente << " SE HA ENCONTRADO EN EL CONJUNTO";
			}
			else{
				cout << "\nEL ELEMENTO " << componente << " NO ESTA EN EL CONJUNTO";
			}
		}
		void NewElemento(){
			int new_elemento = 0, elemento_entre_componentes;
			int posicion_new_elemento, i = 0;
			bool elemento_menor_todos;
			
			cout << "\n\nINSERTE NUEVO ELEMENTO: ";
			cin >> new_elemento;
			
			while(i < num_elem){
				elemento_entre_componentes = new_elemento > elementos[i] && new_elemento < elementos[i+1];
				if(elemento_entre_componentes){
					posicion_new_elemento = i;
					i = num_elem;
				}
				i++;
			}
		
			//SI SE CUMPLE LAS CONDICIONES DEL WHILE
			if(elemento_entre_componentes){
				for(int c=0; c < num_elem; c++){
					cout << elementos[c];
					if(c == posicion_new_elemento){
						cout << new_elemento;
					}
				}
			}
		
			//COMPRUEBA SI ELEMENTO DADO ES MENOR QUE TODOS LOS DEL CONJUNTO
			for(int a = 0; a < num_elem; a++){
				if(new_elemento < elementos[a]){
					elemento_menor_todos = true;
				}
			}
		
			//SI SE CUMPLE FOR ANTERIOR: MUESTRA
			if(elemento_menor_todos){
				cout << new_elemento;
				for(int b=0; b < num_elem; b++){
					cout << elementos[b];
				}
			}
		}
			
};

void LeerConjunto(Conjunto& conjunto){
	int longitud;
	int numb_array[100] = {0};
	
	do{
		cout << "Inserte longitud: ";
		cin >> longitud;
	}while(longitud < 0 || longitud > 100);
	conjunto.SetNumElem(longitud);
	
	cout << "Inserte elementos del conjunto: \n>>> ";
	for(int i=0; i<longitud; i++){
		cin >> numb_array[i];
	}
	conjunto.SetElementos(numb_array, longitud);
}

int main(){
	Conjunto conjunto1;
	
	LeerConjunto(conjunto1);
	
	conjunto1.MostrarCardinal();
	conjunto1.MostrarConjunto();
	conjunto1.FindComponente();
	conjunto1.NewElemento();
}
