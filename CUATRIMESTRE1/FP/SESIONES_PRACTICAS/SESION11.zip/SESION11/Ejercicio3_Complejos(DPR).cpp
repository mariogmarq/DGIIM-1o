/*C�DIGO FUENTE POR DANIEL P�REZ RUIZ*/

#include <iostream>

using namespace std;

const char COMPLEJO = 'i';

class Complejos{
	private:
		double a, b;
	public:
		//CONSTRUCTOR
		Complejos(){
			a = 0;
			b = 1;
		}
		Complejos(double real, double imaginario){
			a = real;
			b = imaginario;
		}
		//SET DATOS
		void SetReal(double real){
			a = real;
		}
		void SetImaginario(double imaginario){
			b = imaginario;
		}
		//FUNCION PARA MOSTRAR COMPLEJO
		void MostrarComplejo(){
			if(b < 0){
				cout << a << " " << b << COMPLEJO << "\n";
			}
			else{
				cout << a << " + " << b << COMPLEJO << "\n";
			}
		}
		//OBTENCION PARTE REAL E IMAGINARIA
		void GetReal(){
			cout << "\nPARTE REAL: " << a;
		}
		void GetImaginario(){
			cout << "\nPARTE IMAGINARIA: " << b;
		}
		//SOBRECARGA OPERADOR SUMA
		Complejos operator +(Complejos &c2){
			Complejos complejo_suma = {0,0};
			complejo_suma.a = this->a + c2.a;
			complejo_suma.b = this->b + c2.b;
			return complejo_suma;
		}
		//SOBRECARGA OPERADOR RESTA
		Complejos operator -(Complejos &c2){
			Complejos complejo_resta = {0,0};
			complejo_resta.a = this->a - c2.a;
			complejo_resta.b = this->b - c2.b;
			return complejo_resta;
		}
		//SOBRECARGA OPERADOR MULTIPLICACION
		Complejos operator *(Complejos &c2){
			Complejos complejo_mult = {0,0};
			complejo_mult.a = (this->a * c2.a) - (this->b * c2.b);
			complejo_mult.b = (this->b * c2.a) + (this->a * c2.b);
			return complejo_mult;
		}
};

void LeerComplejo(Complejos& complejo){
	double real, imaginario;
	cout << "Inserte parte real de complejo: ";
	cin >> real;
	complejo.SetReal(real);
	
	cout << "Inserte parte imaginaria de complejo (sin i): ";
	cin >> imaginario;
	complejo.SetImaginario(imaginario);
}

int main(){
	Complejos complejo1{2,5}, complejo2{7,9};
	Complejos complejo_operator;
	
	//LEER COMPLEJO1
	cout << "LEER COMPLEJO\n";
	LeerComplejo(complejo1);
	
	//MUESTRA COMPLEJO1 Y COMPLEJO2
	cout << "\n\nMOSTRAR COMPLEJO 1 Y 2\n";
	complejo1.MostrarComplejo();
	complejo2.MostrarComplejo();
	
	//OBTENER REAL COMPLEJO 1 Y REAL COMPLEJO2
	cout << "\n\nOBTENER PARTE REAL COMP1 Y COMP2\n";
	complejo1.GetReal();
	complejo2.GetReal();
	
	//OBTENER IM COMPLEJO 1 E IM COMPLEJO2
	cout << "\n\nOBTENER PARTE IMAGINARIA COMP1 Y COM2\n";
	complejo1.GetImaginario();
	complejo2.GetImaginario();
	
	//OBTENER SUMA COMPLEJO 1 Y COMPLEJO 2
	cout << "\n\nSUMA DE COMPLEJO 1 Y COMLPEJO 2\n";
	complejo_operator = complejo1 + complejo2;
	complejo_operator.MostrarComplejo();
	
	//OBTENER RESTA COMPLEJO1 Y COMPLEJO2
	cout << "\n\nRESTA DE COMPLEJO 1 Y COMLPEJO 2\n";
	complejo_operator = complejo1 - complejo2;
	complejo_operator.MostrarComplejo();
	
	//OBTENER MULTIPLICACION COMPLEJO1 Y COMPLEJO2
	cout << "\n\nMULTIPLICACION COMPLEJO 1 Y COMPLEJO 2\n";
	complejo_operator = complejo1 * complejo2;
	complejo_operator.MostrarComplejo();
}
